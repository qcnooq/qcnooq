/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020 ISBN: 9788897527541 
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// QcNooqStatic.cpp: A simple class to have coloured Static strings. To be included in project ONLY in Windows MFC environment
//
#include "stdafx.h"
#include "QcNooq.h"
#include "QcNooqDlg.h"
#include "QcNooqButton.h"
#include "QcNooqStatic.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStaticML

CStaticML::CStaticML()
{
    m_clrText  = 0x00 ;
    m_clrBkgnd = ZO_COLOR_SFONDONE_SFONDO_STATICS ;
    m_brBkgnd.CreateSolidBrush( m_clrBkgnd );/**/    
}
void CStaticML::ColoriSpeciali ( int testo, int sfondo )
{
 if ( testo  != -1 ) m_clrText  = testo  ; else m_clrText  = ZO_COLOR_NORMAL_TEXT ;
 if ( sfondo != -1 ) {
     m_clrBkgnd = sfondo ;
     m_brBkgnd.DeleteObject() ;
     m_brBkgnd.CreateSolidBrush( m_clrBkgnd );
 }
 else m_clrBkgnd = ZO_COLOR_SFONDONE_SFONDO_STATICS ;
}
CStaticML::~CStaticML()
{
}
BEGIN_MESSAGE_MAP(CStaticML, CStatic)
	//{{_MAP(CStaticML)
	ON_WM_CTLCOLOR_REFLECT()
    ON_WM_PAINT()
    ON_WM_DESTROY()
	//}}_MAP
END_MESSAGE_MAP()

// CStaticML message handlers
void CStaticML::OnDestroy()
{
}
HBRUSH CStaticML::CtlColor(CDC* pDC, UINT nCtlColor)
{
 pDC->SetTextColor( m_clrText );    // text
 pDC->SetBkColor( m_clrBkgnd );    // text bkgnd
/* pDC->SetTextCharacterExtra(1) ;   // 1 pixel dopo ogni carattere fa confusione sui portatili 1280 * 800
/**/
 //pDC->SetTextJustification(4,2) ;  // allargamento tra parole
 /**/
 return m_brBkgnd;               // ctl bkgnd
}
void CStaticML::OnPaint()
{
 CStatic::OnPaint() ;
}
/**/