/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
#pragma once
#ifdef QCNOOQ_WINDOWS
#include "afxwin.h"
#endif

// CQCP_shor dialog

// execution of pseudo emulation 
extern void PS_ExecuteShor(int N, int attempts , double neighborhood , int numPeriods ) ;

class CQCP_shor 
#ifdef QCNOOQ_WINDOWS
	: public CDialogML
#endif
{
#ifdef QCNOOQ_WINDOWS
	DECLARE_DYNAMIC(CQCP_shor)
public:
	CQCP_shor(CWnd* pParent = NULL);   // standard constructor
	virtual ~CQCP_shor();
	BOOL Create(CWnd* pParent) ;
	void OnCancel() ;
	BOOL OnInitDialog();
	void OnOK();
	CStaticML m_progress1;

// Dialog Data
	enum { IDD = IDD_QCP_J_SHOR };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
	CStaticML m_static00, m_static01, m_static02, m_static03, m_static04 ;
	CColorButton m_pp0,m_mm0,m_A,m_pp1,m_mm1,m_B,m_C,m_D,m_E,m_F,m_G,m_H,m_Z;
	CEdit m_edit_number_64, m_edit_number_16, m_experiments_input;
#endif
public:
	int N, number_of_loops ;  // parameters for threaded period search
protected:
	void only_digits(char *buf) ;
	void QCF_Shor_increment_64();
	void QCF_Shor_decrement_64();
	void QCF_Shor_increment_16();
	void QCF_Shor_decrement_16();
	void QCF_Non_Shor_factoring_64_bit();
	int  QCF_do_factoring_16_bit(unsigned short input, char *buf);
	void QCF_Non_Shor_factoring_16_bit();
	void QCF_Shor_nonquantum_16();
	void QCF_Shor_nonquantum_16_overflow();
	void QCF_Non_Quantum_Shor_16_overflow_controlled();
	void QCF_Non_Quantum_Shor_16_overflow_NOT_controlled();
	void QCF_do_Shor_Period_16(char verbose) ;
	void QCF_Shor_Periods_16_bit();
	void QCF_Shor_Periods_16_bit_short();
	BOOL QCF_Shor_Uf_4_bit_exec(int);	
	void QCF_Shor_Uf_4_bit();	
	void QCF_Shor_Uf_4_periods();	
	void QCF_Shor_Test_Tools();
};
