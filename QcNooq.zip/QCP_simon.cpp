/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// QCP_Simon.cpp : implementation file. Drills for Chapter 6.3 of "Quantum Computing for Programmers and Investors"
//

#include "stdafx.h"
#include "QcNooq.h"

#include "math.h"      // standard C math definition     
#include "QCM_math.h"  // portable definitions 
#include "QCM_tools.h"

#include "QCP_Simon.h"

// CQCP_simon dialog
#ifdef QCNOOQ_WINDOWS
IMPLEMENT_DYNAMIC(CQCP_simon, CDialog)

CQCP_simon::CQCP_simon(CWnd* pParent /*=NULL*/) : CDialogML(CQCP_simon::IDD, pParent)
{
}
CQCP_simon::~CQCP_simon()
{
}
BOOL CQCP_simon::Create(CWnd* pParent)
{
	if (!CDialogML::Create(CQCP_simon::IDD, pParent))
	{
		return FALSE;
	}
	return TRUE;
}
void CQCP_simon::OnCancel() {DestroyWindow(); theApp.windows_semaphore=0;}
void CQCP_simon::DoDataExchange(CDataExchange* pDX)
{
	CDialogML::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC00, m_static00);
	DDX_Control(pDX, IDC_STATIC01, m_static01);
	DDX_Control(pDX, IDC_Simon_3bit_func_1, m_A);
	DDX_Control(pDX, IDC_Simon_3bit_func_check, m_B);
	DDX_Control(pDX, IDC_Simon_3bit_func_Uf, m_C);
	DDX_Control(pDX, IDC_Simon_3bit_func_Uf_ver, m_D);
	DDX_Control(pDX, IDC_Simon_3bit_Simons_once, m_E);
	DDX_Control(pDX, IDC_Simon_3bit_Simons, m_F);
	DDX_Control(pDX, IDC_Simon_6bit_func_1, m_G);
	DDX_Control(pDX, IDC_Simon_6bit_func_check, m_H);
	DDX_Control(pDX, IDC_Simon_6bit_func_Uf, m_I);
	DDX_Control(pDX, IDC_Simon_6bit_func_Uf_ver, m_J);
	DDX_Control(pDX, IDC_Simon_6bit_Simons_once, m_K);
	DDX_Control(pDX, IDC_Simon_6bit_Simons, m_L);
}
BEGIN_MESSAGE_MAP(CQCP_simon, CDialogML)
	ON_BN_CLICKED(IDC_Simon_3bit_func_1, &CQCP_simon::QCF_Simon_3bit_func_definition)
	ON_BN_CLICKED(IDC_Simon_3bit_func_check, &CQCP_simon::QCF_Simon_3bit_func_find_period)
	ON_BN_CLICKED(IDC_Simon_3bit_func_Uf, &CQCP_simon::QCF_Simon_3bit_func_Uf)
	ON_BN_CLICKED(IDC_Simon_3bit_func_Uf_ver, &CQCP_simon::QCF_Simon_3bit_func_Uf_verify)	
	ON_BN_CLICKED(IDC_Simon_3bit_Simons_once, &CQCP_simon::QCF_Simon_3bit_Simons_once)
	ON_BN_CLICKED(IDC_Simon_3bit_Simons, &CQCP_simon::QCF_Simon_3bit_Simons)

	ON_BN_CLICKED(IDC_Simon_6bit_func_1, &CQCP_simon::QCF_Simon_6bit_func_definition)
	ON_BN_CLICKED(IDC_Simon_6bit_func_check, &CQCP_simon::QCF_Simon_6bit_func_find_period)
	ON_BN_CLICKED(IDC_Simon_6bit_func_Uf, &CQCP_simon::QCF_Simon_6bit_func_Uf)
	ON_BN_CLICKED(IDC_Simon_6bit_func_Uf_ver, &CQCP_simon::QCF_Simon_6bit_func_Uf_verify)	
	ON_BN_CLICKED(IDC_Simon_6bit_Simons_once, &CQCP_simon::QCF_Simon_6bit_Simons_once)
	ON_BN_CLICKED(IDC_Simon_6bit_Simons, &CQCP_simon::QCF_Simon_6bit_Simons)
END_MESSAGE_MAP()
void CQCP_simon::OnOK(){};
BOOL CQCP_simon::OnInitDialog()
{
	CDialogML::OnInitDialog();
	ListMatrixResize(2); // give appropriate sizes - output goes mainly to the message box
	return TRUE;  // return TRUE  unless you set the focus to a control
}
#endif
// CQCP_simon message handlers
static byte base_fx3_other(byte indata) 
{
 return  indata/2; 
}
// The same 3 bit function fx() will be used in the following:
static byte base_fx3(byte indata) 
{
//              input = { 0, 1, 2, 3, 4, 5, 6, 7 } ; 
static byte output[8] = { 4, 1, 5, 7, 1, 4, 7, 5 } ; // two to one - Correct
// With the following cases Simon's Algorithm would not work
//static byte output[8] = { 7, 6, 3, 2, 0, 1, 4, 5 } ; // one to one
//static byte output[8] = { 4, 1, 5, 7, 2, 2, 3, 5 } ; // other
 if ( indata < 8 ) return output[indata] ; 
 else return 0xff ; 
}
void CQCP_simon::QCF_Simon_3bit_func_definition()
{
char buf[200] ;
int x ; 
byte fx ; 
  // get a random input
  x = qx_random() % 8 ; 
  // perform calculation:
  fx = base_fx3(x); 
  sprintf(buf, "Simple Calculation RANDOM  x=%d (%s), fx=%d (%s)", x, qx_binary_output(3,x), fx, qx_binary_output(3,fx) ) ; 
  ListMatrix(0x20,buf) ; //scroll to bottom 
}
void CQCP_simon::QCF_Simon_3bit_func_find_period()
{
char buf[200] ;
byte c, x, x_xor_c ;
byte cfound ; 
 ListMatrix(3, "3 bit sample function having Simon\'s requirements" ) ; 
 for ( cfound = c = 0 ; c < 8 ; ++c ) 
 {
	for ( x = 0 ; x < 8 ; ++x ) 
	{
		x_xor_c = (x^c) & 0x07 ; // zero not relevant bits
		if ( base_fx3(x_xor_c) != base_fx3(x) ) break ; 
	}
	if ( x == 8 ) // condition verified 
	{
		cfound = c ; 
		sprintf ( buf, "Found Period c = %d Binary = %s ", c, qx_binary_output(3,c) ) ; 
		ListMatrix(0, buf ) ; 
		for ( x = 0 ; x < 8 ; ++x ) 
		{
			x_xor_c = (x^c) & 0x07 ; 
			sprintf ( buf, "Period c=%d (%s) x_xor_c=%d (%s) x=%d (%s) f(x^c)=%d (%s) f(x)=%d (%s)", 
				c, qx_binary_output(3,c), 
				x_xor_c, qx_binary_output(3,x_xor_c),
				x, qx_binary_output(3,x), 
				base_fx3(x_xor_c),qx_binary_output(3,base_fx3(x_xor_c)),
				base_fx3(x), qx_binary_output(3,base_fx3(x)) ) ;
			ListMatrix(0,buf);
		}
		ListMatrix(0,"---") ; 
	}	
 }
 // if cfound != 0, verify values for which <value, cfound> == 0 
 ListMatrix(0,"Bit inner product <v,c> for every input" ) ; 
byte inpr, value ; 
 if ( cfound != 0 ) 
 {
    // convert c in a qx vector to execute inner product 
	for ( value = 0 ; value < 8 ; ++value ) 
	{
		inpr = qx_bit_inner_product(3, value, cfound) ; 
		sprintf ( buf, "value = %d (%s) c=%d (%s) <value,c>=%d", value, qx_binary_output(3,value), cfound, qx_binary_output(3,cfound), inpr ) ; 
		ListMatrix(0,buf) ;
	}
 }
}
void CQCP_simon::QCF_Simon_3bit_func_Uf_compose(char mode, qx Ufunc[64][64])
{
char buf[200] ; 
int j, row, col ; 
byte x, y, fx, y_xor_fx ; 
 memset ( Ufunc, 0, 64*64*sizeof(qx) ) ; 
 for ( j = 0 ; j < 64 ; ++j ) 
 {
	x = (j & (32|16|8)) >> 3 ; 
	y = (j & (4+2+1)) ; 
	// this is the classical calculation of f(x):
	// we must calculate every possible value of fx to compose the matrix:
	fx = base_fx3(x) ; 
	y_xor_fx = y^fx ; 
    row = x*8 + y ;
	col = x*8 + y_xor_fx ;
	Ufunc[row][col].a = 1.0 ; 
 }
 if ( mode == 1 ) 
 {
	 // This representation wuold work, but is difficult to read:
	 // ListMatrix(0,"Ufunc", 64,64,(qx *)Ufunc) ; 
	 sprintf ( buf, "Ufunc is unitary=%s, is hermitian=%s", qx_matrix_is_unitary(64,(qx *)Ufunc) ? "yes" : "no", qx_matrix_is_hermitian(64,(qx *)Ufunc) ? "yes" : "no"  ) ; 
	 ListMatrix(3,buf) ; 
	 // list matrix lines as a string of vectors
	 for ( j = 0 ; j < 64 ; ++j ) 
	 {
		 sprintf ( buf, "%02d %s", j, qx_vector_qx_to_binary_output(64, Ufunc[j]) ) ; 
		 ListMatrix(0, buf) ; 	
	 }
 }
}
void CQCP_simon::QCF_Simon_3bit_func_Uf()
{
qx Ufunc[64][64] ;
 // compose Ufunc and output it 
 QCF_Simon_3bit_func_Uf_compose(1,Ufunc); 
}
void CQCP_simon::QCF_Simon_3bit_func_Uf_verify()
{
char buf[200] ; 
qx Ufunc[64][64] ;
qx invector[64], outvector[64] ; 
int j ; 
byte x, y, y_xor_fx, fx ; 
 // compose Ufunc without display 
 QCF_Simon_3bit_func_Uf_compose(0,Ufunc); 
 // get a random index: it will express a couple of x and y 
 j = qx_random() % 64 ; 
 memset ( invector, 0, 64 * sizeof(qx) ) ; 
 invector[j].a = 1 ; // chosen row of matrix
 qx_matrix_mmul(64,64,1,(qx *)Ufunc, invector, outvector ) ; 
 x = (qx_state_variable_binary_value(64, invector, 0)<<2) + (qx_state_variable_binary_value(64, invector, 1)<<1) + (qx_state_variable_binary_value(64, invector, 2)) ; 
 y = (qx_state_variable_binary_value(64, invector, 3)<<2) + (qx_state_variable_binary_value(64, invector, 4)<<1) + (qx_state_variable_binary_value(64, invector, 5)) ; 
 y_xor_fx = 
	 (qx_state_variable_binary_value(64,outvector, 3)<<2) + (qx_state_variable_binary_value(64,outvector, 4)<<1) + (qx_state_variable_binary_value(64,outvector, 5)) ; 
 fx = y_xor_fx ^ y ;  

 sprintf(buf, "Calculation via Uf RANDOM j=%d, x=%d (%s), fx=%d (%s)", j, x, qx_binary_output(3,x), fx, qx_binary_output(3,fx) ) ; 
 ListMatrix(0x20,buf) ; //scroll to bottom 
}
void CQCP_simon::QCF_Simon_3bit_Simons_once()
{
char buf[200] ; 
qx Ufunc[64][64] ;
qx phi0[64], phi1[64], phi2[64], phi3[64], measured[64] ;  ; 
qx HA8[8][8] ;
qx ID8[8][8] ;
qx HA8ID8[64][64] ;
byte z ; 
// following are static in order to allow many subsequent tests
static int tests, z_frequency[8] ; 
 
 ListMatrixResize(1) ; 
 // compose Ufunc without display 
 QCF_Simon_3bit_func_Uf_compose(0,Ufunc); 
 qx_matrix_constant(QX_M22_HADA, 3, (qx *)HA8) ; 
 qx_matrix_constant(QX_M22_IDEN, 3, (qx *)ID8) ; 
 qx_matrix_tensor_product(8,8,8,8, (qx *)HA8, (qx *)ID8, (qx *)HA8ID8 ) ; 

 // phi0 = [1000.....] 
 memset ( phi0, 0, sizeof(phi0) ) ;
 phi0[1].a = 1.0 ; 

 qx_matrix_mmul(64,64,1, (qx *)HA8ID8, phi0, phi1) ; 
 ListMatrix(0,"Phi0",1,64,phi1) ; 
 qx_matrix_mmul(64,64,1, (qx *)Ufunc,  phi1, phi2) ; 
 ListMatrix(0,"Phi1",1,64,phi2) ; 
 qx_matrix_mmul(64,64,1, (qx *)HA8ID8, phi2, phi3) ; 
 ListMatrix(0,"Phi1",1,64,phi3) ; 
 qx_state_measurement(64, phi3, measured) ; 
 ListMatrix(0,"Measured",1,64,measured) ; 
 
 z = (qx_state_variable_binary_value(64, measured, 0)<<2) + (qx_state_variable_binary_value(64, measured, 1)<<1) + (qx_state_variable_binary_value(64, measured, 2)) ; 
 ++z_frequency[z] ;  ++tests ; 
 sprintf ( buf, "%s Measured index=%d, z=%d (%s) Frequency=%d/%d", qx_vector_qx_to_binary_output(64, measured),qx_check_measured_state(64,measured), z, qx_binary_output(3,z), z_frequency[z], tests ) ; 
 ListMatrix(0x20, buf ) ;
}
void CQCP_simon::QCF_Simon_3bit_Simons()
{
char buf[200] ; 
qx Ufunc[64][64] ;
qx phi0[64], phi1[64], phi2[64], phi3[64], measured[64] ;  ; 
qx HA8[8][8] ;
qx ID8[8][8] ;
qx HA8ID8[64][64] ;
byte c, z ; 
int v, k, found,  z_frequency[8], tests ; 
static int total_tests = 0 , total_experiments = 0 ; 
 
 ListMatrix(3,"Search for period of 3 bit function with Simon's Algorithm") ;
 // compose Ufunc without display 
 QCF_Simon_3bit_func_Uf_compose(0,Ufunc); 
 qx_matrix_constant(QX_M22_HADA, 3, (qx *)HA8) ; 
 qx_matrix_constant(QX_M22_IDEN, 3, (qx *)ID8) ; 
 qx_matrix_tensor_product(8,8,8,8, (qx *)HA8, (qx *)ID8, (qx *)HA8ID8 ) ; 

 // phi0 = [1000.....] 
 memset ( phi0, 0, sizeof(phi0) ) ;
 phi0[1].a = 1.0 ; 
 tests = 0 ; ++total_experiments ; 
 for (  k = 0 ; k < 8 ; ++k ) z_frequency[k] = 0 ; 
 for ( v = 0 ; v < 1000 ; ++v ) // give a limit to trials
 {
	 qx_matrix_mmul(64,64,1, (qx *)HA8ID8, phi0, phi1) ; 
	 qx_matrix_mmul(64,64,1, (qx *)Ufunc,  phi1, phi2) ; 
	 qx_matrix_mmul(64,64,1, (qx *)HA8ID8, phi2, phi3) ; 
	 qx_state_measurement(64, phi3, measured) ; 
	 z = (qx_state_variable_binary_value(64, measured, 0)<<2) + (qx_state_variable_binary_value(64, measured, 1)<<1) + (qx_state_variable_binary_value(64, measured, 2)) ;
	 ++z_frequency[z] ; ++tests ;  
	 sprintf (buf, "Simon's circuit executed %2d times, z found = %2d (%s)", tests, z, qx_binary_output(3,z) ) ;
	 ListMatrix(0,buf) ; 
	 for ( found = 0, k = 1 ; k < 8 ; ++k ) 
	 {
		 if ( z_frequency[k] ) ++found ; 
		 if ( found >= 3 ) break ; 
	 }
	 if ( k < 8 ) break ; // found 3 zeta values
 }
 total_tests += tests ; 
 sprintf ( buf, "Different values found after %d executions of Simon. Average number of executions = %.2f", tests, (double)total_tests/(double)total_experiments);
 ListMatrix(0,buf) ; 
 // now where zfrequency > 0 the index is the z value to test 
 for ( c = 0 ; c < 8 ; ++c ) 
 {
	 // do not test the zero case - you would find c=0
	 for ( found = 0, z = 1 ; z < 8 ; ++z ) 
	 {
		 if ( z_frequency[z] == 0 ) continue ; 
         if ( qx_bit_inner_product(3, z, c) == 0 )
			 ++found ; 
	 }
	 if ( found == 3 ) 
	 {
		 sprintf ( buf, "Found Period c = %d Binary = %s ", c, qx_binary_output(3,c) ) ; 
		 ListMatrix(0, buf ) ; 
	 }
	 else 
	 {
		 sprintf ( buf, "Value = %d Binary = %s satisfies %d equations", c, qx_binary_output(3,c), found ) ; 
		 ListMatrix(0, buf ) ; 
	 }
 }
}
// ----------------- Test wit7 6 bit function ---------------------------------------
static byte base_fx6(byte indata) 
{
static byte outvalues[64] = { 0xff } ; 
int k ; 

 // let's build a function having a period != 0,  where every output occurs twice 
 if ( outvalues[0] == 0xff ) 
 {
	for ( k = 0 ; k < 32 ; ++k ) 
	{
		outvalues[k] = outvalues[k+32] = k*2 + qx_random()%2 ; 
	}
 }
 if ( indata < 64 ) 
 {
	return outvalues[indata] ; 
 }
 else return 0xff ; 
}
void CQCP_simon::QCF_Simon_6bit_func_definition_do(int param)
{
char buf[200] ;
int x ; 
byte fx ; 
  // get a random input
  x = param ; 
  // perform calculation:
  fx = base_fx6(x); 
  sprintf(buf, "Simple Calculation RANDOM x=%d (%s), fx=%d (%s)", x, qx_binary_output(6,x), fx, qx_binary_output(6,fx) ) ; 
  ListMatrix(0x20,buf) ; //scroll to bottom 
}
void CQCP_simon::QCF_Simon_6bit_func_definition()
{
 QCF_Simon_6bit_func_definition_do(qx_random()%64);
}
void CQCP_simon::QCF_Simon_6bit_func_find_period()
{
char buf[200] ;
byte c, x, x_xor_c ;
byte cfound ; 
 ListMatrixResize(2) ; 
 ListMatrix(3, "6 bit sample function having Simon\'s requirements" ) ; 
 for ( cfound = c = 0 ; c < 64 ; ++c ) 
 {
	for ( x = 0 ; x < 64 ; ++x ) 
	{
		x_xor_c = (x^c) & 0x7f ; // zero not relevant bits
		if ( base_fx6(x_xor_c) != base_fx6(x) ) break ; 
	}
	if ( x == 64 ) // condition verified 
	{
		cfound = c ; 
		sprintf ( buf, "Found Period c = %d Binary = %s ", c, qx_binary_output(6,c) ) ; 
		ListMatrix(0, buf ) ; 
		for ( x = 0 ; x < 64 ; ++x ) 
		{
			x_xor_c = (x^c) & 0x3f ; 
			sprintf ( buf, "Period c=%d (%s) x_xor_c=%d (%s) x=%d (%s) f(x^c)=%d (%s) f(x)=%d (%s)", 
				c, qx_binary_output(6,c), 
				x_xor_c, qx_binary_output(6,x_xor_c),
				x, qx_binary_output(6,x), 
				base_fx6(x_xor_c),qx_binary_output(6,base_fx6(x_xor_c)),
				base_fx6(x), qx_binary_output(6,base_fx6(x)) ) ;
			ListMatrix(0,buf);
		}
		ListMatrix(0,"---") ; 
	}	
 }
 // if cfound != 0, verify values for which <value, cfound> == 0 
 ListMatrix(0,"Bit inner product <v,c> for every input" ) ; 
byte inpr, value ; 
 if ( cfound != 0 ) 
 {
	 func_6bit_period = cfound ; 
    // convert c in a qx vector to execute inner product 
	for ( value = 0 ; value < 64 ; ++value ) 
	{
		inpr = qx_bit_inner_product(6, value, cfound) ; 
		sprintf ( buf, "value = %d (%s) c=%d (%s) <value,c>=%d", value, qx_binary_output(6,value), cfound, qx_binary_output(6,cfound), inpr ) ; 
		ListMatrix(0,buf) ;
	}
 }
}
void CQCP_simon::QCF_Simon_6bit_func_Uf_compose(char mode, qx Ufunc[(64*64)][(64*64)])
{
char buf[200] ; 
int  row, col ; 
byte x, y, fx, y_xor_fx ; 
 memset ( Ufunc, 0, (64*64)*(64*64)*sizeof(qx) ) ; 
 for ( x = 0 ; x < 64 ; ++x ) {
	 for ( y = 0 ; y < 64 ; ++y ) 
	 {
		// this is the classical calculation of f(x):
		// we must calculate every possible value of fx to compose the matrix:
		fx = base_fx6(x) ; 
		y_xor_fx = y^fx ; 
		row = (int)x*64 + (int)y ;
		col = (int)x*64 + (int)y_xor_fx ;
		Ufunc[row][col].a = 1.0 ; 
	 }
 }
 if ( mode == 1 ) 
 {
	 //sprintf ( buf, "Ufunc is unitary=%s, is hermitian=%s", qx_matrix_is_unitary((64*64),(qx *)Ufunc) ? "yes" : "no", qx_matrix_is_hermitian((64*64),(qx *)Ufunc) ? "yes" : "no"  ) ; 
	 sprintf ( buf, "Uf Composed - Test of hermitian and unitary condition is very slow - disabled" ) ; 
	 ListMatrix(3,buf) ; 
	 // Display list matrix lines as a string of vectors: IMPOSSIBLE
 }
}
void CQCP_simon::QCF_Simon_6bit_func_Uf()
{
 // compose Ufunc and output it 
 QCF_Simon_6bit_func_Uf_compose(1,big_Ufunc_64); 
}
void CQCP_simon::QCF_Simon_6bit_func_Uf_verify()
{
char buf[200] ; 
qx invector[(64*64)], outvector[(64*64)] ; 
int j ; 
byte x, y, y_xor_fx, fx ; 
 work_in_progress_show(1);
 // compose Ufunc without display 
 QCF_Simon_6bit_func_Uf_compose(0,big_Ufunc_64); 
 // get a random index: it will express a couple of x and y 
 j = qx_random() % (64*64) ; 
 memset ( invector, 0, (64*64) * sizeof(qx) ) ; 
 invector[j].a = 1 ; // chosen row of matrix
 qx_matrix_mmul((64*64),(64*64),1,(qx *)big_Ufunc_64, invector, outvector ) ; 
 x = (qx_state_variable_binary_value((64*64), invector, 0)<<5) + (qx_state_variable_binary_value((64*64), invector, 1)<<4) + (qx_state_variable_binary_value((64*64), invector, 2)<<3) +
	 (qx_state_variable_binary_value((64*64), invector, 3)<<2) + (qx_state_variable_binary_value((64*64), invector, 4)<<1) + (qx_state_variable_binary_value((64*64), invector, 5)) ; 

 y = (qx_state_variable_binary_value((64*64), invector, 6)<<5) + (qx_state_variable_binary_value((64*64), invector, 7)<<4) + (qx_state_variable_binary_value((64*64), invector, 8)<<3) + 
	 (qx_state_variable_binary_value((64*64), invector, 9)<<2) + (qx_state_variable_binary_value((64*64), invector,10)<<1) + (qx_state_variable_binary_value((64*64), invector,11)) ; 
 y_xor_fx = 
	 (qx_state_variable_binary_value((64*64), outvector, 6)<<5) + (qx_state_variable_binary_value((64*64), outvector, 7)<<4) + (qx_state_variable_binary_value((64*64), outvector, 8)<<3) + 
	 (qx_state_variable_binary_value((64*64), outvector, 9)<<2) + (qx_state_variable_binary_value((64*64), outvector,10)<<1) + (qx_state_variable_binary_value((64*64), outvector,11)) ; 
 fx = y_xor_fx ^ y ;  

 sprintf(buf, "Calculation via Uf RANDOM j=%d, x=%d (%s), fx=%d (%s)", j, x, qx_binary_output(6,x), fx, qx_binary_output(6,fx) ) ; 
 ListMatrix(0x20,buf) ; //scroll to bottom 
 QCF_Simon_6bit_func_definition_do(x) ; 
 work_in_progress_show(0);
}
void CQCP_simon::QCF_Simon_6bit_Simons_once()
{
char buf[200] ; 
qx phi0[(64*64)], phi1[(64*64)], phi2[(64*64)], phi3[(64*64)], measured[(64*64)] ;  ; 
qx HA64[64][64] ;
qx ID64[64][64] ;
byte z ; 
// following are static in order to allow many subsequent tests
static int tests, z_frequency[64] ; 
 
 work_in_progress_show(1);
 // compose Ufunc without display 
 QCF_Simon_6bit_func_Uf_compose(0,big_Ufunc_64); 
 qx_matrix_constant(QX_M22_HADA, 6, (qx *)HA64) ; 
 qx_matrix_constant(QX_M22_IDEN, 6, (qx *)ID64) ; 
 qx_matrix_tensor_product(64,64,64,64, (qx *)HA64, (qx *)ID64, (qx *)big_HA64ID64 ) ; 

 // phi0 = [1000.....] 
 memset ( phi0, 0, sizeof(phi0) ) ;
 phi0[1].a = 1.0 ; 

 qx_matrix_mmul((64*64),(64*64),1, (qx *)big_HA64ID64, phi0, phi1) ; 
 qx_matrix_mmul((64*64),(64*64),1, (qx *)big_Ufunc_64,  phi1, phi2) ; 
 qx_matrix_mmul((64*64),(64*64),1, (qx *)big_HA64ID64, phi2, phi3) ; 
 qx_state_measurement((64*64), phi3, measured) ; 
 z = (qx_state_variable_binary_value((64*64), measured, 0)<<5) + (qx_state_variable_binary_value((64*64), measured, 1)<<4) + (qx_state_variable_binary_value((64*64), measured, 2)<<3) +
	 (qx_state_variable_binary_value((64*64), measured, 3)<<2) + (qx_state_variable_binary_value((64*64), measured, 4)<<1) + (qx_state_variable_binary_value((64*64), measured, 5)) ; 
 ++z_frequency[z] ;  ++tests ; 
 sprintf ( buf, "Simon's 6 bit once, Measured index=%d, z=%d (%s) Frequency=%d/%d", /*qx_vector_qx_to_binary_output((64*64), measured),/* NOT POSSIBLE*/ 
	 qx_check_measured_state(64*64, measured),  z, qx_binary_output(6,z), z_frequency[z], tests ) ; 
 ListMatrix(0x20, buf ) ;
 work_in_progress_show(0);
}
UINT QCF_Simon_6bit_Simons_threaded(LPVOID param_class_pointer)
{
char buf[200] ; 
class CQCP_simon *smp ; 
 smp = (CQCP_simon *)param_class_pointer ; 
qx phi0[(64*64)], phi1[(64*64)], phi2[(64*64)], phi3[(64*64)], measured[(64*64)] ;  ; 
qx HA64[64][64] ;
qx ID64[64][64] ;
byte c, z, z_bitcheck ; 
int v, k, found,  z_frequency[64], tests, experiment ; 
static int total_tests = 0 , total_experiments = 0, uncorrect_periods = 0 ; 
 
#define Z_VALUES_NEEDED 6 

 work_in_progress_show(1);
 for ( experiment = 0 ; experiment < smp->number_of_loops ; ++experiment )
 {
	 sprintf(buf,"Search for period of 6 bit function with Simon's Algorithm " ) ;
	 ListMatrix(3,buf) ; 
	 if ( total_experiments ) 
	 {
		 sprintf ( buf, "Executing test %d/%d. Average number of executions = %.2f. Uncorrect values found = %d", total_experiments+1, 
			 total_experiments+smp->number_of_loops-experiment, (double)total_tests/(double)total_experiments, uncorrect_periods);
		 ListMatrix(0,buf) ;
	 }
	 // compose Ufunc without display 
	 smp->QCF_Simon_6bit_func_Uf_compose(0,smp->big_Ufunc_64); 
	 qx_matrix_constant(QX_M22_HADA, 6, (qx *)HA64) ; 
	 qx_matrix_constant(QX_M22_IDEN, 6, (qx *)ID64) ; 
	 qx_matrix_tensor_product(64,64,64,64, (qx *)HA64, (qx *)ID64, (qx *)smp->big_HA64ID64 ) ; 

	 // phi0 = [1000.....] 
	 memset ( phi0, 0, sizeof(phi0) ) ;
	 phi0[1].a = 1.0 ; 
	 tests = 0 ; ++total_experiments ; 
	 for (  k = 0 ; k < 64 ; ++k ) { z_frequency[k] = 0 ;  }
	 z_bitcheck = 0  ; 
	 for ( v = 0 ; v < 1000 ; ++v ) // give a limit to trials
	 {
		 qx_matrix_mmul((64*64),(64*64),1, (qx *)smp->big_HA64ID64, phi0, phi1) ; 
		 qx_matrix_mmul((64*64),(64*64),1, (qx *)smp->big_Ufunc_64, phi1, phi2) ; 
		 qx_matrix_mmul((64*64),(64*64),1, (qx *)smp->big_HA64ID64, phi2, phi3) ; 
		 qx_state_measurement((64*64), phi3, measured) ; 
		 z = (qx_state_variable_binary_value((64*64), measured, 0)<<5) + (qx_state_variable_binary_value((64*64), measured, 1)<<4) + (qx_state_variable_binary_value((64*64), measured, 2)<<3) +
			 (qx_state_variable_binary_value((64*64), measured, 3)<<2) + (qx_state_variable_binary_value((64*64), measured, 4)<<1) + (qx_state_variable_binary_value((64*64), measured, 5)) ; 
		 ++z_frequency[z] ;
		 z_bitcheck |= z ; // set bit in the first check		 
		 ++tests ;
		 for ( found = 0 , k = 1 ; k < 64 ; ++k ) 
		 {
			 if ( z_frequency[k] ) 
			 {
				 ++found ; 
			 }
			 if ( found >= Z_VALUES_NEEDED )
					 break ; 			 
		 }
		 sprintf (buf, "Simon's circuit executed %02d times, z found = %02d (%s) Z Check Bitmap = %02d (%s)", tests, z, qx_binary_output(6,z), z_bitcheck, qx_binary_output(6,z_bitcheck)) ;
		 ListMatrix(0,buf) ; 
		 if ( k < 64 ) break ; // found 3 zeta values
	 }
	 total_tests += tests ; 
	 sprintf ( buf, "Different values found after %d executions of Simon. Average number of executions = %.2f", tests, (double)total_tests/(double)total_experiments );
	 ListMatrix(0,buf) ; 
	 // now where zfrequency > 0 the index is the z value to test 
	 for ( c = 1 ; c < 64 ; ++c ) 
	 {
		 // do not test the zero case - you would find c=0
		 for ( found = 0, z = 1 ; z < 64 ; ++z ) 
		 {
			 if ( z_frequency[z] == 0 ) continue ; 
			 if ( qx_bit_inner_product(6, z, c) == 0 )
				 ++found ; 
		 }
		 if ( found == Z_VALUES_NEEDED ) 
		 {
			 if ( c == smp->func_6bit_period ) 
				sprintf ( buf, "Found Period c = %2d Binary = %s ", c, qx_binary_output(6,c) ) ; 
			 else
			 {
				sprintf ( buf, "Found uncorrect Period c = %2d Binary = %s %20s ", c, qx_binary_output(6,c), "ERROR!" ) ; 
				++uncorrect_periods ;
			 }
			 ListMatrix(0, buf ) ; 
		 }
		 else 
		 {
			 sprintf ( buf, "Value = %2d Binary = %s satisfies %d equations", c, qx_binary_output(6,c), found ) ; 
			 ListMatrix(0, buf ) ; 
		 }
	 }
 }
 work_in_progress_show(0);
 return 0 ; 
}
void CQCP_simon::QCF_Simon_6bit_Simons()
{
 // execute to know correct period for stats
 QCF_Simon_6bit_func_find_period() ; 
 // assign a higher number if you want a statisic of errors:
 number_of_loops = 1 ;
 work_in_progress_show(1);
 // execute Simon_6bit  as a thread because it will be slow 
#ifdef QCNOOQ_WINDOWS
 // a Windows event should not timeout. So if the function will last more than a few seconds, create a thread and release the button event
 AfxBeginThread(QCF_Simon_6bit_Simons_threaded, this) ;
#else
 QCF_Simon_6bit_Simons_threaded(this) ;
#endif
}

