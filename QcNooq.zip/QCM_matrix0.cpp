/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020 ISBN: 9788897527541 
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// Matrix operations 0
//

#include "stdafx.h"
#include "QCM_Math.h"

extern void qx_matrix_negate( int m, int n, qx *m0, qx *mresult ) 
{
int j,k ; 
 for ( j = 0 ; j < m ; ++j ) {
   for ( k = 0 ; k < n ; ++k ) 
   {
	 mresult[(j*n)+k] = qx_negate( m0[(j*n)+k] ) ; 
   }
 }
}
extern void qx_matrix_add ( int m, int n, qx *m0, qx *m1, qx *mresult ) 
{
int j,k ; 
 for ( j = 0 ; j < m ; ++j ) {
   for ( k = 0 ; k < n ; ++k ) 
   {
	 mresult[(j*n)+k] = qx_add( m0[(j*n)+k], m1[(j*n)+k] ) ; 
   }
 }
}
extern void qx_matrix_smul ( int m, int n, qx  c0, qx *m0, qx *mresult )
{
int j,k ; 
 for ( j = 0 ; j < m ; ++j ) {
   for ( k = 0 ; k < n ; ++k ) 
   {
	 mresult[(j*n)+k] = qx_mul( c0, m0[(j*n)+k] ) ; 
   }
 }
}
extern void qx_matrix_transpose ( int m, int n, qx *m0, qx *mresult ) 
{
int j,k ; 
 for ( j = 0 ; j < m ; ++j ) {
   for ( k = 0 ; k < n ; ++k ) 
   {
	 mresult[(k*m)+j] = m0[(j*n)+k] ; 
   }
 }
}
extern void qx_matrix_conjugate ( int m, int n, qx *m0, qx *mresult ) 
{
int j,k ; 
 for ( j = 0 ; j < m ; ++j ) {
   for ( k = 0 ; k < n ; ++k ) 
   {
	 mresult[(j*n)+k] = qx_conjugate( m0[(j*n)+k] ) ; 
   }
 }
}
extern void qx_matrix_adjoint   ( int m, int n, qx *m0, qx *mresult ) 
{
int j,k ; 
 for ( j = 0 ; j < m ; ++j ) {
   for ( k = 0 ; k < n ; ++k ) 
   {
	 mresult[(k*m)+j] = qx_conjugate( m0[(j*n)+k] ) ; 
   }
 }
}
extern void qx_matrix_mmul( int m, int n, int p,  qx *m0, qx *m1, qx *mresult ) 
{
qx qx0 = {0,0};  // a complex number initialized with 0 
qx elemento ; 
int i, j,k ; 
 for ( j = 0 ; j < m ; ++j ) {
   for ( k = 0 ; k < p ; ++k )  // devo comporre la matrice m, p
   {
	   mresult[(j*p)+k] = qx0 ;  	   
	   for ( i = 0 ; i < n ; ++i ) // Columns in the first must be equal to rows in the second - parameter n 
	   {
		   // ogni membro contiene sigma dell'elemento i della riga di m0 (j riga) moltiplicato per l'elemento i della stessa colonna di m1 (j colonna)
		   // every element contains the summation of the elements i of the row in m0 (j row) multiplied for the element i of the same column in m1 (j column)
		   elemento = qx_mul( m0[(j*n)+i], m1[(i*p)+k] ) ; 
		   mresult[(j*p)+k] = qx_add(mresult[(j*p)+k], elemento ) ; 
	   }
   }
 } 
}
// per moltiplicare matrici booleane per altre matrici booleane
extern void qx_matrix_boolean_mmul( int m, int n, int p,  qx *m0, qx *m1, qx *mresult ) 
{
qx qx0 = {0,0};
qx elemento ; 
int i, j,k ; 
 for ( j = 0 ; j < m ; ++j ) {
   for ( k = 0 ; k < p ; ++k )  // devo comporre la matrice m, p
   {
	   mresult[(j*p)+k] = qx0 ;  	   
	   for ( i = 0 ; i < n ; ++i ) // Columns in the first must be equal to rows in the second - parameter n 
	   {
		   // ogni membro contiene sigma dell'elemento i della riga di m0 (j riga) moltiplicato per l'elemento i della stessa colonna di m1 (j colonna)
		   //elemento = qx_mul( m0[(j*n)+i], m1[(i*p)+k] ) ; 
		   //elemento.a = (elemento.a != 0.0 ? 1 : 0) ; 
		   elemento.a = (m0[(j*n)+i].a && m1[(i*p)+k].a) ;
		   elemento.b = 0 ; // ridondante se i dati in ingresso non sono complessi 
		   mresult[(j*p)+k].a =  ( mresult[(j*p)+k].a  || elemento.a  ) ; 
		   //mresult[(j*p)+k] = qx_add(mresult[(j*p)+k], elemento ) ; 
		   //mresult[(j*p)+k].a =  ( mresult[(j*p)+k].a != 0 || elemento.a != 0 ) ? 1 : 0 ; 
	   }
   }
 }
}

extern qx   qx_matrix_trace(int n, qx *m0) // sommatoria della diagonale principale 
{
int  k ; 
qx result = {0,0} ; 
   for ( k = 0 ; k < n ; ++k ) 
   {
	  result = qx_add(result, m0[(k*n)+k] ) ; 	 
   }
 return result ; 
}
extern void qx_matrix_tensor_product( int m, int n,  int p, int q,  qx *m0, qx *m1, qx *mresult ) 
{
int j,k, a, b, row, col  ; 

 // la matrice di destinazione avr� le dimensioni m * p, n * q
 // percorro m0 sulle sue dimensioni
 for ( j = 0 ; j < m ; ++j ) 
 {
	 for ( k = 0 ; k < n ; ++k ) 
	 {
		 for ( a = 0 ; a < p ; ++a ) // percorro m1 sulle sue dimensioni 
		 {
			 for ( b = 0 ; b < q ; ++b ) 
			 {
				 row = a +(j*p) ; 
				 col = b +(k*q) ;
				 mresult[row*(n*q) + col] = qx_mul(m0[j*n+k], m1[a*q+b]) ;
			 }
		 }
	 }
 }
}
extern BOOL qx_matrix_is_doubly_stochastic(int m, qx *m0) 
{
qx qx0 = {0,0} ; 
qx rres, cres ;
int j, k ; 

 for ( j = 0 ; j < m ; ++j ) 
 {
	 rres = cres = qx0 ; 
	 for ( k = 0 ; k < m ; ++k ) 
	 {
		 rres = qx_add( rres, m0[(j*m)+k] ) ;
		 cres = qx_add( cres, m0[(k*m)+j] ) ;
	 }
	 // assumiamo che B sia insignificante e lo abbiamo portato solo a spasso a zero 
	 if ( ! qx_double_equal_enough(rres.a,1.0) || rres.b != 0.0 ) 
		 return FALSE ; 
	 if ( ! qx_double_equal_enough(cres.a,1.0) || cres.b != 0.0 ) 
		 return FALSE ; /**/
 }
 return TRUE ; 
}
extern BOOL qx_matrix_is_hermitian(int m, qx *m0) 
{
int j, k ; 

 for ( j = 0 ; j < m ; ++j ) 
 {
	 for ( k = 0 ; k < m ; ++k ) {
		 if ( k == j ) continue ; 
		 if ( ! qx_complex_equal_enough(m0[(k*m)+j], qx_conjugate(m0[(j*m)+k])) ) 
			 return FALSE ; 
	 }
 }
 return TRUE ; 
}
extern BOOL qx_matrix_is_unitary(int m, qx *m0) 
{
qx qx0 = {0.0,0.0} ;
qx qx1 = {1.0,0.0} ;
qx item1, somma ;
qx elemento ; 
int i, j,k ; 
int n = m, p = m ; // per leggibilit� 

 for ( j = 0 ; j < m ; ++j ) {
   for ( k = 0 ; k < p ; ++k )  // devo comporre la matrice m, p
   {
	   //mresult[(j*p)+k] = qx0 ; // qui andrebbe accumulato il risultato se ci fosse la moltiplicazione in output
	   somma = qx0 ; 
	   for ( i = 0 ; i < n ; ++i ) // Columns in the first must be equal to rows in the second - parameter n 
	   {
		   // ogni membro contiene sigma dell'elemento i della riga di m0 (j riga) moltiplicato per l'elemento i della stessa colonna di m1 (j colonna)
		   //elemento = qx_mul( m0[(j*n)+i], m1[(i*p)+k] ) ; // questa sarebbe per la moltiplicazione  
		   //mresult[(j*p)+k] = qx_add(mresult[(j*p)+k], elemento ) ; // accumulerebbe la somma nella matrice risultato 
		   //item1 = m1[(i*p)+k] ; // sarebbe quello da sommare, solo che la matrice m1 � stata trasposta, quindi 
		   item1 = qx_conjugate ( m0[(k*p)+i] ) ; // questo � quello da prendere, ma conjugato 
		   elemento = qx_mul( m0[(j*n)+i], item1 ) ; 
		   somma = qx_add(somma, elemento) ; 
	   }
		 if ( j == k ) 
		 {
			 if ( ! qx_complex_equal_enough(somma,qx1) ) 
				return FALSE ; 
		 }
		 else
		 {
			 if ( ! qx_complex_equal_enough(somma,qx0) ) 
				return FALSE ; 
		 }
   }
 }
 return TRUE ; 
}
