/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// QCP_tools.cpp: tools for OUTPUT. Qutside Windows MFC implement your  own version of global_ListMatrix() to display output
//

#include "stdafx.h"
#include "QcNooq.h"
#include "math.h"      // standard C math definition     
#include "QCM_math.h"  // portable definitions 
#include "QCM_tools.h"


#ifdef QCNOOQ_WINDOWS
#include "QcNooqDlg.h"
extern CQcNooqDlg CQcNooqDlg_dlg;
// calls for output - to be remapped if environment different than Windows Visual Studio C++
/* parameters of ListMatrix() are:
char init: bitmap, if bit 0 is set (value=1), clear screen; if bit 1 is set (value=2), insert a separation line
char *comment: a text comment
int mrow, int ncol: size of complex matrix to be displayed (optional)
qx *mtr: address of complex matrix to be displayed (optional)
int hexacomment: a decimal number to be displayed oin binary format (optional)

global_ListMatrix() outputs to a box of text lines (type CListBox) and a box of text lines and columns (type CListCtrl).
If you want compile the code in a different environment, rewrite global_ListMatrix() redirecting the output where needed
*/

void ListMatrixResize ( char mode ) 
{
CRect   messages_new, matrix_new ; 
 if ( CQcNooqDlg_dlg.messages_rect.right == 0 ) // first call
 {
	 CQcNooqDlg_dlg.m_messages.GetWindowRect(&CQcNooqDlg_dlg.messages_rect) ; 
	 CQcNooqDlg_dlg.m_matrix_0.GetWindowRect(&CQcNooqDlg_dlg.matrix_rect) ; 
	 CQcNooqDlg_dlg.ScreenToClient(&CQcNooqDlg_dlg.messages_rect) ; 
	 CQcNooqDlg_dlg.ScreenToClient(&CQcNooqDlg_dlg.matrix_rect) ; 
 }
 switch ( mode ) 
 {
 default:
 case 0:
	 messages_new = CQcNooqDlg_dlg.messages_rect ; 
	 matrix_new = CQcNooqDlg_dlg.matrix_rect ; 
	 CQcNooqDlg_dlg.m_messages.MoveWindow(&messages_new,1) ; 
	 CQcNooqDlg_dlg.m_matrix_0.MoveWindow(&matrix_new,1) ; 
	 break ; 
 case 1: // matrix half size
	 messages_new = CQcNooqDlg_dlg.messages_rect ; 
	 matrix_new = CQcNooqDlg_dlg.matrix_rect ; 
	 matrix_new.top = CQcNooqDlg_dlg.matrix_rect.bottom - (CQcNooqDlg_dlg.matrix_rect.bottom-CQcNooqDlg_dlg.matrix_rect.top)/2 ; 
	 messages_new.bottom = matrix_new.top - 4 ;
	 CQcNooqDlg_dlg.m_messages.MoveWindow(&messages_new,1) ; 
	 CQcNooqDlg_dlg.m_matrix_0.MoveWindow(&matrix_new,1) ; 
	 break ; 
 case 2: // small
	 messages_new = CQcNooqDlg_dlg.messages_rect ; 
	 matrix_new = CQcNooqDlg_dlg.matrix_rect ; 
	 matrix_new.top = CQcNooqDlg_dlg.matrix_rect.bottom - 2 ; 
	 messages_new.bottom = matrix_new.top - 2 ;
	 CQcNooqDlg_dlg.m_messages.MoveWindow(&messages_new,1) ; 
	 CQcNooqDlg_dlg.m_matrix_0.MoveWindow(&matrix_new,1) ; 
	 break ; 
 }
}
extern void ListMatrixColumnView(int c1, int c2)
{
CHeaderCtrl* pHeader;
int k, w1, ncol, evi ;
RECT rettangolo ;
 if ((pHeader = CQcNooqDlg_dlg.m_matrix_0.GetHeaderCtrl()) == NULL) return ;
 ncol = pHeader->GetItemCount();
 CQcNooqDlg_dlg.m_matrix_0.GetWindowRect(&rettangolo) ; w1 = (rettangolo.right-rettangolo.left)-4 ;  // un pochino meno per non fare apparire la barra scorrimento sotto
 evi = (c2-c1)+2; w1/=2 ; 
 if ( evi >= ncol ) return ; 
 for ( k = 0 ; k < ncol ; ++k ) 
 {
	 if ( (k >= c1 && k <= c2) ) CQcNooqDlg_dlg.m_matrix_0.SetColumnWidth(k,w1/evi) ; 
	 else if ( k == ncol-1 ) CQcNooqDlg_dlg.m_matrix_0.SetColumnWidth(k,2*w1/evi) ; 
	 else  CQcNooqDlg_dlg.m_matrix_0.SetColumnWidth(k,w1/(ncol-evi)) ; 
 }
}
/*
** init parameter:
** Bit 01: clear upper screen (messages)
** Bit 02: clear lower screen (matrix)
** Bit 04: put an empty line after output
** Bit 08: disable output
** Bit 10: enable output
** Bit 20: scroll matrix to bottom
*/
void ListMatrix(char init, char *comment) 
{ 
 global_ListMatrix(&CQcNooqDlg_dlg.m_messages, &CQcNooqDlg_dlg.m_matrix_0, init, comment, 0,0,NULL, 0); 
}
void ListMatrix(char init, char *comment, int mrow, int ncol, qx *mtr ) 
{
 global_ListMatrix(&CQcNooqDlg_dlg.m_messages, &CQcNooqDlg_dlg.m_matrix_0, init, comment, mrow, ncol, mtr, 0 ) ; 
}
void ListMatrix(char init, char *comment, int mrow, int ncol, qx *mtr, int hexacomment ) 
{
 global_ListMatrix(&CQcNooqDlg_dlg.m_messages, &CQcNooqDlg_dlg.m_matrix_0, init, comment, mrow, ncol, mtr, hexacomment ) ;  
}


#define COLLARGA(x) (strlen(x)*8)
extern void lix_larghezza_colonne (  CListCtrl *lixp, int zerowid, int headerwid );
extern void lix_larghezza_colonne (  CListCtrl *lixp, int zerowid, int headerwid, BOOL aggiusta_header_wid );
void global_ListMatrix(CListBox *messap, CListCtrl *mcp,  char bitmap_mode, char *commento, int mrow, int ncol, void *mtr_source, int hexacomment ) 
{
qx *mtr = (qx *)mtr_source ; 
char buf[100] ;
static int num = 0 ; 
int j, k  ; 
CHeaderCtrl* pHeader;
static char output_enabled =  1; 

 if ( bitmap_mode & 0x08 ) { output_enabled = 0; return ; }
 if ( bitmap_mode & 0x10 ) { output_enabled = 1; return ; }
 if ( ! output_enabled ) return ; 

 if ( bitmap_mode & 0x03 ) {                  // bit 1,2: clear screen
	 if ( bitmap_mode & 0x01 )messap->ResetContent() ; 
	 if ( bitmap_mode & 0x02 )
	 {
		 mcp->DeleteAllItems() ; 
		 if ((pHeader = mcp->GetHeaderCtrl()) != NULL)
		 {
			num = pHeader->GetItemCount(); 
			for ( k = num-1 ; k >= 0 ; --k ) mcp->DeleteColumn(k) ;
		 }
		 for ( k = 0 ; k < ncol ; ++k ) 
		 {
			sprintf ( buf, "%d", k ) ; 
			mcp->InsertColumn( k, buf    , LVCFMT_CENTER,    COLLARGA(buf)*10,-1 ) ;	
		 }
		 if ( k )
		 {
			 sprintf ( buf, "%d", k ) ; 
			 mcp->InsertColumn( k, buf    , LVCFMT_LEFT,    COLLARGA(buf)*10,-1 ) ;	
		 }
		 num = 0 ; // nessuna riga inserita
	 }
 }
 else 
 {
	 if ((pHeader = mcp->GetHeaderCtrl()) != NULL)
	 {
		j = pHeader->GetItemCount(); 
		if ( j < ncol+1 ) 
		{
			 for ( k = j ; k < ncol ; ++k ) 
			 {
				sprintf ( buf, "%d", k ) ; 
				mcp->InsertColumn( k, buf    , LVCFMT_CENTER,    COLLARGA(buf)*10,-1 ) ;	
			 }
			 sprintf ( buf, "%d", k ) ; 
			 mcp->InsertColumn( k, buf   , LVCFMT_LEFT,    COLLARGA(buf)*10,-1 ) ;	
		}
	 }
 }
 if ( mrow == 0 || ncol == 0 )  messap->AddString(commento) ;

 for ( j = 0 ; j < mrow ; ++j ) 
 {	 
	 for ( k = 0 ; k < ncol ; ++k ) 
	 {
		 sprintf ( buf, "%s", qx_format(mtr[(j*ncol)+k]) ) ; 
		 if ( k == 0 ) num = mcp->InsertItem(LVIF_TEXT|LVIF_STATE, num+1, buf ,  0, 0, 0, 0);
		 else mcp->SetItemText(num,k,buf) ; 
	 }
	 if ( hexacomment ) 
	 {
		 CString binary ;
		 int mask = 1;
 		 for(int i = 0; i < hexacomment; ++i)
		 {
			if((mask&j) >= 1)
				binary = "1"+binary;
			else
				binary = "0"+binary;
			mask<<=1;
		 }
		 sprintf ( buf, "%04x %s %s", j, binary,commento ) ;
		 mcp->SetItemText(num,k,buf) ; 
	 }
	 else if ( j == 0 ) mcp->SetItemText(num,k,commento) ; 
 }
 // bit 4: put a separation line
 if ( (bitmap_mode & 0x04) ) num = mcp->InsertItem(LVIF_TEXT|LVIF_STATE, num+1, "----" ,  0, 0, 0, 0);
 if ( ncol ) lix_larghezza_colonne(mcp, -1,-1) ; 
 if ( (bitmap_mode & 0x20) ) // bit 20: scroll to bottom
 {
/* CSize sz ; 
		sz.cx = -1 ;
		sz.cy = -1 ;
//		sz = messap->ApproximateViewRect(  sz,   ) ; // cos� per scrollare all'ultima riga del lix
		messap->Scroll(sz) ; 
/**/	
	 messap->SetTopIndex(messap->GetCount()-1) ; // scroll messages to bottom line 
 }
}

extern void lix_larghezza_colonne (  CListCtrl *lixp, int zerowid, int headerwid ){lix_larghezza_colonne (lixp, zerowid, headerwid, TRUE) ;}
extern void lix_larghezza_colonne (  CListCtrl *lixp, int zerowid, int headerwid, BOOL aggiusta_header_wid )
{
int k, ncol, variabili, primavar, w1, w2, wm, wtot ;
CHeaderCtrl* pHeader;
RECT rettangolo ;
	
	if (lixp == NULL) return ;

    // per conoscere il numero di colonne, occorre conoscere il numero di item nello header
	if ((pHeader = const_cast<CListCtrl*>(lixp)->GetHeaderCtrl()) == NULL) return ;
	ncol = pHeader->GetItemCount();

    wtot = k = 0 ;
    if ( zerowid >= 0 )        for (  ; k <= zerowid ; ++k )   { lixp->SetColumnWidth(k,0) ; wtot += lixp->GetColumnWidth(k) ; }
    if ( headerwid > zerowid ) for (  ; k <= headerwid ; ++k ) { if (aggiusta_header_wid) lixp->SetColumnWidth(k,LVSCW_AUTOSIZE_USEHEADER) ;
                                                                 wtot += lixp->GetColumnWidth(k) ; }
    if ( ncol <= headerwid ) return ;
    for (  variabili = 0, primavar = k ; k < ncol ;       ++k )
    {
        lixp->SetColumnWidth(k,LVSCW_AUTOSIZE_USEHEADER) ; w1 = lixp->GetColumnWidth(k) ;
        lixp->SetColumnWidth(k,LVSCW_AUTOSIZE) ;           w2 = lixp->GetColumnWidth(k) ;
        if ( w1 > w2 )
        {
            lixp->SetColumnWidth(k,LVSCW_AUTOSIZE_USEHEADER) ; wtot += w1 ;
        }
        else wtot += w2 ;
        ++variabili ;
    }
    // adesso mi aggiusto alla larghezza disponibile effettivamente
    lixp->GetWindowRect(&rettangolo) ; w1 = (rettangolo.right-rettangolo.left) ;
    if ( w1 < wtot )
    {
       w2 = ((wtot-w1) / (variabili)) ;  // quantum in pi� (spessore della separazia tra colonne ?) da regolare empiricamente
       wm = ((wtot-w1) % (variabili)) ;  // tenere esatto conto del resto
       for ( k = primavar ; k < ncol ; ++k )
       {
           lixp->SetColumnWidth(k, lixp->GetColumnWidth(k)-(w2+wm) ) ;
           if ( wm ) --wm ; // quando a zero basta, ha fatto il suo dovere
       }
    }
}
#else
extern void work_in_progress_show(int) 
{
	// implement display work in progress duration
}
void ListMatrixResize ( char mode ) 
{
	// implement display resize
}
extern void ListMatrixColumnView(int c1, int c2)
{
	// implement column view resize
}
void ListMatrix(char init, char *comment) 
{ 
 global_ListMatrix(NULL, NULL, init, comment, 0,0,NULL, 0); 
}
void ListMatrix(char init, char *comment, int mrow, int ncol, qx *mtr ) 
{
 global_ListMatrix(NULL, NULL, init, comment, mrow, ncol, mtr, 0 ) ; 
}
void ListMatrix(char init, char *comment, int mrow, int ncol, qx *mtr, int hexacomment ) 
{
 global_ListMatrix(NULL, NULL, init, comment, mrow, ncol, mtr, hexacomment ) ;  
}
// This is the function to be developed for more rich output in an environment other than Windows:
void global_ListMatrix(void *messap, void *mcp,  char bitmap_mode, char *comment, int mrow, int ncol, void *mtr_source, int hexacomment ) 
{
char buf[100] ; 
qx *mtr = (qx *)mtr_source ; 
int j, k; 
 printf ( "%s\n", comment) ;
 for ( j = 0 ; j < mrow ; ++j ) 
 {
	 for ( k = 0 ; k < ncol ; ++k ) 
	 {
		sprintf ( buf, "%s", qx_format(mtr[(j*ncol)+k]) ) ; 
		printf ( buf ) ; 
	 }
	 if ( j == 0 ) printf(comment) ; 
	 printf ( "\n") ; 
 }
}
#endif