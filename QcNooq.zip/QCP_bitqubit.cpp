/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// QCP_bitqubit.cpp : implementation file. Drills for Chapter 4 of "Quantum Computing for Programmers and Investors"
//

#include "stdafx.h"
#include "QcNooq.h"

#include "math.h"      // standard C math definition     
#include "QCM_math.h"  // portable definitions 
#include "QCM_tools.h"

#include "QCP_bitqubit.h"


// CQCP_bitqubit dialog
#ifdef QCNOOQ_WINDOWS
IMPLEMENT_DYNAMIC(CQCP_bitqubit, CDialog)

CQCP_bitqubit::CQCP_bitqubit(CWnd* pParent /*=NULL*/) : CDialogML(CQCP_bitqubit::IDD, pParent)
{
}
CQCP_bitqubit::~CQCP_bitqubit()
{
}
BOOL CQCP_bitqubit::Create(CWnd* pParent)
{
	if (!CDialogML::Create(CQCP_bitqubit::IDD, pParent))
	{
		return FALSE;
	}
	return TRUE;
}
void CQCP_bitqubit::OnCancel() {DestroyWindow(); theApp.windows_semaphore=0;}
void CQCP_bitqubit::DoDataExchange(CDataExchange* pDX)
{
	CDialogML::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC00, m_static00);
	DDX_Control(pDX, IDC_measurement_test, m_A);
	DDX_Control(pDX, IDC_measurement_test_loop, m_B);
	DDX_Control(pDX, IDC_ket_normalization, m_C);
	DDX_Control(pDX, IDC_ket_simple_action, m_D);
	DDX_Control(pDX, IDC_ket_2bit_action, m_E);
	DDX_Control(pDX, IDC_ket_2bit_action_measured, m_F);
}
BEGIN_MESSAGE_MAP(CQCP_bitqubit, CDialogML)
	ON_BN_CLICKED(IDC_measurement_test, &CQCP_bitqubit::QCF_measurement_test)
	ON_BN_CLICKED(IDC_measurement_test_loop, &CQCP_bitqubit::QCF_measurement_test_loop)
	ON_BN_CLICKED(IDC_ket_normalization, &CQCP_bitqubit::QCF_ket_normalization)
	ON_BN_CLICKED(IDC_ket_simple_action, &CQCP_bitqubit::QCF_ket_simple_action_1_qubit)
	ON_BN_CLICKED(IDC_ket_2bit_action, &CQCP_bitqubit::QCF_ket_action_on_2_qubits)
	ON_BN_CLICKED(IDC_ket_2bit_action_measured, &CQCP_bitqubit::QCF_ket_action_2_bit_measured)
END_MESSAGE_MAP()
void CQCP_bitqubit::OnOK(){};
BOOL CQCP_bitqubit::OnInitDialog()
{
	CDialogML::OnInitDialog();
	ListMatrixResize(0); // give appropriate sizes
	return TRUE;  // return TRUE  unless you set the focus to a control
}
#endif
// CQCP_bitqubit message handlers
static int sampling_cnt = 0 ; 
void CQCP_bitqubit::execute_measurement_test(int cycles)
{
char buf[100] ;
// you can test several cases. 
// Simple case with probabilities = {4/14, 0, 9/14, 1/14}. 
#define  NUM_CASES 4
qx state[NUM_CASES] = {{2,0}, {0,0}, {3,0}, {1,0}} ; char *case_description = "Real probabilties, total = 2*2+0+3*3+1 = 14" ; 
/**/
/* // In this case the non zero values have the same probability
#define  NUM_CASES 8
qx state[NUM_CASES] = { {15,0}, {15,0}, {0,0}, {0,0}, {15,0}, {15,0}, {0,0}, {0,0} }; char *case_description = "Real probabilties, alle the same" ; 
/**/
/* // In this case values 0 and 1 have probability = 225, 4 and 5 have 900, 7 has 100 (the probability is the squared module, remember!)
#define  NUM_CASES 8
qx state[NUM_CASES] = { {15,0}, {15,0}, {0,0}, {0,0}, {30,0}, {30,0}, {0,0}, {10,0} }; char *case_description = "Real probabilties summing 100" ; 
/**/
// Other chances:
/* #define  NUM_CASES 8
qx state[NUM_CASES] = { {3,0}, {2,0}, {1,0}, {0,0}, {4,0}, {5,0}, {4,0}, {3,0} }; char *case_description = "Real probabilties with any sum" ;
/**/
/* 
#define  NUM_CASES 8
qx state[NUM_CASES] = { {3,1}, {2,0}, {1,-1}, {0,0}, {4,-2}, {5,2}, {4,1}, {3,3} }; char *case_description = "Complex probabilties with any sum" ;
/**/
qx measured[NUM_CASES] ;
static qx counters[NUM_CASES] ; // preserve for next measurement
int c0, c1 , k ;
int lim0, lim1 ;
if ( cycles < 100 ) { lim0 = cycles ; lim1 = 1 ; }
else               { lim0 = cycles/100 ; lim1 = 100 ; }  

 ListMatrix(0, case_description ) ; 
 for ( c0 = 0 ; c0 < lim0 ; ++c0 )
 {
	 for ( c1 = 0 ; c1 < lim1 ; ++c1 ) 
	 {
		 if ( qx_state_measurement(NUM_CASES, state, measured ) == TRUE ) 
		 {
			k = qx_check_measured_state(NUM_CASES, measured ) ;
			if ( k >= 0 ) 
			{
				++counters[k].a ; 
				++sampling_cnt ;
			}
			else ListMatrix(0,"NOT MEASURED - output vector is not a binary state", 1,NUM_CASES, measured) ; 
		 }
		 else ListMatrix(0,"NOT MEASURED - Incorrect values", 1,NUM_CASES, measured) ; 
	 }
	 // otuput at the end of the inner cycle
	 ListMatrix(0,"Measured", 1,NUM_CASES, measured) ; 				
 }
 ListMatrix(0,"Counters", 1,NUM_CASES, counters) ; 	
 sprintf ( buf, "Total samplings done = %d", sampling_cnt ) ; ListMatrix(0,buf) ; 
}
void CQCP_bitqubit::QCF_measurement_test() { execute_measurement_test(1) ; }
void CQCP_bitqubit::QCF_measurement_test_loop(){ execute_measurement_test(1000) ; }

void CQCP_bitqubit::QCF_ket_normalization()
{
char buf[200] ; 
qx psi[4] = { {5,2}, {7}, {0,4}, {3,2} } ;
qx psinormal[4] ; 
double msq = qx_vector_moduli_squared_sum(4, psi) ; 
qx inverse_length ; 
 sprintf ( buf, "Vector modulus squared before normalization=%f", msq ) ; 
 ListMatrix(3, buf ) ;  
 inverse_length.a = 1/sqrt(msq) ; inverse_length.b = 0 ; 
 qx_vector_smul(4, inverse_length, psi, psinormal ) ; 
 ListMatrix(0, "psi to normalize", 1,4, psi ) ; 
 ListMatrix(0, "psi normalized", 1,4, psinormal ) ; 
 msq = qx_vector_moduli_squared_sum(4, psinormal) ; 
 sprintf ( buf, "Vector modulus squared after normalization=%f", msq ) ; 
 ListMatrix(0, buf ) ;  
}

void CQCP_bitqubit::QCF_ket_simple_action_1_qubit()
{
char buf[200] ; 
qx psi0[2] = { {1}, {0} } ;
qx psi1[2] ; 
qx psi2[2] ; 
qx Hadamard[2][2] ; 
BOOL Hadamard_is_unitary, Hadamard_is_hermitian ;
 
 // build Hadamard matrix
 qx_matrix_constant(QX_M22_HADA, (qx *)Hadamard) ; 
 // verify Hadamard matrix properties
 Hadamard_is_unitary = qx_matrix_is_unitary(2, (qx *)Hadamard )  ;
 Hadamard_is_hermitian = qx_matrix_is_hermitian(2, (qx *)Hadamard )  ;
 sprintf ( buf, "Hadamard[2] matrix is unitary=%s, is hermitian=%s", Hadamard_is_unitary ? "yes" : "no", Hadamard_is_hermitian ? "yes" : "no"  ) ; 
 ListMatrix(7, buf, 2,2, (qx *)Hadamard )  ;
 ListMatrix(0, "Initial state, bit value = 0", 1,2, psi0 )  ;
 // act on psi
 qx_matrix_mmul(2,2,1, (qx *)Hadamard, (qx *)psi0, (qx *)psi1) ; 
 ListMatrix(0, "Transformed state", 1,2, psi1 )  ;
 qx_matrix_mmul(2,2,1, (qx *)Hadamard, (qx *)psi1, (qx *)psi2) ; 
 ListMatrix(4, "Reversed transformed state", 1,2, psi2 )  ;
 
 // now change value of psi
 psi0[0].a = 0; psi0[1].a = 1 ; 
 ListMatrix(0, "Initial state, bit value = 1", 1,2, psi0 )  ;
 qx_matrix_mmul(2,2,1, (qx *)Hadamard, (qx *)psi0, (qx *)psi1) ; 
 ListMatrix(0, "Transformed state", 1,2, psi1 )  ;
 qx_matrix_mmul(2,2,1, (qx *)Hadamard, (qx *)psi1, (qx *)psi2) ; 
 ListMatrix(0, "Reversed transformed state", 1,2, psi2 )  ;
}
void CQCP_bitqubit::QCF_ket_action_on_2_qubits()
{
char buf[200] ; 
qx qubit_x[2], qubit_y[2] ; 
qx psi0[4] ; 
qx psi1[4] ; 
qx psi2[4] ; 
qx Hadamard2[2][2] ; 
qx Hadamard4[4][4] ; 
int x, y, k ;
BOOL Hadamard_is_unitary, Hadamard_is_hermitian ; // verifications

 qx_matrix_constant(QX_M22_HADA, (qx *)Hadamard2 ) ; 
 qx_matrix_tensor_product(2,2,2,2, (qx *)Hadamard2, (qx *)Hadamard2, (qx *)Hadamard4 ) ; 
 Hadamard_is_unitary = qx_matrix_is_unitary(4, (qx *)Hadamard4 )  ;
 Hadamard_is_hermitian = qx_matrix_is_hermitian(4, (qx *)Hadamard4 )  ;
 sprintf ( buf, "Hadamard matrix[4] is unitary=%s, is hermitian=%s", Hadamard_is_unitary ? "yes" : "no", Hadamard_is_hermitian ? "yes" : "no"  ) ; 
 ListMatrix(7, buf, 4,4, (qx *)Hadamard4 )  ;
 
 for ( x = 0 ; x <= 1 ; ++x ) 
 { 
    // initialize qubit x
	for ( k = 0 ; k < 2 ; ++k ) qubit_x[k].a = qubit_x[k].b = 0.0 ; 
    qubit_x[x].a = 1.0 ;
	for ( y = 0 ; y <= 1 ; ++y ) 
	{
		// initialize qubit y 
		for ( k = 0 ; k < 2 ; ++k ) qubit_y[k].a = qubit_y[k].b = 0.0 ; 
		qubit_y[y].a = 1.0 ;
		// inizialize input vector representing the state of 2 qubits
		qx_matrix_tensor_product(1,2,1,2, qubit_x, qubit_y, psi0 ) ; 
		sprintf ( buf, "Initial state, input vector with x=%d, y=%d", x, y ) ; 
		ListMatrix(0, buf, 1,4, psi0 ) ; 
		qx_matrix_mmul(4,4,1, (qx *)Hadamard4, (qx *)psi0, (qx *)psi1) ; 
	    ListMatrix(0, "Transformed state", 1,4, psi1 )  ;
		qx_matrix_mmul(4,4,1, (qx *)Hadamard4, (qx *)psi1, (qx *)psi2) ; 
		ListMatrix(4, "Second transformed state", 1,4, psi2 )  ;
	}
 }
}
void CQCP_bitqubit::QCF_ket_action_2_bit_measured()
{
char buf[200] ; 
qx qubit_x[2] = {{1}, {0}}; // initial state 0 
qx qubit_y[2] = {{1}, {0}}; 
qx psi0[4] ; 
qx psi1[4] ; 
qx measured[4] ; 
qx Hadamard2[2][2] ; 
qx Hadamard4[4][4] ; 
char measured_x, measured_y ;

 qx_matrix_constant(QX_M22_HADA, (qx *)Hadamard2 ) ; 
 qx_matrix_tensor_product(2,2,2,2, (qx *)Hadamard2, (qx *)Hadamard2, (qx *)Hadamard4 ) ; 
 ListMatrix(7, "Hadamard [4]", 4,4, (qx *)Hadamard4 )  ;

 // inizialize input vector representing the state of 2 qubits
 qx_matrix_tensor_product(1,2,1,2, qubit_x, qubit_y, psi0 ) ; 
 sprintf ( buf, "Initial state, input vector with x=0, y=0" ) ; 
 ListMatrix(0, buf, 1,4, psi0 ) ; 

 qx_matrix_mmul(4,4,1, (qx *)Hadamard4, (qx *)psi0, (qx *)psi1) ; 
 ListMatrix(0, "Transformed state", 1,4, psi1 )  ;

 if ( qx_state_measurement(4, psi1, measured ) == TRUE ) 
 {
    if ( qx_check_measured_state(4, measured) < 0 )
	{
		ListMatrix(0, "Attention: some thing went wrong! Check software." );
	}
	ListMatrix(0, "The measurement will change executing the test more times - try it!" );
	measured_x = qx_state_variable_binary_value(4, measured, 0 ) ; 
	measured_y = qx_state_variable_binary_value(4, measured, 1 ) ; 
	sprintf ( buf, "After measurement, x=%d, y=%d", measured_x, measured_y ) ; 
	ListMatrix(0, buf, 1,4, measured )  ;
 }
 else ListMatrix(0, "Measurement error"  )  ;
}
