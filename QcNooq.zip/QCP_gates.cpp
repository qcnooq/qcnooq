/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020 ISBN: 9788897527541 
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// QCP_gates.cpp : implementation file. Drills for Chapter 5 of "Quantum Computing for Programmers and Investors"
//

#include "stdafx.h"
#include "QcNooq.h"

#include "math.h"      // standard C math definition     
#include "QCM_math.h"  // portable definitions 
#include "QCM_tools.h"

#include "QCP_gates.h"


// CQCP_gates dialog
#ifdef QCNOOQ_WINDOWS
IMPLEMENT_DYNAMIC(CQCP_gates, CDialog)

CQCP_gates::CQCP_gates(CWnd* pParent /*=NULL*/)	: CDialogML(CQCP_gates::IDD, pParent)
{
}
CQCP_gates::~CQCP_gates()
{
}
BOOL CQCP_gates::Create(CWnd* pParent)
{
	if (!CDialogML::Create(CQCP_gates::IDD, pParent))
	{
		return FALSE;
	}
	return TRUE;
}
void CQCP_gates::OnCancel() {DestroyWindow(); theApp.windows_semaphore=0;}
void CQCP_gates::DoDataExchange(CDataExchange* pDX)
{
	CDialogML::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC00, m_static00);
	DDX_Control(pDX, IDC_STATIC01, m_static01);
	DDX_Control(pDX, IDC_STATIC02, m_static02);
	DDX_Control(pDX, IDC_STATIC03, m_static03);
	DDX_Control(pDX, IDC_gate_NOT, m_NOT);
	DDX_Control(pDX, IDC_gate_AND, m_AND);
	DDX_Control(pDX, IDC_gate_OR, m_OR);
	DDX_Control(pDX, IDC_gateXOR, m_XOR);
	DDX_Control(pDX, IDC_gateNAND, m_NAND);
	DDX_Control(pDX, IDC_gate_composed, m_C);
	DDX_Control(pDX, IDC_gate_controlled_NOT, m_D);
	DDX_Control(pDX, IDC_gate_Toffoli, m_E);
	DDX_Control(pDX, IDC_gate_misc_a, m_misc_a);
}
BEGIN_MESSAGE_MAP(CQCP_gates, CDialogML)
	ON_BN_CLICKED(IDC_gate_NOT, &CQCP_gates::QCF_gate_NOT)
	ON_BN_CLICKED(IDC_gate_AND, &CQCP_gates::QCF_gate_AND)
	ON_BN_CLICKED(IDC_gate_OR, &CQCP_gates::QCF_gate_OR)
	ON_BN_CLICKED(IDC_gateXOR, &CQCP_gates::QCF_gate_XOR)
	ON_BN_CLICKED(IDC_gateNAND, &CQCP_gates::QCF_gate_NAND)
	ON_BN_CLICKED(IDC_gate_composed, &CQCP_gates::QCF_gate_composed)
	ON_BN_CLICKED(IDC_gate_controlled_NOT, &CQCP_gates::QCF_gate_controlled_NOT)
	ON_BN_CLICKED(IDC_gate_Toffoli, &CQCP_gates::QCF_gate_Toffoli)
	ON_BN_CLICKED(IDC_gate_misc_a, &CQCP_gates::QCF_gate_misc_a)
END_MESSAGE_MAP()
void CQCP_gates::OnOK(){};
BOOL CQCP_gates::OnInitDialog()
{
	CDialogML::OnInitDialog();
	ListMatrixResize(0); // give appropriate sizes
	return TRUE;  // return TRUE  unless you set the focus to a control
}
#endif

// CQCP_gates message handlers

void CQCP_gates::QCF_gate_NOT()
{
char buf[200] ; 
qx NOT_gate[2][2] = { {{0},{1}}, 
                      {{1},{0}} };
qx bit_0[2] = {{1},{0}} ;
qx bit_1[2] = {{0},{1}} ; 
qx not_bit[2] ; 
int k ; 

 ListMatrix(3, "Test NOT gate in two cases" ) ;
 qx_matrix_mmul(2,2,1, (qx *)NOT_gate, bit_0, not_bit ) ; 
 k = qx_state_variable_binary_value(2, not_bit, 0 ) ; 
 sprintf (buf, "NOT |0>, result=%d", k ) ; 
 ListMatrix(0,buf, 1,2, not_bit) ; 

 qx_matrix_mmul(2,2,1, (qx *)NOT_gate, bit_1, not_bit ) ; 
 k = qx_state_variable_binary_value(2, not_bit, 0 ) ; 
 sprintf (buf, "NOT |1>, result=%d", k ) ; 
 ListMatrix(0, buf, 1,2, not_bit) ; 
}

void CQCP_gates::classical_gates_test(char *description, qx *classical_gate ) 
{
char buf[200] ; 
qx bit_0[2]  ;   
qx bit_1[2]  ; 
qx phi0 [4] ;
qx RESULT_phi[2] ;
int x, y, k ;

 sprintf ( buf,"Test %s gate in four cases", description ) ; 
 ListMatrix(3, buf) ; 
 for ( x = 0 ; x <= 1 ; ++x ) 
 { 
    // initialize qubit x
	for ( k = 0 ; k < 2 ; ++k ) bit_0[k].a = bit_0[k].b = 0.0 ; 
    bit_0[x].a = 1.0 ;
	for ( y = 0 ; y <= 1 ; ++y ) 
	{
		// initialize qubit y 
		for ( k = 0 ; k < 2 ; ++k ) bit_1[k].a = bit_1[k].b = 0.0 ; 
		bit_1[y].a = 1.0 ;
		// create phi representing the state of input 
		qx_matrix_tensor_product(1,2,1,2, bit_0, bit_1, phi0 ) ; 
		// execute AND|xy>
		qx_matrix_mmul(2,4,1, (qx *)classical_gate, phi0, RESULT_phi ) ; 
		k = qx_state_variable_binary_value(2, RESULT_phi, 0 ) ; 
		sprintf ( buf, "Gate %s |%d%d> result = %d", description, x, y, k ) ; 
		ListMatrix(0,buf, 1,2, RESULT_phi) ; 
	}
 }
}
void CQCP_gates::QCF_gate_AND()
{
qx AND_gate[2][4] = { {{1},{1},{1},{0}}, 
                      {{0},{0},{0},{1}} };
 classical_gates_test("AND", (qx *)AND_gate)  ; 
}
void CQCP_gates::QCF_gate_OR()
{
qx OR_gate[2][4]  = { {{1},{0},{0},{0}}, 
                      {{0},{1},{1},{1}} };
 classical_gates_test("OR", (qx *)OR_gate)  ; 
}
void CQCP_gates::QCF_gate_XOR()
{
qx XOR_gate[2][4] = { {{1},{0},{0},{1}},
                      {{0},{1},{1},{0}}, };
 classical_gates_test("XOR", (qx *)XOR_gate)  ; 
}
void CQCP_gates::QCF_gate_NAND()
{
qx NOT_gate[2][2] = { {{0},{1}}, 
                      {{1},{0}} };
qx AND_gate[2][4] = { {{1},{1},{1},{0}}, 
                      {{0},{0},{0},{1}} };
qx NAND_gate[2][4] ; // to be built
 
 // build NAND multiplying NOT * AND
 qx_matrix_mmul(2,2,4, (qx *)NOT_gate, (qx *)AND_gate, (qx *)NAND_gate ) ; 
 classical_gates_test("NAND", (qx *)NAND_gate)  ; 
}
void CQCP_gates::QCF_gate_composed()
{
char buf[200] ;
qx NOT_gate[2][2] = { {{0},{1}}, 
                      {{1},{0}} };
qx IDE_gate[2][2] = { {{1},{0}}, 
                      {{0},{1}} };
qx NOT_IDE_gate[4][4] ; 
qx bit_0[2] = {{1},{0}} ; // |0>
qx bit_1[2] = {{0},{1}} ; // |1>
qx phi0 [4] ;
qx RESULT_phi[4] ;
qx RESULT_phi_reverse[4] ;
qx RESULT_phi_reverse_reverse[4] ;

 // build composed gate 
 qx_matrix_tensor_product(2,2,2,2, (qx *)NOT_gate, (qx *)IDE_gate, (qx *)NOT_IDE_gate ) ; 
 sprintf ( buf,  "Composed Gate NOT x,  IDENTITY y, hermitian=%s, unitary=%s", 
	 qx_matrix_is_hermitian(4,(qx *)NOT_IDE_gate) ? "yes" : "no", qx_matrix_is_unitary(4,(qx *)NOT_IDE_gate) ? "yes" : "no"  ) ; 
 ListMatrix(7, buf, 4,4,(qx *)NOT_IDE_gate ) ; 

 // create phi representing the state of input 
 qx_matrix_tensor_product(1,2,1,2, bit_0, bit_1, phi0 ) ; 
 ListMatrix(0, "Input |01>", 1,4,phi0 ) ; 
 
 // execute gate: 
 qx_matrix_mmul(4,4,1, (qx *)NOT_IDE_gate, phi0, RESULT_phi ) ;
 ListMatrix(0, "Applied Composed Gate NOT x,  IDENTITY y", 1,4,RESULT_phi ) ; 
 qx_matrix_mmul(4,4,1, (qx *)NOT_IDE_gate, RESULT_phi, RESULT_phi_reverse ) ;
 ListMatrix(0, "Applied Composed Gate NOT x,  IDENTITY y, First  reversion", 1,4,RESULT_phi_reverse ) ; 
 qx_matrix_mmul(4,4,1, (qx *)NOT_IDE_gate, RESULT_phi_reverse, RESULT_phi_reverse_reverse ) ;
 ListMatrix(0, "Applied Composed Gate NOT x,  IDENTITY y, Second reversion", 1,4,RESULT_phi_reverse_reverse ) ; 
}

void CQCP_gates::QCF_gate_controlled_NOT()
{
qx IDE_gate[2][2] = { {{1},{0}}, 
                      {{0},{1}} };
qx NOT_gate[2][2] = { {{0},{1}}, 
                      {{1},{0}} };
qx controlled_NOT_gate[4][4] ; 

// build composed gate 
 qx_matrix_tensor_product(2,2,2,2, (qx *)IDE_gate, (qx *)NOT_gate, (qx *)controlled_NOT_gate ) ; 
 ListMatrix(7, "Composed Gate controlled-NOT", 4,4,(qx *)controlled_NOT_gate ) ; 

qx bit_0[2] = {{1},{0}} ; // |0>
qx bit_1[2] = {{0},{1}} ; // |1>
qx phi0 [4] ;
qx RESULT_phi[4] ;
qx RESULT_phi_reverse[4] ;
qx RESULT_phi_reverse_reverse[4] ;

 // create phi representing the state of input 
 qx_matrix_tensor_product(1,2,1,2, bit_0, bit_1, phi0 ) ; 
 ListMatrix(0, "Input, |x> = 0 |y> = 1", 1,4,phi0 ) ; 
 // execute gate: 
 qx_matrix_mmul(4,4,1, (qx *)controlled_NOT_gate, phi0, RESULT_phi ) ;
 ListMatrix(0, "Applied Gate controlled-NOT", 1,4,RESULT_phi ) ; 
 qx_matrix_mmul(4,4,1, (qx *)controlled_NOT_gate, RESULT_phi, RESULT_phi_reverse ) ;
 ListMatrix(0, "Applied Gate controlled-NOT First  reversion", 1,4,RESULT_phi_reverse ) ; 
 qx_matrix_mmul(4,4,1, (qx *)controlled_NOT_gate, RESULT_phi_reverse, RESULT_phi_reverse_reverse ) ;
 ListMatrix(0, "Applied Gate controlled-NOT Second reversion", 1,4,RESULT_phi_reverse_reverse ) ; 
}

void CQCP_gates::QCF_gate_Toffoli()
{
qx Toffoli[8][8] ;
qx Fredkin[8][8] ;

 // build composed gate as a constant
 qx_matrix_constant(QX_M88_TOFFOLI, (qx *)Toffoli ) ; 
 ListMatrix(7, "Composed Gate Toffoli", 8,8,(qx *)Toffoli ) ; 

 qx_matrix_constant(QX_M88_FREDKIN, (qx *)Fredkin ) ; 
 ListMatrix(4, "Composed Gate Fredkin", 8,8,(qx *)Fredkin ) ; 
}

void CQCP_gates::QCF_gate_misc_a()
{
	ListMatrix(0,"Further tests can be implemented here") ; 
}

