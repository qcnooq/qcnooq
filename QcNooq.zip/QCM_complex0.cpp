/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020 ISBN: 9788897527541 
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// utilities for operations on complex numbers
//
#include "stdafx.h"
#include "QCM_Math.h"

extern qx qx_negate(qx c0)
{
qx result ;
 result.a = -c0.a ; result.b = -c0.b ;
 return result ;
}
extern qx qx_conjugate(qx c0) 
{
qx result ;
 result.a = c0.a ; result.b = -c0.b ;
 return result ;
}
extern qx qx_add(qx c0, qx c1) 
{
qx result ;
 result.a = c0.a + c1.a ; 
 result.b = c0.b + c1.b ; 
 return result ;
}
extern qx qx_mul(qx c0, qx c1) 
{
qx result ;
 result.a = (c0.a * c1.a) - (c0.b * c1.b)  ; 
 result.b = (c0.a * c1.b) + (c1.a * c0.b)  ; 
 return result ;
}
extern BOOL qx_div(qx c0, qx c1, qx *resp) 
{
double ms = (c1.a * c1.a)+(c1.b * c1.b) ; //  modulus squared of divisor
 if ( ms == 0 ) return FALSE ; // we cannot divide by zero
 resp->a = ((c0.a * c1.a) + (c0.b * c1.b))/(ms) ; 
 resp->b = ((c1.a * c0.b) - (c0.a * c1.b))/(ms) ; 
 return TRUE ;
}
extern double qx_modulus_squared (qx c1) 
{
double result = (c1.a * c1.a)+(c1.b * c1.b) ; //  modulus squared
 return result ;
}
