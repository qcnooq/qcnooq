/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020 ISBN: 9788897527541 
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// QcNooqDlg.h : header file
//

#pragma once
#include "afxwin.h"


class CAboutDlg : public CDialogML
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	void OnOK();
// Implementation
protected:
	DECLARE_MESSAGE_MAP()
	
public:
	CStaticML m_static01;
	CStaticML m_static02;
	CStaticML m_static03;
};


// CQcNooqDlg dialog
class CQcNooqDlg : public CDialogML
{
// Construction
public:
	CQcNooqDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_QCNOOQ_DIALOG };

	CListBox m_messages;
	CListCtrl m_matrix_0;
	CRect messages_rect, matrix_rect ; 
	CAboutDlg WorkInProgress ;


protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

// Implementation
protected:
	HICON m_hIcon;
	CColorButton m_resize, m_cls ;
	CStaticML m_buildinfo, m_info00;
	CStaticML m_static01;
	CStaticML m_static00;
	CStaticML m_static02;

	CColorButton m_readme;
	CColorButton m_chap30;
	CColorButton m_chap40;
	CColorButton m_chap50;
	CColorButton m_chap61;
	CColorButton m_chap62;
	CColorButton m_chap63;
	CColorButton m_chap64;
	CColorButton m_chap65;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	void OnOK();
	void OnSysCommand(UINT nID, LPARAM lParam);
	void OnPaint();
	HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
	void On_Button_readme();
	void On_Button_resize();
	void On_Button_Buttoncls();
	void On_Button_deutsch_test();
	void On_Button_matrix_test();	
	void On_Button_bitqubittest();
	void On_Button_gatestest();
	void On_Button_deutschJosza();
	void On_Button_Simon();
	void On_Button_Grover();
	void On_Button_Shor();	
	void OnNMRClickmatrix0(NMHDR *pNMHDR, LRESULT *pResult);
};
