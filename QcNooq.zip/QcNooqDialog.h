/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020 ISBN: 9788897527541 
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
#if !defined(AFX_DLBOX_H__1F411462_E4B2_11D8_B14D_00201X574596__INCLUDED_)
#define AFX_DLBOX_H__1F411462_E4B2_11D8_B14D_00201X574596__INCLUDED_

/////////////////////////////////////////////////////////////////////////////
// CDialogML window

class CDialogML : public CDialog
{
// Construction
public:
	CDialogML(int IDDX, CWnd* pParent = 0);
	//virtual ~CDialogML();
	// Generated message map functions
protected:
    COLORREF m_clrText ;
	COLORREF m_clrBkgnd ;
    CBrush   m_brBkgnd ;
    void CDialogML::ColoriSpeciali ( int testo, int sfondo );
	//{{(CDialogML)
	HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
    void OnDestroy();
    void OnPaint();
	DECLARE_MESSAGE_MAP()
};
#endif // !defined(AFX_DLBOX_H__1F411462_E4B2_11D8_B14D_00201X574596__INCLUDED_)