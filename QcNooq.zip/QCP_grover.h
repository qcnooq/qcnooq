/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020 ISBN: 9788897527541 
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
#pragma once
#ifdef QCNOOQ_WINDOWS
#include "afxwin.h"
#endif

// CQCP_grover dialog

class CQCP_grover 
#ifdef QCNOOQ_WINDOWS
	: public CDialogML
#endif
{
#ifdef QCNOOQ_WINDOWS
	DECLARE_DYNAMIC(CQCP_grover)
public:
	CQCP_grover(CWnd* pParent = NULL);   // standard constructor
	virtual ~CQCP_grover();
	BOOL Create(CWnd* pParent) ;
	void OnCancel() ;
	BOOL OnInitDialog();
	void OnOK();
	CStaticML m_progress1 ;
	CComboBox m_number_of_iterations;

// Dialog Data
	enum { IDD = IDD_QCP_I_GROVER };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	CStaticML m_static00;
	DECLARE_MESSAGE_MAP()
	CStaticML m_static01;
	CStaticML m_static03;
	CColorButton m_A,m_B,m_C,m_D,m_E,m_Ev,m_F,m_bA,m_bB,m_bC,m_bE,m_bF, m_bG;
	CComboBox m_number_of_bits;
	void OnCbnSelchangevaluetotry();
	void OnCbnSelchangenumberofiterations();
#endif
public:
	byte number_of_bits, number_of_iterations ; 	
protected:
	byte QCF_Grover_3bit_base_function(byte input) ;
	void QCF_Grover_3bit_func1();
	void QCF_Build_Grover_3bit_func_Uf(qx Ufunc[16][16]);
	void QCF_Grover_3bit_func_Uf();
	void QCF_Build_Grover_3bit_average_inversion_matrix(int, qx *) ; 
	void QCF_Grover_3bit_inversion_matrix();
	void QCF_Grover_3bit_algorithm(char  mode, int samples);
	void QCF_Grover_3bit_algorithm();
	void QCF_Grover_3bit_stat();

	byte QCF_Grover_Nbit_base_function(byte input) ;
	void QCF_Grover_Nbit_func1();
	void QCF_Build_Grover_Nbit_func_Uf(qx *);
	void QCF_Grover_Nbit_func_Uf();
	void QCF_Build_Grover_Nbit_average_inversion_matrix(int, qx *) ; 
	void QCF_Grover_Nbit_inversion_matrix();
public:
	void QCF_Grover_Nbit_algorithm(char verbose, int samples, qx *);
protected:
	void QCF_Grover_Nbit_algorithm();
	void QCF_Grover_Nbit_stat();	
	void QCF_Grover_3bit_inversion_sample();
	void QCF_Grover_Nbit_find_optimal_iterations();
	void QCF_QcfGrover3bitalgorithmverbose();
};
