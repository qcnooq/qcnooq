/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020 ISBN: 9788897527541 
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// CQCP_deutsch_josza.cpp : implementation file. Drills for Chapter 6.2 of "Quantum Computing for Programmers and Investors"
//

#include "stdafx.h"
#include "QcNooq.h"

#include "math.h"      // standard C math definition     
#include "QCM_math.h"  // portable definitions 
#include "QCM_tools.h"

#include "QCP_deutsch_josza.h"


// QCP_deutsch_josza dialog
#ifdef QCNOOQ_WINDOWS
IMPLEMENT_DYNAMIC(CQCP_deutsch_josza, CDialog)
CQCP_deutsch_josza::CQCP_deutsch_josza(CWnd* pParent /*=NULL*/)	: CDialogML(CQCP_deutsch_josza::IDD, pParent)
{
}
CQCP_deutsch_josza::~CQCP_deutsch_josza()
{
}
BOOL CQCP_deutsch_josza::Create(CWnd* pParent)
{
	if (!CDialogML::Create(CQCP_deutsch_josza::IDD, pParent))
	{
		return FALSE;
	}
	return TRUE;
}
void CQCP_deutsch_josza::OnCancel() {DestroyWindow(); theApp.windows_semaphore=0;}
void CQCP_deutsch_josza::DoDataExchange(CDataExchange* pDX)
{
	CDialogML::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC01, m_progress1);
	DDX_Control(pDX, IDC_STATIC02, m_progress2);
	DDX_Control(pDX, IDC_STATIC00, m_static00);
	DDX_Control(pDX, IDC_STATIC03, m_static03);
	DDX_Control(pDX, IDC_STATIC04, m_static04);
	DDX_Control(pDX, IDC_develop_N2, m_A);
	DDX_Control(pDX, IDC_develop_N2_verify, m_B);
	DDX_Control(pDX, IDC_develop_N2_execute_DJ, m_C);
	DDX_Control(pDX, IDC_develop_N2_execute_DJ_VTIMES, m_D);
	DDX_Control(pDX, IDC_develop_N2_reset_counters, m_E);
	DDX_Control(pDX, IDC_develop_N3, m_G);
	DDX_Control(pDX, IDC_develop_N3_verify, m_H);
	DDX_Control(pDX, IDC_develop_N3_execute_DJ, m_I);
	DDX_Control(pDX, IDC_develop_N3_execute_DJ_VTIMES, m_J);
	DDX_Control(pDX, IDC_develop_N3_reset_counters, m_K);
}
BEGIN_MESSAGE_MAP(CQCP_deutsch_josza, CDialogML)
	ON_BN_CLICKED(IDC_develop_N2, &CQCP_deutsch_josza::QCF_develop_N2)
	ON_BN_CLICKED(IDC_develop_N2_verify, &CQCP_deutsch_josza::QCF_develop_N2_verify)
	ON_BN_CLICKED(IDC_develop_N2_execute_DJ, &CQCP_deutsch_josza::QCF_develop_N2_execute_DJ)
	ON_BN_CLICKED(IDC_develop_N2_execute_DJ_VTIMES, &CQCP_deutsch_josza::QCF_develop_N2_execute_Dj_Vtimes)
	ON_BN_CLICKED(IDC_develop_N2_reset_counters, &CQCP_deutsch_josza::QCF_develop_N2_reset_counters)

	ON_BN_CLICKED(IDC_develop_N3, &CQCP_deutsch_josza::QCF_develop_N3)
	ON_BN_CLICKED(IDC_develop_N3_verify, &CQCP_deutsch_josza::QCF_develop_N3_verify)
	ON_BN_CLICKED(IDC_develop_N3_execute_DJ, &CQCP_deutsch_josza::QCF_develop_N3_execute_DJ)
	ON_BN_CLICKED(IDC_develop_N3_execute_DJ_VTIMES, &CQCP_deutsch_josza::QCF_develop_N3_execute_Dj_Vtimes)
	ON_BN_CLICKED(IDC_develop_N3_reset_counters, &CQCP_deutsch_josza::QCF_develop_N3_reset_counters)
END_MESSAGE_MAP()
void CQCP_deutsch_josza::OnOK(){};
BOOL CQCP_deutsch_josza::OnInitDialog()
{
	CDialogML::OnInitDialog();
	ListMatrixResize(0); // give appropriate sizes
	return TRUE;  // return TRUE  unless you set the focus to a control
}
#endif
// CQCP_deutsch_josza message handlers 
// -------- for N = 2 
void CQCP_deutsch_josza::QCF_DJ_N2_execute_DJ(int func_idx, qx Ufunc[8][8])
{
char buf[200], *type_sure_p, *type_guessed_p ; 
qx x0[2] = {{1},{0}} ;
qx x1[2] = {{1},{0}} ;
qx y[2]  = {{0},{1}} ;
qx phix[4] ; 
qx phi0[8], phi1[8], phi2[8], phi3[8], measured[8] ; 
qx HA2[2][2] ;
qx HA4[4][4] ;
qx HA8[8][8] ;
qx ID2[2][2] ;
qx HA4ID[8][8] ;
int outx0, outx1 ; 
static int counter_x00[16] ; // 
static int counter_x10[16] ; // 
static int total_counter[16] ; 

 if ( func_idx < 0 ) // called to reset counters 
 {
	 memset ( counter_x00, 0, sizeof(counter_x00) ) ;
	 memset ( counter_x10, 0, sizeof(counter_x10) ) ;
	 memset ( total_counter, 0, sizeof(total_counter) ) ;
	 return ; 
 }
 // create phi0 using the tensor product of the input constant values
 qx_matrix_tensor_product(1,2,1,2, x0, x1, phix) ; 
 qx_matrix_tensor_product(1,4,1,2, phix, y, phi0) ; 
 // create the constants 
 qx_matrix_constant(QX_M22_HADA, (qx *)HA2) ; 
 qx_matrix_tensor_product(2,2,2,2, (qx *)HA2, (qx *)HA2, (qx *)HA4) ; 
 qx_matrix_tensor_product(4,4,2,2, (qx *)HA4, (qx *)HA2, (qx *)HA8) ; 
 qx_matrix_constant(QX_M22_IDEN, (qx *)ID2) ; 
 qx_matrix_tensor_product(4,4,2,2, (qx *)HA4, (qx *)ID2, (qx *)HA4ID) ; 
 // superposition:
 qx_matrix_mmul(8,8,1, (qx *)HA8, phi0, phi1 ) ; 
 // action with Ufunc
 qx_matrix_mmul(8,8,1, (qx *)Ufunc, phi1, phi2 ) ; 
 // superposition on X:
 qx_matrix_mmul(8,8,1, (qx *)HA4ID, phi2, phi3 ) ; 
 // measurement
 qx_state_measurement(8, phi3, measured) ; 
 outx0 = qx_state_variable_binary_value(8, measured, 0) ; 
 outx1 = qx_state_variable_binary_value(8, measured, 1) ; 
 if ( outx0 == 0 && outx1 == 0 ) type_sure_p = "Constant or Neutral" ; 
 else type_sure_p = "Balanced or Neutral" ; 
 if ( outx0 == 0 ) ++counter_x00[func_idx] ;
 if ( outx1 == 0 ) ++counter_x10[func_idx] ;
 ++total_counter[func_idx] ; 
 // guessed type after multiple execution
 if ( counter_x00[func_idx] == total_counter[func_idx] && counter_x10[func_idx] == total_counter[func_idx] ) 
	 type_guessed_p = "Constant" ; 
 else if ( counter_x00[func_idx] == 0 && counter_x10[func_idx] == 0 ) 
	 type_guessed_p = "Balanced" ; 
 else if ( counter_x00[func_idx] == total_counter[func_idx] || counter_x10[func_idx] == total_counter[func_idx] ) 
	 type_guessed_p = "Balanced (or Constant)" ; 
 else
	 type_guessed_p = "Neutral (or Constant)" ;
 sprintf ( buf, "%20sAfter measurement x0=%d, x1=%d Sure=%s x0=Zero %d/%d, x1=Zero %d/%d Guessed=%s", "", outx0, outx1, type_sure_p, 
           counter_x00[func_idx], total_counter[func_idx], counter_x10[func_idx], total_counter[func_idx], type_guessed_p ) ; 
 ListMatrix(0,buf) ; 
}
void CQCP_deutsch_josza::QCF_DJ_N2_verify(int func_idx, char func_values[4], char func_values_printable[4], char analytic, qx Ufunc[8][8])
{
char buf[200], *typep ; 
qx invector[8] ; // input vector: case of x0, x1, y
int inidx ; 
qx outvector[8] ; 
int x0, x1, y, fx_xor_y, fx ; 
int cnt0 ; 
 cnt0 = 0  ; 
 for ( inidx = 0 ; inidx < 8 ; ++inidx )
 {
	 memset ( invector, 0, 8 * sizeof(qx) ) ; 
	 invector[inidx].a = 1.0 ; 
	 qx_matrix_mmul(8,8,1, (qx *)Ufunc, invector, outvector ) ; 
	 x0 = qx_state_variable_binary_value(8, invector, 0 ) ; 
	 x1 = qx_state_variable_binary_value(8, invector, 1 ) ; 
	 y  = qx_state_variable_binary_value(8, invector, 2 ) ; 
	 fx_xor_y = qx_state_variable_binary_value(8, outvector, 2 ) ; 
	 fx = fx_xor_y ^ y ; 
	 if ( fx == 0 ) ++cnt0 ;  
	 if ( analytic ) {
		sprintf ( buf, "Func index %02d fx values=[%s] x0=%d x1=%d y=%d fx=%d", func_idx , func_values_printable, x0, x1, y, fx) ; 
		ListMatrix(0, buf) ;
	 }
 }
 if ( cnt0 == 0 ) typep = "CONSTANT 1"  ;
 else if ( cnt0 == 8 ) typep = "CONSTANT 0"  ;
 else if ( cnt0 == 4 ) typep = "BALANCED" ; 
 else typep = "NEUTRAL" ;
 sprintf ( buf, "Func index %02d fx values=[%s] Output=|0> %d times, %s", func_idx , func_values_printable, cnt0, typep ) ; 
 ListMatrix(0, buf) ; 
}
// the following function develops the 16 possibile Ufunc and acts according to mode parameter
void CQCP_deutsch_josza::QCF_DJ_N2(char mode)
{
char buf[200] ; 
char func_values[4] ; // char perch� questa non entrer� nel gioco quantistico 
char func_values_printable[4+1] ;   // only for output
unsigned char func_idx ; // index of base function
int x0, x1, y, fx, fx_xor_y ;  
int Urow, Ucol ; 
qx Ufunc[8][8] ; 

 ListMatrix(3, "DJ with N = 2" ) ; 
 for ( func_idx = 0 ; func_idx < 16 ; ++func_idx ) 
 {
	 qx_binary_vector(func_values, 4, func_idx  ) ; 
	 qx_binary_output(func_values_printable, 4, func_idx  ) ; 
	 sprintf (buf, "Func index %02d fx values=[%s]", func_idx , func_values_printable) ; 
	 ListMatrix(0, buf ) ; 
	 memset ( Ufunc, 0, 8*8*sizeof(qx) ) ; 
	 for ( x0 = 0 ; x0 <= 1 ; ++x0 ) 
	 {
		 for ( x1 = 0 ; x1 <= 1 ; ++x1 ) 
		 {
			 for ( y = 0 ; y <= 1 ; ++y ) 
			 {
				 fx = func_values[x0*2 + x1] ; 
				 fx_xor_y = fx^y ; 
				 Urow = x0*4 + x1*2+ y ;
				 Ucol = x0*4 + x1*2+ fx_xor_y  ;
				 Ufunc[Urow][Ucol].a =  1 ; 
			 }
		 }
	 }
	 ListMatrix(4,buf, 8,8, (qx *)Ufunc ) ; 
	 if ( mode == 1 ) 
	 {
		 QCF_DJ_N2_verify(func_idx, func_values, func_values_printable, 1, Ufunc);
	 }
	 else if ( mode == 2 ) 
	 {
		 QCF_DJ_N2_verify(func_idx, func_values, func_values_printable, 0, Ufunc);
		 QCF_DJ_N2_execute_DJ(func_idx, Ufunc);
	 }
 }
}
void CQCP_deutsch_josza::QCF_develop_N2()
{
	work_in_progress_show(1) ; 
	QCF_DJ_N2(0); // just develop Ufunc with N=2
	work_in_progress_show(0) ; 
}
void CQCP_deutsch_josza::QCF_develop_N2_verify()
{
	work_in_progress_show(1) ; 
	ListMatrixResize(1) ; 
	QCF_DJ_N2(1); // develop Ufunc with N=2 and execute them - show output 
	work_in_progress_show(0) ; 
}
void CQCP_deutsch_josza::QCF_develop_N2_execute_DJ()
{
	work_in_progress_show(1) ; 
	QCF_DJ_N2(2); // develop Ufunc with N=2 and execute them - show output 
	work_in_progress_show(0) ; 
}
void CQCP_deutsch_josza::QCF_develop_N2_execute_Dj_Vtimes()
{
int k ; 
 work_in_progress_show(1) ; 
 ListMatrix(0x08,NULL) ; // disable output
 for ( k = 0 ; k < 99 ; ++k ) QCF_DJ_N2(2); // develop Ufunc with N=2 and execute them 
 ListMatrix(0x10,NULL) ; // enable output
 QCF_DJ_N2(2); // execute again for output
 work_in_progress_show(0) ; 
}
void CQCP_deutsch_josza::QCF_develop_N2_reset_counters()
{
 QCF_DJ_N2_execute_DJ(-1, NULL) ; // call to reset counters 
}

////////  Functions for N = 3 ----------------------------

void CQCP_deutsch_josza::QCF_DJ_N3_execute_DJ(int func_idx, qx Ufunc[16][16])
{
char buf[200], *type_sure_p, *type_guessed_p ; 
qx x0[2] = {{1},{0}} ;
qx x1[2] = {{1},{0}} ;
qx x2[3] = {{1},{0}} ;
qx y[2]  = {{0},{1}} ;
qx phix2[4] ; 
qx phix3[8] ; 
qx phi0[16], phi1[16], phi2[16], phi3[16], measured[16] ; 
qx HA2[2][2] ;
qx HA4[4][4] ;
qx HA8[8][8] ;
qx HA16[16][16] ;
qx ID2[2][2] ;
qx HA8ID[16][16] ;
int outx0, outx1, outx2 ; 
static int counter_x0[3][256] ; // 
static int total_counter[256] ; 

 if ( func_idx < 0 ) // called to reset counters 
 {
	 memset ( counter_x0[0], 0, sizeof(counter_x0[0]) ) ;
	 memset ( counter_x0[1], 0, sizeof(counter_x0[1]) ) ;
	 memset ( counter_x0[2], 0, sizeof(counter_x0[2]) ) ;
	 memset ( total_counter, 0, sizeof(total_counter) ) ;
	 return ; 
 }
 // create phi0 using the tensor product of the input constant values
 qx_matrix_tensor_product(1,2,1,2, x0, x1, phix2) ; 
 qx_matrix_tensor_product(1,4,1,2, phix2, x2, phix3) ; 
 qx_matrix_tensor_product(1,8,1,2, phix3, y, phi0) ; 
 // create the constants 
 qx_matrix_constant(QX_M22_HADA, (qx *)HA2) ; 
 qx_matrix_tensor_product(2,2,2,2, (qx *)HA2, (qx *)HA2, (qx *)HA4) ; 
 qx_matrix_tensor_product(4,4,2,2, (qx *)HA4, (qx *)HA2, (qx *)HA8) ; 
 qx_matrix_tensor_product(8,8,2,2, (qx *)HA8, (qx *)HA2, (qx *)HA16) ; 
 qx_matrix_constant(QX_M22_IDEN, (qx *)ID2) ; 
 qx_matrix_tensor_product(8,8,2,2, (qx *)HA8, (qx *)ID2, (qx *)HA8ID) ; 
 // superposition:
 qx_matrix_mmul(16,16,1, (qx *)HA16, phi0, phi1 ) ; 
 // action with Ufunc
 qx_matrix_mmul(16,16,1, (qx *)Ufunc, phi1, phi2 ) ; 
 // superposition on X:
 qx_matrix_mmul(16,16,1, (qx *)HA8ID, phi2, phi3 ) ; 
 // measurement
 qx_state_measurement(16, phi3, measured) ; 
 outx0 = qx_state_variable_binary_value(16, measured, 0) ; 
 outx1 = qx_state_variable_binary_value(16, measured, 1) ; 
 outx2 = qx_state_variable_binary_value(16, measured, 2) ; 
 if ( outx0 == 0 && outx1 == 0 && outx2 == 0 ) type_sure_p = "Constant or Neutral" ; 
 else type_sure_p = "Balanced or Neutral" ; 
 if ( outx0 == 0 ) ++counter_x0[0][func_idx] ;
 if ( outx1 == 0 ) ++counter_x0[1][func_idx] ;
 if ( outx2 == 0 ) ++counter_x0[2][func_idx] ;
 ++total_counter[func_idx] ; 
 int j, piumez, menomez ;
 for ( j = piumez = menomez = 0 ; j < 3 ; ++j ) 
 {
	 if ( counter_x0[j][func_idx] > (total_counter[func_idx] * 45)/100 && counter_x0[j][func_idx] < (total_counter[func_idx] * 55)/100  )
	 {
		 if ( counter_x0[j][func_idx] < (total_counter[func_idx] * 50)/100 ) ++menomez ; 
		 else ++piumez ; 
	 }
 }

 // guessed type after multiple execution
 if ( counter_x0[0][func_idx] == total_counter[func_idx] && counter_x0[1][func_idx] == total_counter[func_idx] && counter_x0[2][func_idx] == total_counter[func_idx] ) 
	 type_guessed_p = "Constant" ; 
 else if ( counter_x0[0][func_idx] == 0 || counter_x0[1][func_idx] == 0 || counter_x0[2][func_idx] == 0 ) 
	 type_guessed_p = "Balanced" ; 
 else if ( (counter_x0[0][func_idx] == total_counter[func_idx] || counter_x0[1][func_idx] == total_counter[func_idx] || counter_x0[2][func_idx] == total_counter[func_idx]) &&
	       (counter_x0[0][func_idx] == 0 || counter_x0[1][func_idx] == 0 || counter_x0[2][func_idx] == 0)  )
	 type_guessed_p = "Balanced (or Constant)" ; 
 else if (	menomez > 0 && piumez > 0 && menomez+piumez == 3 )	       
	 type_guessed_p = "Balanced (or Neutral)" ; 
 else
	 type_guessed_p = "Neutral (or Constant)" ; 

 sprintf ( buf, "Measured x0=%d, x1=%d, x2=%d Sure=%s x0=Zero %d/%d, x1=Zero %d/%d, x2=Zero %d/%d Guessed=%s", outx0, outx1, outx2, type_sure_p, 
           counter_x0[0][func_idx], total_counter[func_idx], counter_x0[1][func_idx], total_counter[func_idx], 
		   counter_x0[2][func_idx], total_counter[func_idx], 
		   type_guessed_p ) ; 
 ListMatrix(0,buf) ; 
}
void CQCP_deutsch_josza::QCF_DJ_N3_verify(int func_idx, char func_values[4], char func_values_printable[4], char analytic, qx Ufunc[16][16])
{
char buf[200], *typep ; 
qx invector[16] ; // input vector: case of x0, x1, y
int inidx ; 
qx outvector[16] ; 
int x0, x1, x2, y, fx_xor_y, fx ; 
int cnt0 ; 
 cnt0 = 0  ; 
 for ( inidx = 0 ; inidx < 16 ; ++inidx )
 {
	 memset ( invector, 0, 16 * sizeof(qx) ) ; 
	 invector[inidx].a = 1.0 ; 
	 qx_matrix_mmul(16,16,1, (qx *)Ufunc, invector, outvector ) ; 
	 x0 = qx_state_variable_binary_value(16, invector, 0 ) ; 
	 x1 = qx_state_variable_binary_value(16, invector, 1 ) ; 
	 x2 = qx_state_variable_binary_value(16, invector, 2 ) ; 
	 y  = qx_state_variable_binary_value(16, invector, 3 ) ; 
	 fx_xor_y = qx_state_variable_binary_value(16, outvector, 3 ) ; 
	 fx = fx_xor_y ^ y ; 
	 if ( fx == 0 ) ++cnt0 ;  
	 if ( analytic ) {
		sprintf ( buf, "Func index %03d fx values=[%s] x0=%d x1=%d x2=%d y=%d fx=%d", func_idx , func_values_printable, x0, x1, x2, y, fx) ; 
		ListMatrix(0, buf) ;
	 }
 }
 if ( cnt0 == 0 ) typep = "CONSTANT 1"  ;
 else if ( cnt0 == 16 ) typep = "CONSTANT 0"  ;
 else if ( cnt0 == 8 ) typep = "BALANCED" ; 
 else typep = "NEUTRAL" ;
 sprintf ( buf, "Func index %02d fx values=[%s] Output=|0> %d times, %s", func_idx , func_values_printable, cnt0, typep ) ; 
 ListMatrix(0, buf) ; 
}
// the following function develops the 16 possibile Ufunc and acts according to mode parameter
void CQCP_deutsch_josza::QCF_DJ_N3(char mode)
{
char buf[200], bpr[100] ; 
char func_values[8] ; // char perch� questa non entrer� nel gioco quantistico 
char func_values_printable[8+1] ;   // only for output
unsigned short func_idx ; // index of base function
int x0, x1, x2, y, fx, fx_xor_y ;  
int Urow, Ucol ; 
qx Ufunc[16][16] ; 

 ListMatrix(3, "DJ with N = 3" ) ; 
 for ( func_idx = 0 ; func_idx < 256 ; ++func_idx ) 
 {
	 qx_binary_vector(func_values, 8, func_idx  ) ; 
	 qx_binary_output(func_values_printable, 8, func_idx  ) ; 
	 sprintf (buf, "Func index %02d fx values=[%s]", func_idx , func_values_printable) ; 
	 ListMatrix(0, buf ) ; 
	 memset ( Ufunc, 0, 16*16*sizeof(qx) ) ; 
	 for ( x0 = 0 ; x0 <= 1 ; ++x0 ) 
	 {	
		 for ( x1 = 0 ; x1 <= 1 ; ++x1 ) 
		 {
			 for ( x2 = 0 ; x2 <= 1 ; ++x2 ) 
			 {
				 for ( y = 0 ; y <= 1 ; ++y ) 
				 {
					 fx = func_values[x0*4 + x1*2 + x2] ; 
					 fx_xor_y = fx^y ; 
					 Urow = x0*8 + x1*4+ x2*2 + y ;
					 Ucol = x0*8 + x1*4+ x2*2 + fx_xor_y  ;
					 Ufunc[Urow][Ucol].a =  1 ; 
				 }
			 }
		 }
	 }
	 if ( func_idx % 16 == 0 ) 
	 {
		 ListMatrix(4,buf, 16,16, (qx *)Ufunc ) ; 
		 sprintf ( bpr , "Wait %d / 256", func_idx ) ; 
#ifdef QCNOOQ_WINDOWS
		 m_progress1.SetWindowText(bpr) ;
#endif
	 }
	 if ( mode == 1 ) 
	 {
		 QCF_DJ_N3_verify(func_idx, func_values, func_values_printable, 0, Ufunc);
	 }
	 else if ( mode == 2 ) 
	 {
		 QCF_DJ_N3_verify(func_idx, func_values, func_values_printable, 0, Ufunc);
		 QCF_DJ_N3_execute_DJ(func_idx, Ufunc);
	 }
 }
#ifdef QCNOOQ_WINDOWS
 m_progress1.SetWindowText("DONE") ;
#endif
}
void CQCP_deutsch_josza::QCF_develop_N3()
{
	work_in_progress_show(1) ; 
	QCF_DJ_N3(0); // just develop Ufunc with N=2	
	work_in_progress_show(0) ; 
}
void CQCP_deutsch_josza::QCF_develop_N3_verify()
{
	work_in_progress_show(1) ; 
	ListMatrixResize(1) ; 
	QCF_DJ_N3(1); // develop Ufunc with N=2 and execute them - show output 
	work_in_progress_show(0) ; 
}
void CQCP_deutsch_josza::QCF_develop_N3_execute_DJ()
{
	work_in_progress_show(1) ; 
	QCF_DJ_N3(2); // develop Ufunc with N=2 and execute them - show output 
	work_in_progress_show(0) ; 
}
UINT QCF_develop_N3_execute_Dj_Vtimes_threaded(LPVOID param_class_pointer)
{
int k ;
char buf [40] ; 
int repetitions = 100 ; 
CQCP_deutsch_josza *smp = (CQCP_deutsch_josza *)param_class_pointer ; 
 for ( k = 0 ; k < repetitions-1 ; ++k ) 
 {
	 sprintf ( buf, "%d / %d", k, repetitions ) ; 
#ifdef QCNOOQ_WINDOWS
	 smp->m_progress2.SetWindowText(buf) ;
#endif
	 smp->QCF_DJ_N3(2); // develop Ufunc with N=2 and execute them 
 }
ListMatrix(0x10,NULL) ; // enable output
#ifdef QCNOOQ_WINDOWS
 smp->m_progress2.SetWindowText("LAST") ;
#endif
 smp->QCF_DJ_N3(2); // execute once more for output
#ifdef QCNOOQ_WINDOWS
 smp->m_progress2.SetWindowText("DONE") ;
#endif
 work_in_progress_show(0) ; 
 return 0 ; 
}
void CQCP_deutsch_josza::QCF_develop_N3_execute_Dj_Vtimes()
{
 work_in_progress_show(1) ; 
 ListMatrix(0x08,NULL) ; // disable output
#ifdef QCNOOQ_WINDOWS
 // a Windows event should not timeout. So if the function will last more than a few seconds, create a thread and release the button event
 AfxBeginThread(QCF_develop_N3_execute_Dj_Vtimes_threaded,this) ; 
#else
 QCF_develop_N3_execute_Dj_Vtimes_threaded(this) ; 
#endif 
}
void CQCP_deutsch_josza::QCF_develop_N3_reset_counters()
{
 QCF_DJ_N3_execute_DJ(-1, NULL) ; // call to reset counters 
}
