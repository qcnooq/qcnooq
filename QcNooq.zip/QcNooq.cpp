/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// QcNooq.cpp : Defines the class behaviors for the application. To be included in project ONLY in Windows MFC environment
//
#include "stdafx.h"
#include "QcNooq.h"
#include "QcNooqDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// global main dialog - members can be referenced by other dialogs 
CQcNooqDlg CQcNooqDlg_dlg;

// CQcNooqApp

BEGIN_MESSAGE_MAP(CQcNooqApp, CWinApp)
	ON_COMMAND(ID_HELP, &CWinApp::OnHelp)
END_MESSAGE_MAP()


// CQcNooqApp construction

CQcNooqApp::CQcNooqApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
	windows_semaphore = 0 ; 
}


// The one and only CQcNooqApp object

CQcNooqApp theApp;


// CQcNooqApp initialization

BOOL CQcNooqApp::InitInstance()
{
	// InitCommonControlsEx() is required on Windows XP if an application
	// manifest specifies use of ComCtl32.dll version 6 or later to enable
	// visual styles.  Otherwise, any window creation will fail.
	INITCOMMONCONTROLSEX InitCtrls;
	InitCtrls.dwSize = sizeof(InitCtrls);
	// Set this to include all the common control classes you want to use
	// in your application.
	InitCtrls.dwICC = ICC_WIN95_CLASSES;
	InitCommonControlsEx(&InitCtrls);

	CWinApp::InitInstance();

	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need
	// Change the registry key under which our settings are stored
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));
	
	m_pMainWnd = &CQcNooqDlg_dlg;
	INT_PTR nResponse = CQcNooqDlg_dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
extern void work_in_progress_show(int mode) 
{
CRect   gl, wp ; 
int hi, wi ;
 if ( mode == 1 ) 
 {
	 CQcNooqDlg_dlg.GetWindowRect(&gl) ; 
	 CQcNooqDlg_dlg.WorkInProgress.GetWindowRect(&wp) ;
	 hi = wp.bottom-wp.top ; wi=wp.right-wp.left;
	 //CQcNooqDlg_dlg.ScreenToClient(&gl) ; // not needed for main dialog 
	 CQcNooqDlg_dlg.WorkInProgress.ScreenToClient(&wp) ;
	 // centered:
	 /* wp.top  = (gl.top+gl.bottom)/2 - hi/2 ; wp.bottom = (gl.top+gl.bottom)/2 + hi/2 ; 
	 wp.left = (gl.left+gl.right)/2 - wi/2 ; wp.right  = (gl.left+gl.right)/2 + wi/2 ; /**/
	 // left:
	 wp.top = gl.top + 1 ; wp.bottom = wp.top + hi ; 
	 wp.left = gl.left + 1 ; wp.right = wp.left + wi ; /**/
	 CQcNooqDlg_dlg.WorkInProgress.MoveWindow(&wp, TRUE) ; 	 
	 CQcNooqDlg_dlg.WorkInProgress.ShowWindow(SW_SHOW) ; 	 
	 CQcNooqDlg_dlg.WorkInProgress.Invalidate() ; CQcNooqDlg_dlg.WorkInProgress.UpdateWindow() ;
 }
 else 
 {
	 CQcNooqDlg_dlg.WorkInProgress.ShowWindow(SW_HIDE) ; 
 }
}