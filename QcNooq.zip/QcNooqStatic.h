/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
#if !defined(AFX_STATIC_H__1F411462_E4B2_11D8_B14D_00201X574596__INCLUDED_)
#define AFX_STATIC_H__1F411462_E4B2_11D8_B14D_00201X574596__INCLUDED_

class CStaticML : public CStatic
{
// Construction
public:
	CStaticML();
// Attributes
public:
 COLORREF m_clrText ;
 COLORREF m_clrBkgnd ;
 CBrush   m_brBkgnd ;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStaticML)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CStaticML();
    void ColoriSpeciali ( int, int ) ;
    	// Generated message map functions
protected:
	//{{(CStaticML)
    HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
    void OnDestroy();
    void OnPaint();
	//}}
	DECLARE_MESSAGE_MAP()
};

#endif // !defined(AFX_STATIC_H__1F411462_E4B2_11D8_B14D_00201X574596__INCLUDED_)