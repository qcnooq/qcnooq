/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020 ISBN: 9788897527541 
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// Matrix operations 1
//

#include "stdafx.h"
#include <math.h>  
#include "QCM_Math.h"


extern BOOL qx_matrix_constant (int casevalue, qx *dd) 
{
int j ; 
 memset(dd, 0, 2*2*sizeof(qx) ) ; // all matrices at least 2 x 2 
 switch ( casevalue ) 
 {
 default: return FALSE ; 
 case QX_M22_PAULIX: dd[(0*2)+0].a = 0 ; dd[(0*2)+1].a = 1 ; dd[(1*2)+0].a = 1 ; dd[(1*2)+1].a = 0 ; 
	 break ; 
 case QX_M22_PAULIY: dd[(0*2)+0].a = 0 ; dd[(0*2)+1].a = 0 ; dd[(1*2)+0].a = 0 ; dd[(1*2)+1].a = 0 ; 
					 dd[(0*2)+0].b = 0 ; dd[(0*2)+1].b =-1 ; dd[(1*2)+0].b = 1 ; dd[(1*2)+1].a = 0 ; 
	 break ; 
 case QX_M22_PAULIZ: dd[(0*2)+0].a = 1 ; dd[(0*2)+1].a = 0 ; dd[(1*2)+0].a = 0 ; dd[(1*2)+1].a = -1 ; 
	 break ; 
 case QX_M22_S:      dd[(0*2)+0].a = 1 ; 
										                                         dd[(1*2)+1].b = 1 ; 
	 break ; 
 case QX_M22_T:		
	 double epowipiquarti ;
					epowipiquarti = QX_C_EULERO ; // elevarlo a i * (pigreco/4) - elevare a esponente complesso come si fa ??
					dd[(0*2)+0].a = 1 ; dd[(0*2)+1].a = 0 ; dd[(1*2)+0].a = 0 ; dd[(1*2)+1].a = epowipiquarti ; 
					return FALSE ; // non finito 
	 break ; 
 case QX_M22_IDEN:
	 dd[(0*2)+0].a = 1 ; dd[(1*2)+1].a = 1 ;  					
	 break ; 
 case QX_M22_HADA:
	 double S2I ;   S2I = 1.0/(sqrt(2.0)) ;
					dd[(0*2)+0].a = S2I ; dd[(0*2)+1].a = S2I ; dd[(1*2)+0].a = S2I ; dd[(1*2)+1].a = -S2I ; 
	 break ; 
 case QX_M22_SQNOT:
	                S2I = 1.0/(sqrt(2.0)) ;
					dd[(0*2)+0].a = S2I ; dd[(0*2)+1].a = -S2I ; dd[(1*2)+0].a = S2I ; dd[(1*2)+1].a = S2I ; 
	 break ; 
 case QX_M88_TOFFOLI:
	 memset(dd, 0, 8*8*sizeof(qx) ) ; // Toffoli gate  8 * 8 
	 // constant values of Toffoli:
	 for ( j = 0 ; j < 6 ; ++j ) dd[j*8 + j].a = 1 ; 
	 dd[6*8 + 7].a = 1 ; dd[7*8 + 6].a = 1 ; 
	 break ; 
 case QX_M88_FREDKIN:
	 memset(dd, 0, 8*8*sizeof(qx) ) ; // Toffoli gate  8 * 8 
	 // constant values of Toffoli:
	 for ( j = 0 ; j < 5 ; ++j ) dd[j*8 + j].a = 1 ; 
	 dd[5*8 + 6].a = 1 ; dd[6*8 + 5].a = 1 ; dd[7*8 + 7].a = 1 ; 
	 break ; 
 }
 return TRUE ; 
}
extern BOOL qx_matrix_constant (int casevalue, int intpower, qx *dd) // logaritmo base 2 della dimensione 
{
int j, k, dimension ; 
 if ( intpower > 30 ) return FALSE ; // poi per numeri enormi vediamo 
 dimension = (1 << intpower) ; // dimensione = 2 elevato a intvalue (32768 per parametro 15)
 double divisor ;
 //qx omega ; 
 switch ( casevalue ) 
 {
 default: return FALSE ; 
 case QX_M22_VANDERMONDE:
	 divisor = 1 / sqrt((double)dimension) ; 
	 for ( j = 0 ;  j < dimension ; ++j ) // intvalue � la size della matrice 
	 {
		 for ( k = 0 ; k < dimension ; ++k ) 
		 {
			 dd[(j*dimension)+k].a = divisor * cos((2.0*QX_C_PIGRECO*(double)(j*k%dimension))/(double)dimension) ; 
			 dd[(j*dimension)+k].b = divisor * sin((2.0*QX_C_PIGRECO*(double)(j*k%dimension))/(double)dimension) ; 
		 }
	 }	 
	 break ; 
 case QX_M22_IDEN:  // identit� di n dimensioni 
	 for ( j = 0 ;  j < dimension ; ++j ) // intvalue � la size della matrice 
	 {
		 for ( k = 0 ; k < dimension ; ++k ) 
		 {
			 dd[(j*dimension)+k].a = ((j == k ) ? 1.0 : 0.0 ) ; 
			 dd[(j*dimension)+k].b = 0.0 ; 
		 }
	 }	 
	 break ; 
 case QX_M22_HADA: // potenza N di Hada (tensor product) (pag. 202 libro per metodo)
	 double S2I ;   
	 S2I = 1.0/(sqrt(pow(2.0,(double)intpower))) ;
//	 S2I = pow(2.0, (-(double)intpower)/2.0) ; // pi� elegante 
	 for ( j = 0 ;  j < dimension ; ++j ) // intvalue � la size della matrice 
	 {
		 for ( k = 0 ; k < dimension ; ++k ) 
		 {
			 // is segno � - se il numero di bit == 1 in (j & k) � dispari
			 // NB: questa � il risultato di una versione ridotta di inner product
			 int test = (j & k) ; 
			 int xbit, x, is_parity = 0 ; 
			 for ( xbit = 1, x = 0 ; x < intpower ; ++x, xbit <<= 1 ) 
			 {
				 if ( test & xbit ) is_parity =  (1 - is_parity) ; 
			 }			 
			 dd[(j*dimension)+k].b = 0 ;
			 if ( is_parity ) dd[(j*dimension)+k].a = -S2I ;
			 else dd[(j*dimension)+k].a = S2I ;
		 }
	 }	 
	 break ; 
 }
 return TRUE ; 
}
extern BOOL qx_matrix_constant (int casevalue, double dvalue, qx *dd) 
{
 switch ( casevalue ) 
 {
 default: return FALSE ; 
 case QX_M22_ROTA:  // con angolo theta
	 memset(dd, 0, 4*sizeof(qx) ) ; // tutte matrici di 2 x 2 
	 return FALSE ; // non finito 
	 break ; 
 }
 return TRUE ; 
}

