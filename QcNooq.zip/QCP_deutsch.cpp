/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// QCP_deutsch.cpp : implementation file. Drills for Chapter 6.1 of "Quantum Computing for Programmers and Investors"
//
#include "stdafx.h"
#include "QcNooq.h"

#include "math.h"      // standard C math definition     
#include "QCM_math.h"  // portable definitions 
#include "QCM_tools.h"

#include "QCP_deutsch.h"

// CQCP_deutsch dialog
#ifdef QCNOOQ_WINDOWS
IMPLEMENT_DYNAMIC(CQCP_deutsch, CDialog)
CQCP_deutsch::CQCP_deutsch(CWnd* pParent /*=NULL*/)	: CDialogML(CQCP_deutsch::IDD, pParent)
{
}
CQCP_deutsch::~CQCP_deutsch()
{
}
BOOL CQCP_deutsch::Create(CWnd* pParent)
{
	if (!CDialogML::Create(CQCP_deutsch::IDD, pParent))
	{
		return FALSE;
	}
	return TRUE;
}
void CQCP_deutsch::OnCancel() {DestroyWindow(); theApp.windows_semaphore=0;}
void CQCP_deutsch::DoDataExchange(CDataExchange* pDX)
{
	CDialogML::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC00, m_static00);
	DDX_Control(pDX, IDC_STATIC01, m_static01);
	DDX_Control(pDX, IDC_Shor_verify_0, m_A);
	DDX_Control(pDX, IDC_Shor_verify_1, m_B);
	DDX_Control(pDX, IDC_Shor_verify_2, m_C);
	DDX_Control(pDX, IDC_ALG_deutsch_1_case, m_X);
	DDX_Control(pDX, IDC_ALG_deutsch, m_Y);
}
BEGIN_MESSAGE_MAP(CQCP_deutsch, CDialogML)	
	ON_BN_CLICKED(IDC_Shor_verify_0, &CQCP_deutsch::QCF_Shor_Verify_0)
	ON_BN_CLICKED(IDC_Shor_verify_1, &CQCP_deutsch::QCF_Shor_Verify_1)
	ON_BN_CLICKED(IDC_Shor_verify_2, &CQCP_deutsch::QCF_Shor_Verify_2)
	ON_BN_CLICKED(IDC_ALG_deutsch_1_case, &CQCP_deutsch::QCF_Alg_deutsch_1_case)
	ON_BN_CLICKED(IDC_ALG_deutsch, &CQCP_deutsch::QCF_Alg_Deutsch)
END_MESSAGE_MAP()
void CQCP_deutsch::OnOK(){};
BOOL CQCP_deutsch::OnInitDialog()
{
	CDialogML::OnInitDialog();
	ListMatrixResize(0); // give appropriate sizes
	return TRUE;  // return TRUE  unless you set the focus to a control
}
#endif
// CQCP_deutsch message handlers - the following code is easyly portable remapping the "ListMatrix" calls 
void CQCP_deutsch::QCF_Shor_Verify_0()
{
char buf[200] ; 
qx func_c0[2][2] = { {{1},{1}}, 
                     {{0},{0}} }; // constant function returning 0 
qx func_bi[2][2] = { {{1},{0}}, 
                     {{0},{1}} }; // balanced function returning input
qx func_bn[2][2] = { {{0},{1}}, 
                     {{1},{0}} }; // balanced function returning NOT input
qx func_c1[2][2] = { {{0},{0}}, 
                     {{1},{1}} }; // constant function returning 1
qx input_0[2] = {{1},{0}} ;  // input = |0> 
qx input_1[2] = {{0},{1}} ;  // input = |1> 
qx output [2] ; // destination of the multiplication output
char result ;
 // verify if the function matrix is unitary:
 sprintf ( buf, "Matrix for function returning 0 constant is unitary:%s", qx_matrix_is_unitary(2,(qx *)func_c0) == TRUE ? "YES" : "NO" ) ; ListMatrix(3,buf) ;
 sprintf ( buf, "Matrix for function returning input      is unitary:%s", qx_matrix_is_unitary(2,(qx *)func_bi) == TRUE ? "YES" : "NO" ) ; ListMatrix(0,buf) ;
 sprintf ( buf, "Matrix for function returning NOT input  is unitary:%s", qx_matrix_is_unitary(2,(qx *)func_bn) == TRUE ? "YES" : "NO" ) ; ListMatrix(0,buf) ;
 sprintf ( buf, "Matrix for function returning 1 constant is unitary:%s", qx_matrix_is_unitary(2,(qx *)func_c1) == TRUE ? "YES" : "NO" ) ; ListMatrix(0,buf) ;

 ListMatrix(4,"") ; // empty line
 // trivial verification of 8 cases - 2 input * 4 functions
 qx_matrix_mmul (2,2,1, (qx *)func_c0,  input_0,output) ; result=qx_state_variable_binary_value(2,output,0); sprintf ( buf, "Input = |0>, f(x)=%d, Func = constant 0",result) ; ListMatrix(0,buf,1,2,output) ; 
 qx_matrix_mmul (2,2,1, (qx *)func_c0,  input_1,output) ; result=qx_state_variable_binary_value(2,output,0); sprintf ( buf, "Input = |1>, f(x)=%d, Func = constant 0",result) ; ListMatrix(0,buf,1,2,output) ; 
 qx_matrix_mmul (2,2,1, (qx *)func_bi,  input_0,output) ; result=qx_state_variable_binary_value(2,output,0); sprintf ( buf, "Input = |0>, f(x)=%d, Func = balanced input",result) ; ListMatrix(0,buf,1,2,output) ; 
 qx_matrix_mmul (2,2,1, (qx *)func_bi,  input_1,output) ; result=qx_state_variable_binary_value(2,output,0); sprintf ( buf, "Input = |1>, f(x)=%d, Func = balanced input",result) ; ListMatrix(0,buf,1,2,output) ; 
 qx_matrix_mmul (2,2,1, (qx *)func_bn,  input_0,output) ; result=qx_state_variable_binary_value(2,output,0); sprintf ( buf, "Input = |0>, f(x)=%d, Func = balanced NOT input",result) ; ListMatrix(0,buf,1,2,output) ; 
 qx_matrix_mmul (2,2,1, (qx *)func_bn,  input_1,output) ; result=qx_state_variable_binary_value(2,output,0); sprintf ( buf, "Input = |1>, f(x)=%d, Func = balanced NOT input",result) ; ListMatrix(0,buf,1,2,output) ; 
 qx_matrix_mmul (2,2,1, (qx *)func_c1,  input_0,output) ; result=qx_state_variable_binary_value(2,output,0); sprintf ( buf, "Input = |0>, f(x)=%d, Func = constant 1",result) ; ListMatrix(0,buf,1,2,output) ; 
 qx_matrix_mmul (2,2,1, (qx *)func_c1,  input_1,output) ; result=qx_state_variable_binary_value(2,output,0); sprintf ( buf, "Input = |1>, f(x)=%d, Func = constant 1",result) ; ListMatrix(0,buf,1,2,output) ; 
}
void CQCP_deutsch::QCF_Shor_Verify_1()
{
char buf[200] ; 
qx mout0 [4][4] = {  {{1},{0},{0},{0}},  {{0},{1},{0},{0}}, {{0},{0},{1},{0}}, {{0},{0},{0},{1}},  } ;
qx mouti [4][4] = {  {{1},{0},{0},{0}},  {{0},{1},{0},{0}}, {{0},{0},{0},{1}}, {{0},{0},{1},{0}},  } ;
qx moutni[4][4] = {  {{0},{1},{0},{0}},  {{1},{0},{0},{0}}, {{0},{0},{1},{0}}, {{0},{0},{0},{1}},  } ;
qx mout1 [4][4] = {  {{0},{1},{0},{0}},  {{1},{0},{0},{0}}, {{0},{0},{0},{1}}, {{0},{0},{1},{0}},  } ;
 sprintf ( buf, "Matrix for function returning 0 constant is unitary:%s", qx_matrix_is_unitary(4,(qx *)mout0) == TRUE ? "YES" : "NO" ) ;  ListMatrix(3,buf) ;
 sprintf ( buf, "Matrix for function returning Input      is unitary:%s", qx_matrix_is_unitary(4,(qx *)mouti) == TRUE ? "YES" : "NO" ) ;  ListMatrix(0,buf) ;
 sprintf ( buf, "Matrix for function returning NOT Input  is unitary:%s", qx_matrix_is_unitary(4,(qx *)moutni) == TRUE ? "YES" : "NO" ) ; ListMatrix(0,buf) ;
 sprintf ( buf, "Matrix for function returning 1 constant is unitary:%s", qx_matrix_is_unitary(4,(qx *)mout1) == TRUE ? "YES" : "NO" ) ;  ListMatrix(0,buf) ;
 sprintf ( buf, "Matrix for function returning 0 constant is hermitian:%s", qx_matrix_is_hermitian(4,(qx *)mout0) == TRUE ? "YES" : "NO" ) ;  ListMatrix(0,buf) ;
 sprintf ( buf, "Matrix for function returning Input      is hermitian:%s", qx_matrix_is_hermitian(4,(qx *)mouti) == TRUE ? "YES" : "NO" ) ;  ListMatrix(0,buf) ;
 sprintf ( buf, "Matrix for function returning NOT Input  is hermitian:%s", qx_matrix_is_hermitian(4,(qx *)moutni) == TRUE ? "YES" : "NO" ) ; ListMatrix(0,buf) ;
 sprintf ( buf, "Matrix for function returning 1 constant is hermitian:%s", qx_matrix_is_hermitian(4,(qx *)mout1) == TRUE ? "YES" : "NO" ) ;  ListMatrix(0,buf) ;

}
void CQCP_deutsch::QCF_Shor_Verify_2()
{
char buf[200] ; 
qx mout0 [4][4] = {  {{1},{0},{0},{0}},  {{0},{1},{0},{0}}, {{0},{0},{1},{0}}, {{0},{0},{0},{1}},  } ;
qx mouti [4][4] = {  {{1},{0},{0},{0}},  {{0},{1},{0},{0}}, {{0},{0},{0},{1}}, {{0},{0},{1},{0}},  } ;
qx moutni[4][4] = {  {{0},{1},{0},{0}},  {{1},{0},{0},{0}}, {{0},{0},{1},{0}}, {{0},{0},{0},{1}},  } ;
qx mout1 [4][4] = {  {{0},{1},{0},{0}},  {{1},{0},{0},{0}}, {{0},{0},{0},{1}}, {{0},{0},{1},{0}},  } ;
char *func_description[] = { "constant 0", "input", "not input", "constant 1" } ;
qx input_00[4] = {{1},{0},{0},{0}}; // input with x = 0 , y = 0 
qx input_01[4] = {{0},{1},{0},{0}}; // input with x = 0 , y = 1 
qx input_10[4] = {{0},{0},{1},{0}}; // input with x = 1 , y = 0 
qx input_11[4] = {{0},{0},{0},{1}}; // input with x = 1 , y = 1 
qx output[4] ; 
qx *Ufunc [4] = {(qx *)mout0,(qx *)mouti,(qx *)moutni,(qx *)mout1} ;
qx *invec[4] = {(qx *)input_00,(qx *)input_01,(qx *)input_10,(qx *)input_11} ;
char fx, j, k ; 
char x_input, y_input,  y_xor_fx ; // value of x and y^f(x) in resulting state 
 ListMatrix(3, "Calculation through unitary function matrices" ) ; 
 for ( j = 0 ; j < 4 ; ++j ) 
 {	 
	 ListMatrix(0, func_description[j] ) ; 
	 for ( k = 0 ; k < 4 ; ++k ) 
	 {
		 qx_matrix_mmul(4,4,1,(qx *)Ufunc[j], (qx *)invec[k], output) ;
		 x_input = qx_state_variable_binary_value(4, invec[k], 0) ; // retrieve value of x in input state 
         y_input = qx_state_variable_binary_value(4, invec[k], 1) ; // retrieve value of y in input state 
		 y_xor_fx= qx_state_variable_binary_value(4, output, 1) ;    // retrieve value of y^f(x) in output state 
		 fx = y_xor_fx ^ y_input ;               // calculate fx from reversible output
		 sprintf ( buf, "Unitary function:%d (%s) applied to input %d: x=%d, y=%d, y^fx=%d, fx=%d" , j, func_description[j], k, x_input, y_input, y_xor_fx, fx ) ; 
		 ListMatrix(0, buf, 1,4, output ) ; 
	 }
	 ListMatrix(4,"") ; // empty line
 }
}
void CQCP_deutsch::QCF_Alg_deutsch_1_case()  // one input, one output 
{
char buf[200] ;
// U matrix corresponding to the function returnng NOT input
qx moutni[4][4] = {  {{0},{1},{0},{0}},  {{1},{0},{0},{0}}, {{0},{0},{1},{0}}, {{0},{0},{0},{1}},  } ;
// input corresponding to |01>, i.e. x = 0 , y = 1 
qx input_01[4] = {{0},{1},{0},{0}}; 

 // initialize the necessary constant matrices
qx ha[2][2], IDE1[2][2], haha[4][4], haid[4][4] ; 
 qx_matrix_constant(QX_M22_HADA,    (qx *)ha) ;     // Hadamard 
 qx_matrix_constant(QX_M22_IDEN, 1, (qx *)IDE1) ;   // Identity
 qx_matrix_tensor_product(2,2,2,2, (qx *)ha,(qx *)ha,(qx *)haha) ;     // Hadamard for 2 variables
 qx_matrix_tensor_product(2,2,2,2, (qx *)ha,(qx *)IDE1,(qx *)haid) ;   // Hadamard on x, Identity on y

// output states 
qx phi1[4], phi2[4], phi3[4], measured[4] ; 
char x_in_output ; 
 ListMatrix(3, "DEUTSCH on input |01> and function returning NOT input") ; 

 // act with Hadamard 
 qx_matrix_mmul(4,4,1,(qx *)haha, (qx *)input_01, phi1) ; 
 sprintf ( buf, "Deutsch function after first HAHA" ) ; ListMatrix(0, buf, 1,4, phi1 ) ; 

 // act with the chosen function
 qx_matrix_mmul ( 4,4,1, (qx *)moutni, phi1, phi2 ) ; 
 sprintf ( buf, "Deutsch function after function" ) ; ListMatrix(0, buf, 1,4, phi2 ) ; 

 // act with Hadamard on x only
 qx_matrix_mmul ( 4,4,1, (qx *)haid, phi2, phi3 ) ; 
 sprintf ( buf, "Deutsch function after HAID" ) ; ListMatrix(0, buf, 1,4, phi3 ) ; 

 // execute the measurement
 qx_state_measurement(4, phi3, measured) ;
 // catch the measured bit - executing the procedure more than once it will change randomly
 x_in_output = qx_state_variable_binary_value(4, measured, 0) ;    // retrieve value of x (variable of index 0) in output state 
 sprintf ( buf, "Deutsch function after measurement. Value of x in output after measurement = %d", x_in_output ) ; 
 ListMatrix(0, buf, 1,4, measured ) ; 
}
void CQCP_deutsch::QCF_Alg_Deutsch() //  Deutsch, verification for 4 x 4 cases
{
char buf[200] ;
work_in_progress_show(1) ; 
// matrici U che dati x e y danno x e y^f(x)
qx mout0 [4][4] = {  {{1},{0},{0},{0}},  {{0},{1},{0},{0}}, {{0},{0},{1},{0}}, {{0},{0},{0},{1}},  } ;
qx mouti [4][4] = {  {{1},{0},{0},{0}},  {{0},{1},{0},{0}}, {{0},{0},{0},{1}}, {{0},{0},{1},{0}},  } ;
qx moutni[4][4] = {  {{0},{1},{0},{0}},  {{1},{0},{0},{0}}, {{0},{0},{1},{0}}, {{0},{0},{0},{1}},  } ;
qx mout1 [4][4] = {  {{0},{1},{0},{0}},  {{1},{0},{0},{0}}, {{0},{0},{0},{1}}, {{0},{0},{1},{0}},  } ;
char *func_description[] = { "constant 0", "input", "not input", "constant 1" } ;
qx *Ufunc [4] = {(qx *)mout0,(qx *)mouti,(qx *)moutni,(qx *)mout1} ;
qx input_00[4] = {{1},{0},{0},{0}}; // input with x = 0 , y = 0 
qx input_01[4] = {{0},{1},{0},{0}}; // input with x = 0 , y = 1 
qx input_10[4] = {{0},{0},{1},{0}}; // input with x = 1 , y = 0 
qx input_11[4] = {{0},{0},{0},{1}}; // input with x = 1 , y = 1 
qx *invec[4] = {(qx *)input_01, (qx *)input_00,(qx *)input_10,(qx *)input_11} ;
char j, k ; 
char x_input, y_input,  x_in_output ; // value of x and y^f(x) in resulting state 
qx phi1[4], phi2[4], phi3[4], measured[4] ; 
qx ha[2][2], IDE1[2][2], haha[4][4], haid[4][4] ; 

 // initialize the necessary constants
 qx_matrix_constant(QX_M22_HADA,    (qx *)ha) ; 
 qx_matrix_constant(QX_M22_IDEN, 1, (qx *)IDE1) ; 
 qx_matrix_tensor_product(2,2,2,2, (qx *)ha,(qx *)ha,(qx *)haha) ;
 qx_matrix_tensor_product(2,2,2,2, (qx *)ha,(qx *)IDE1,(qx *)haid) ; 
 ListMatrix(3, "DEUTSCH") ; 

 // now let us calculate Deutsch for the 4 possibile input and functions 
 // first let us calculate Deutsch for the case discussed in literature, with input x=|0>, y=|1> (first case in invec list)
 // the value of x_in_output is 0 for constant, 1 for balanced, as expected
 // Then notice that in the case of x=|1>, y=|1> we have 1 for constant, 0 for balanced, as expected - so this case could be used too
 // The other two inputs give a constant value for x_in_output

 for ( k = 0 ; k < 4 ; ++k ) // to try 4 possbile inputs  
 {
	 x_input = qx_state_variable_binary_value(4, invec[k], 0) ; // retrieve value of x in input state 
     y_input = qx_state_variable_binary_value(4, invec[k], 1) ; // retrieve value of y in input state 
	 sprintf ( buf, "Deutsch for input %d x=%d y=%d", k, x_input, y_input ) ; 
	 ListMatrix(0, buf) ; 
	 for ( j = 0 ; j < 4 ; ++j )  // try 4 functions
	 {
		 sprintf ( buf, "Deutsch function:%d (%s) INITIAL STATE of input %d: x=%d, y=%d " , j, func_description[j], k, x_input, y_input ) ; 
		 ListMatrix(0, buf, 1,4, invec[k] ) ; 

		 qx_matrix_mmul(4,4,1,(qx *)haha, (qx *)invec[k], phi1) ; 
	     sprintf ( buf, "Deutsch function:%d (%s) after first HAHA applied to input %d: " , j, func_description[j], k ) ; 
		 ListMatrix(0, buf, 1,4, phi1 ) ; 

		 qx_matrix_mmul ( 4,4,1, Ufunc[j], phi1, phi2 ) ; 
		 sprintf ( buf, "Deutsch function:%d (%s) after func applied to input %d: " , j, func_description[j], k ) ; 
		 ListMatrix(0, buf, 1,4, phi2 ) ; 

		 qx_matrix_mmul ( 4,4,1, (qx *)haid, phi2, phi3 ) ; 
         sprintf ( buf, "Deutsch function:%d (%s) after HAID applied to input %d: x=%d, y=%d " , j, func_description[j], k, x_input, y_input ) ; 
		 ListMatrix(0, buf, 1,4, phi3 ) ;		 

		 qx_state_measurement(4, phi3, measured) ;
		 x_in_output = qx_state_variable_binary_value(4, measured, 0) ;    // retrieve value of x in output state 
		 sprintf ( buf, "Deutsch function:%d (%s) MEASURED applied to input %d: x=%d, y=%d, x_in_output=%d" , j, func_description[j], k, x_input, y_input, x_in_output ) ; 
		 ListMatrix(0, buf, 1,4, measured ) ;		 
	 }
	 ListMatrix(4,"") ; // empty line	
 }	 
 work_in_progress_show(0) ; 
}




