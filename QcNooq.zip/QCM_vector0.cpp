/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// Vector operations
//

#include "stdafx.h"
#include <math.h>  
#include "QCM_Math.h"

extern void qx_vector_negate( int size, qx *v0, qx *vresult ) 
{
int k ; 
 for ( k = 0 ; k < size ; ++k ) 
 {
	 vresult[k] = qx_negate( v0[k] ) ; 
 }
}
extern void qx_vector_add ( int size, qx *v0, qx *v1, qx *vresult ) 
{
int k ; 
 for ( k = 0 ; k < size ; ++k ) 
 {
	 vresult[k] = qx_add( v0[k], v1[k] ) ; 
 }
}
extern qx qx_vector_sum (int size, qx *v0)
{
qx result ; result.a = 0.0 ; result.b = 0.0 ; 
int k ; 
 for ( k = 0 ; k < size ; ++k ) 
 {
	 result = qx_add( result, v0[k] ) ; 
 }
 return result ; 
}
extern double qx_vector_moduli_squared_sum (int size, qx *v0)
{
double result = 0.0 ; 
int k ; 
 for ( k = 0 ; k < size ; ++k ) 
 {
	 result += qx_modulus_squared(v0[k])  ; 
 }
 return result ; 
}
extern void qx_vector_smul ( int size, qx  c0, qx *v0, qx *vresult )
{
int k ; 
 for ( k = 0 ; k < size ; ++k ) 
 {
	 vresult[k] = qx_mul( c0, v0[k] ) ; 
 }
}
extern void qx_vector_conjugate ( int n, qx *v0, qx *vresult ) 
{
int k ; 
   if ( vresult == NULL ) vresult = v0 ; // if no destination, transform the source vector
   for ( k = 0 ; k < n ; ++k ) 
   {
	 vresult[k] = qx_conjugate( v0[k] ) ; 
   }
}
extern qx   qx_vector_conjugate_and_inner_product( int size, qx *v0, qx *v1 ) 
{
qx vx, cresult = {0,0} ;
int k ; 
 for ( k = 0 ; k < size ; ++k ) 
 {
	vx = qx_conjugate(v0[k]) ; 
	vx = qx_mul(vx,v1[k]) ; 
	cresult = qx_add(cresult,vx) ; 
 }
 return cresult ; 
}
extern BOOL qx_vector_normalize( int size, qx *v0, qx *vresult ) 
{
qx qxlen ; // poi interessa solo la parte reale
int k ; 
 qxlen = qx_vector_conjugate_and_inner_product(size, v0, v0) ; 
 if ( ! qx_double_equal_enough(qxlen.b, 0.0) ) return FALSE ; // non deve essere
 qxlen.b = 0 ; // via, se ci fosse dentro un residuo del f.p.
 qxlen.a = sqrt(qxlen.a) ; 
 // evitiamo divisori molto piccoli 
 if ( qx_double_equal_enough ( qxlen.a, 0.0 ) ) return FALSE ;  
 for ( k = 0 ; k < size ; ++k ) 
 {
	qx_div(v0[k], qxlen, vresult+k ) ; 
 }
 return TRUE ; 
}
// per il vettore la distanza si pu� trovare membro per membro, senza bisogno del vettore trasformato intermedio:
extern qx   qx_vector_distance_square( int size, qx *v0, qx *v1 ) 
{
qx vx, vxc, cresult = {0,0} ;
int k ; 
 for ( k = 0 ; k < size ; ++k ) 
 {
    vx  = qx_negate(v1[k]) ; 
	vx  = qx_add(v0[k], vx) ;
	vxc = qx_conjugate(vx) ; 
	vx  = qx_mul(vx,vxc) ; 
	cresult = qx_add(cresult,vx) ; 
 }
 return cresult ; 
}
// � quella della matrice tagliata di quanto non serve - trivial 
extern void qx_vector_tensor_product( int m,  int p,  qx *m0, qx *m1, qx *mresult ) 
{
int j,  a,  row   ; 

 // percorro m0 sulle sue dimensioni
 for ( j = 0 ; j < m ; ++j ) 
 {
	 	 for ( a = 0 ; a < p ; ++a ) // percorro m1 sulle sue dimensioni 
		 {
			 	 row = a +(j*p) ; 				 
				 mresult[row ] = qx_mul(m0[j], m1[a]) ;			 
		 }	 
 }
}
// implementation for bit of vectors of size sizeof(unsigned int)
// the operation returns a bit, which is the parity of the number of cases where both bits are 1
extern char   qx_bit_inner_product( int size, unsigned int v0, unsigned int v1 ) 
{
unsigned int vr, test ; 
int k ; 
char cresult = 0 ; 
 vr = v0 & v1 ; 
 for ( test = 1,  k = 0 ; k < size ; ++k, test <<= 1 ) 
 {
	if ( vr & test ) cresult = 1-cresult ; 
 }
 return cresult ; 
}
