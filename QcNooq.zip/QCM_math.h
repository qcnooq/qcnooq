/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020 ISBN: 9788897527541 
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// math defs 
#ifndef QCM_math_h_included_q1w2e3r4t5y6u7i8o9
 #define QCM_math_h_included_q1w2e3r4t5y6u7i8o9

// obvious constants 
#define QX_C_EULERO		2.71828182845904523536
#define QX_C_PIGRECO	3.14159265358979323846

typedef unsigned char byte;
typedef unsigned long long unsigned_64_bit;
typedef long long int_64_bit;
// types 
typedef  struct s_qx { double a; double b ;}  qx;
//typedef  struct s_qx { float a; float b ;}  qx;   // alternate definition to manage huge data

// per inizializzare una matrice senza rimbambire
typedef struct s_qx_init_trick { char lettera ; qx c ; } qxit ;

// TOOLS 
extern BOOL qx_double_equal_enough (double c0, double c1)  ;
extern BOOL qx_complex_equal_enough (qx c0, qx c1)  ;

// tricks 
extern void qx_matrix_init(int r, int c, qxit *key, int keynum, char *schema, qx *destination) ; 
extern void qx_matrix_to_squared_modulus(int r, int c, qx *origin, qx *destination) ; 

// inizializzazione delle matrici 2x2 costanti notevoli 
#define QX_M22_IDEN		100  // con dimensione matrice quadrata da inizializzare
#define QX_M22_HADA		101
#define QX_M22_PAULIX	102
#define QX_M22_PAULIY	103
#define QX_M22_PAULIZ	104
#define QX_M22_S		105
#define QX_M22_T		106
#define QX_M22_SQNOT	107
#define QX_M22_ROTA		201   // with theta angle
#define QX_M22_VANDERMONDE   202   // Vandermonde
#define QX_M88_TOFFOLI  801
#define QX_M88_FREDKIN  802

extern BOOL qx_matrix_constant (int casevalue, qx *destination) ; 
extern BOOL qx_matrix_constant (int casevalue, int intpower, qx *destination) ; 
extern BOOL qx_matrix_constant (int casevalue, double dvalue, qx *destination) ; 

// proto of calculations 
extern qx qx_negate(qx c0) ;
extern BOOL qx_iszero(qx c0) ;
extern qx qx_conjugate(qx c0) ;
extern BOOL qx_equal(qx c0, qx c1) ;  
extern qx qx_add(qx c0, qx c1) ;  
extern qx qx_mul(qx c0, qx c1) ;  
extern BOOL qx_div(qx c0, qx c1, qx *resp) ;  // test divide by zero 
extern double qx_modulus_squared (qx c1) ;

extern void qx_vector_negate( int size, qx *v0, qx *vresult ) ;
extern void qx_vector_add ( int size, qx *v0, qx *v1, qx *vresult ) ;
extern qx qx_vector_sum (int size, qx *v0) ;
extern double qx_vector_moduli_squared_sum (int size, qx *v0) ;
extern void qx_vector_smul( int size, qx  c0, qx *v0, qx *vresult ) ;
extern void qx_vector_conjugate ( int m, qx *v0, qx *vresult ) ;
extern qx   qx_vector_conjugate_and_inner_product( int size, qx *v0, qx *v1 ) ;
extern qx   qx_vector_distance_square( int size, qx *v0, qx *v1 ) ;
extern void qx_vector_tensor_product( int m, int p, qx *v0, qx *v1, qx *vresult ) ;
extern BOOL qx_vector_normalize( int size, qx *v0, qx *vresult ) ;

// special operation for bit vectors
extern char   qx_bit_inner_product( int size, unsigned int v0, unsigned int v1 )  ;

extern void qx_matrix_negate( int m, int n, qx *m0, qx *mresult ) ;
extern void qx_matrix_add ( int m, int n, qx *m0, qx *m1, qx *mresult ) ;
extern void qx_matrix_smul( int m, int n, qx  c0, qx *m0, qx *mresult ) ;

extern void qx_matrix_transpose ( int m, int n, qx *m0, qx *mresult ) ;
extern void qx_matrix_conjugate ( int m, int n, qx *m0, qx *mresult ) ;
extern void qx_matrix_adjoint   ( int m, int n, qx *m0, qx *mresult ) ;

extern void qx_matrix_mmul( int m, int n, int p,  qx *m0, qx *m1, qx *mresult ) ;
extern void qx_matrix_boolean_mmul( int m, int n, int p,  qx *m0, qx *m1, qx *mresult ) ;
extern qx   qx_matrix_trace(int n, qx *m0) ; 
extern void qx_matrix_tensor_product( int m, int n, int p, int q,   qx *m0, qx *m1, qx *mresult ) ;
extern BOOL qx_matrix_is_doubly_stochastic(int m, qx *m0) ; 
extern BOOL qx_matrix_is_hermitian(int m, qx *m0) ; 
extern BOOL qx_matrix_is_unitary(int m, qx *m0) ; 

extern int qx_check_measured_state (int size, qx *v0) ;
extern char qx_state_variable_binary_value (int size, qx *v0, int n_variable) ;
extern BOOL qx_state_measurement (int size, qx *v0, qx *mresult) ;

/* da aggiungere  allorch� servono:
qx_matrix_adjoint = transpose + conjugate 
qx_matrix_star per due matrici aventi una dimensione in comune 
/**/

// used in implementation of Shor's algorithm
extern unsigned short qx_Euclid_GCD_double(double a, unsigned short b) ;
extern unsigned short qx_Euclid_GCD_16(unsigned short a, unsigned short b) ;
extern unsigned short qx_Euclid_GCD_16_r(unsigned short m, unsigned short n);
extern unsigned short qx_a_powx_modN_16 (unsigned short a, unsigned short x, unsigned short N);
extern unsigned short qx_a_powx_modN_16 (unsigned short a, unsigned short x, unsigned short N, unsigned int *);
extern unsigned short qx_period_16 (unsigned short a, unsigned short N);
extern unsigned int qx_Euclid_GCD_32(unsigned int a, unsigned int b) ;
extern unsigned int qx_Euclid_GCD_32_r(unsigned int m, unsigned int n);

// utilities:
extern int qx_random(); 

// utilities for formatting:
extern char * qx_format(qx c0) ; 
extern char * qx_binary_output ( int,  unsigned int number ) ;
extern char * qx_vector_qx_to_binary_output( int, qx *) ; 
extern void   qx_binary_output ( char *, int,  unsigned int number ) ;
extern void   qx_binary_vector ( char *, int,  unsigned int number ) ;
#endif 
// eof 