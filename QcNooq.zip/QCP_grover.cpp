/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// QCP_Grover.cpp : implementation file. Drills for Chapter 6.4 of "Quantum Computing for Programmers and Investors"
//

#include "stdafx.h"
#include "QcNooq.h"

#include "math.h"      // standard C math definition     
#include "QCM_math.h"  // portable definitions 
#include "QCM_tools.h"

#include "QCP_Grover.h"


// CQCP_grover dialog
#ifdef QCNOOQ_WINDOWS
IMPLEMENT_DYNAMIC(CQCP_grover, CDialog)

CQCP_grover::CQCP_grover(CWnd* pParent /*=NULL*/) : CDialogML(CQCP_grover::IDD, pParent)
{
}
CQCP_grover::~CQCP_grover()
{
}
BOOL CQCP_grover::Create(CWnd* pParent)
{
	if (!CDialogML::Create(CQCP_grover::IDD, pParent))
	{
		return FALSE;
	}
	return TRUE;
}
void CQCP_grover::OnCancel() {DestroyWindow(); theApp.windows_semaphore=0;}
void CQCP_grover::DoDataExchange(CDataExchange* pDX)
{
	CDialogML::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_number_of_bits, m_number_of_bits);
	DDX_Control(pDX, IDC_number_of_iterations, m_number_of_iterations);
	DDX_Control(pDX, IDC_progress1, m_progress1);
	DDX_Control(pDX, IDC_STATIC00, m_static00);
	DDX_Control(pDX, IDC_STATIC01, m_static01);
	DDX_Control(pDX, IDC_STATIC03, m_static03);
	DDX_Control(pDX, IDC_Grover_3bit_func_1, m_A);
	DDX_Control(pDX, IDC_Grover_3bit_func_Uf, m_B);
	DDX_Control(pDX, IDC_Grover_3bit_inversion_matrix, m_C);
	DDX_Control(pDX, IDC_Grover_3bit_inversion_sample, m_D);
	DDX_Control(pDX, IDC_QCF_Grover_3bit_algorithm, m_E);
	DDX_Control(pDX, IDC_QCF_Grover_3bit_algorithm_verbose, m_Ev);
	DDX_Control(pDX, IDC_Grover_3bit_stat, m_F);
	DDX_Control(pDX, IDC_Grover_Nbit_func_1, m_bA);
	DDX_Control(pDX, IDC_Grover_Nbit_func_Uf, m_bB);
	DDX_Control(pDX, IDC_Grover_Nbit_inversion_matrix, m_bC);
	DDX_Control(pDX, IDC_QCF_Grover_Nbit_algorithm, m_bE);
	DDX_Control(pDX, IDC_Grover_Nbit_stat, m_bF);
	DDX_Control(pDX, IDC_Grover_Nbit_find_optimal_iterations, m_bG);
}
BEGIN_MESSAGE_MAP(CQCP_grover, CDialogML)
	ON_BN_CLICKED(IDC_Grover_3bit_func_1, &CQCP_grover::QCF_Grover_3bit_func1)
	ON_BN_CLICKED(IDC_Grover_3bit_func_Uf, &CQCP_grover::QCF_Grover_3bit_func_Uf)
	ON_BN_CLICKED(IDC_Grover_3bit_inversion_matrix, &CQCP_grover::QCF_Grover_3bit_inversion_matrix)
	ON_BN_CLICKED(IDC_QCF_Grover_3bit_algorithm, &CQCP_grover::QCF_Grover_3bit_algorithm)
	ON_BN_CLICKED(IDC_Grover_3bit_stat, &CQCP_grover::QCF_Grover_3bit_stat)
	ON_CBN_SELCHANGE(IDC_number_of_bits, &CQCP_grover::OnCbnSelchangevaluetotry)

	ON_BN_CLICKED(IDC_Grover_Nbit_func_1, &CQCP_grover::QCF_Grover_Nbit_func1)
	ON_BN_CLICKED(IDC_Grover_Nbit_func_Uf, &CQCP_grover::QCF_Grover_Nbit_func_Uf)
	ON_BN_CLICKED(IDC_Grover_Nbit_inversion_matrix, &CQCP_grover::QCF_Grover_Nbit_inversion_matrix)
	ON_BN_CLICKED(IDC_QCF_Grover_Nbit_algorithm, &CQCP_grover::QCF_Grover_Nbit_algorithm)
	ON_BN_CLICKED(IDC_Grover_Nbit_stat, &CQCP_grover::QCF_Grover_Nbit_stat)
	ON_CBN_SELCHANGE(IDC_number_of_iterations, &CQCP_grover::OnCbnSelchangenumberofiterations)
	ON_BN_CLICKED(IDC_Grover_3bit_inversion_sample, &CQCP_grover::QCF_Grover_3bit_inversion_sample)
	ON_BN_CLICKED(IDC_Grover_Nbit_find_optimal_iterations, &CQCP_grover::QCF_Grover_Nbit_find_optimal_iterations)
	ON_BN_CLICKED(IDC_QCF_Grover_3bit_algorithm_verbose, &CQCP_grover::QCF_QcfGrover3bitalgorithmverbose)
END_MESSAGE_MAP()
void CQCP_grover::OnOK(){};
BOOL CQCP_grover::OnInitDialog()
{
int k ; 
char buf [20] ;
	CDialogML::OnInitDialog();
	ListMatrixResize(0); // give appropriate sizes
	for ( k = 2 ; k <= 7 ; ++k ) 
	{
		sprintf(buf, "%d", k ) ; 
		m_number_of_bits.AddString(buf) ; 
	}
	m_number_of_bits.SetCurSel(2) ; number_of_bits = 4 ; 
	m_number_of_iterations.AddString("default") ; 
	for ( k = 2 ; k <= 127 ; ++k ) 
	{
		sprintf(buf, "%d", k ) ; 
		m_number_of_iterations.AddString(buf) ; 
	}
	m_number_of_iterations.SetCurSel(0) ; number_of_iterations = 0 ;  // default
	return TRUE;  // return TRUE  unless you set the focus to a control
}
// CQCP_grover message handlers - Only Windows implementation:
void CQCP_grover::OnCbnSelchangevaluetotry()
{
 number_of_bits = m_number_of_bits.GetCurSel() + 2 ; 
 if ( number_of_bits < 2 || number_of_bits > 7 ) number_of_bits = 4 ; 
 QCF_Grover_Nbit_algorithm(1,-1, NULL); // zero statistics if number changed
}
void CQCP_grover::OnCbnSelchangenumberofiterations()
{
 number_of_iterations = m_number_of_iterations.GetCurSel()+1 ; 
 if ( number_of_iterations < 2 || number_of_iterations > 127 ) number_of_iterations = 0 ; 
 QCF_Grover_Nbit_algorithm(1,-1, NULL); // zero statistics if number changed
}
#endif
// Grover 3 Bit functions:
#define GROVER_3BIT_VALUE 5
byte CQCP_grover::QCF_Grover_3bit_base_function(byte input)
{
 if ( input == GROVER_3BIT_VALUE ) return 1 ; 
 else return 0 ; 
}
void CQCP_grover::QCF_Grover_3bit_func1()
{
char buf[200] ; 
byte x, y ;  
 ListMatrix(3,"Values returned from the sample 3 bit function implemented trivially" ) ;
 for ( x = 0 ; x < 8 ; ++x ) 
 {	
	y = QCF_Grover_3bit_base_function(x) ;
	sprintf (buf,"Input = %d (%s), output = %d", x, qx_binary_output(3,x), y ) ; 
	ListMatrix(0, buf) ; 
 }
}
void CQCP_grover::QCF_Build_Grover_3bit_func_Uf(qx Ufunc[16][16])
{
byte x, y, fx, y_xor_fx ;  
int row, col ; 
 memset(Ufunc, 0, 16*16*sizeof(qx)) ; 
 for ( x = 0 ; x < 8 ; ++x ) 
 {
	 for ( y = 0 ; y <= 1 ; ++y ) 
	 {
		 fx = QCF_Grover_3bit_base_function(x) ;
		 y_xor_fx = y^fx ; 
		 row = x * 2 + y  ; 
		 col = x * 2 + y_xor_fx  ;  
		 Ufunc[row][col].a = 1 ; 
	 }
 }
}
void CQCP_grover::QCF_Grover_3bit_func_Uf()
{
char buf[200] ; 
qx Ufunc[16][16] ; 
byte x, y, fx, y_xor_fx ;  
qx phi0[16], phi1[16] ; 

 QCF_Build_Grover_3bit_func_Uf(Ufunc);
 ListMatrix(3,"Values returned from the sample 3 bit function implemented as Uf") ;
 ListMatrix(0,"",16,16,(qx *)Ufunc ) ;
 for ( x = 0 ; x < 8 ; ++x ) 
 {	
    y = 0 ; // could be 1 
    memset ( phi0, 0, sizeof(phi0) ) ; 
	phi0[x*2+y].a = 1.0 ; // input data 
	qx_matrix_mmul(16,16,1, (qx *)Ufunc, phi0, phi1) ; 
	// Notice that the binary variable to be extracted is 3, i.e. the fourth bit
	y_xor_fx = qx_state_variable_binary_value(16,phi1,3) ; 
	fx = y^y_xor_fx ;
	sprintf (buf,"Input = %d (%s), output = %d", x, qx_binary_output(3,x), fx) ; 
	ListMatrix(0, buf) ; 
 }
}
void CQCP_grover::QCF_Build_Grover_3bit_average_inversion_matrix(int size, qx *MI2A) 
{
int  r, c ; 
 for ( r = 0 ; r < size ; ++r ) 
 {
	 for ( c = 0 ; c < size ; ++c ) 
	 {
         // Take care of floating point. Do not calculate an integer division:
		 if ( r == c ) MI2A[r*size+c].a = -1.0 + (2.0/(double)size) ;
		 else MI2A[r*size+c].a = (2.0/(double)size) ; 
		 MI2A[r*size+c].b = 0 ; 		 
	 }
 }
}
void CQCP_grover::QCF_Grover_3bit_inversion_matrix()
{
char buf[200] ; 
qx M_IDE_2A[8][8] ; 
 QCF_Build_Grover_3bit_average_inversion_matrix(8, (qx *)M_IDE_2A) ;
 sprintf ( buf, "M_IDE_2A is unitary=%s, is hermitian=%s", qx_matrix_is_unitary(8,(qx *)M_IDE_2A) ? "yes" : "no", qx_matrix_is_hermitian(8,(qx *)M_IDE_2A) ? "yes" : "no"  ) ; 
 ListMatrix(3,buf) ; 
 ListMatrix(0, "Inversion about the mean matrix for 3 bit input",8,8, (qx *)M_IDE_2A) ; 
}
void CQCP_grover::QCF_Grover_3bit_inversion_sample()
{
char buf[200] ;
#define GMSIZE 4
qx vector[GMSIZE] = {{22},{37},{5},{12}} ;
qx vector_t[GMSIZE]  ;
double average ; 
int k, j ;
qx average_matrix[GMSIZE][GMSIZE] ; 
 average = 0 ; 
 for ( k = 0 ; k < GMSIZE ; ++k ) 
 {
	 average += vector[k].a ; 
 }
 average /= GMSIZE ; 
 sprintf ( buf, "Input Vector. Average is %f", average) ; 
 ListMatrix(3, buf, 1,GMSIZE,vector) ; 
 for ( k = 0 ; k < GMSIZE ; ++k ) {
	 for ( j = 0 ; j < GMSIZE ; ++j ) {
		 average_matrix[k][j].a = 1.0/(double)GMSIZE ; 
		 average_matrix[k][j].b = 0 ; 
	 }
 }
 sprintf ( buf, "Average matrix - unitary:%s hermitian:%s", qx_matrix_is_unitary(GMSIZE,(qx *)average_matrix) ? "yes" : "no", qx_matrix_is_hermitian(GMSIZE,(qx *)average_matrix) ? "yes" : "no"  ) ;
 ListMatrix(0, buf, GMSIZE,GMSIZE, (qx *)average_matrix) ;
 qx_matrix_mmul(GMSIZE,GMSIZE,1, (qx *)average_matrix,vector, vector_t);
 ListMatrix(0, "Vector transformed by average matrix", 1,GMSIZE,vector_t) ;
 QCF_Build_Grover_3bit_average_inversion_matrix(GMSIZE, (qx *)average_matrix) ;
 sprintf ( buf, "Inversion about mean matrix - unitary:%s hermitian:%s", qx_matrix_is_unitary(GMSIZE,(qx *)average_matrix) ? "yes" : "no", qx_matrix_is_hermitian(GMSIZE,(qx *)average_matrix) ? "yes" : "no"  ) ;
 ListMatrix(0, buf, GMSIZE,GMSIZE, (qx *)average_matrix) ;
 qx_matrix_mmul(GMSIZE,GMSIZE,1, (qx *)average_matrix,vector, vector_t);
 ListMatrix(0, "Vector transformed by inversion matrix", 1,GMSIZE,vector_t) ;
}
void CQCP_grover::QCF_Grover_3bit_algorithm(char verbose, int num_samples)
{
char buf[200] ;
qx Ufunc[16][16] ; 
 QCF_Build_Grover_3bit_func_Uf(Ufunc);
qx M_IDE_2A[8][8] ; 
 QCF_Build_Grover_3bit_average_inversion_matrix(8, (qx *)M_IDE_2A) ;
qx HA[2][2] ; 
qx HA3[8][8] ;
qx HA4[16][16] ;
qx IDE1[2][2] ; 
qx IDE3[8][8] ; 
qx IDE3HA[16][16] ; 
qx HA3IDE[16][16] ; 
qx M_IDE_2A_IDE[16][16] ; 
 qx_matrix_constant(QX_M22_HADA, (qx *)HA) ; 
 qx_matrix_constant(QX_M22_HADA,4,(qx *)HA4) ; 
 qx_matrix_constant(QX_M22_HADA,3,(qx *)HA3) ; 
 qx_matrix_constant(QX_M22_IDEN, (qx *)IDE1) ; 
 qx_matrix_constant(QX_M22_IDEN,3,(qx *)IDE3) ; 
 qx_matrix_tensor_product(8,8,2,2,(qx *)M_IDE_2A,(qx *)IDE1, (qx *)M_IDE_2A_IDE) ; 
 qx_matrix_tensor_product(8,8,2,2,(qx *)IDE3,(qx *)HA, (qx *)IDE3HA) ; 
 qx_matrix_tensor_product(8,8,2,2,(qx *)HA3,(qx *)IDE1, (qx *)HA3IDE) ; 
int iteration ; 
byte xout ; 
qx phi0[16], phi1[16],  phi2[16], phi3[16], phi4[16], measured[16] ; 
static int total_ok=0, total_ko=0, total; 
byte classical_fx = GROVER_3BIT_VALUE ; // value to be found 
int sample ; 

 for ( sample = 0 ; sample < num_samples ; ++sample ) 
 { 
	 memset( phi0, 0, sizeof(phi0) ) ; 
	 // ww must initialize phi0 with x[3] = 0, y = 1, so the significant element is:
	 phi0[1].a = 1.0 ; 
	 if ( verbose ) ListMatrix(0,"Grover 3 bit phi0",1,16, phi0) ; 
	 // first step:
	 qx_matrix_mmul(16,16,1,(qx *)HA3IDE, phi0, phi1) ; 	 	 
	 if ( sample == num_samples-1 ) ListMatrix(0,"Grover 3 bit phi1",1,16, phi1) ; 
	 // iterations 
#define ITERATIONS_3BIT 3
	 for ( iteration = 0 ; iteration < ITERATIONS_3BIT ; ++iteration )
	 {			
		 if ( verbose && iteration > 0 && sample == num_samples-1 ){ 
			 sprintf ( buf, "Iteration %d phi1", iteration+1 ) ; 
			 ListMatrix(0,buf,1,16,phi1) ; 
		 } 
		 qx_matrix_mmul(16,16,1, (qx *)IDE3HA, phi1, phi2) ; 
		 if ( verbose && sample == num_samples-1 ){ 
			 sprintf ( buf, "Iteration %d phi2", iteration+1 ) ; 
			 ListMatrix(0,buf,1,16,phi2) ; 
		 } 
		 qx_matrix_mmul(16,16,1, (qx *)Ufunc, phi2, phi3) ; 
		 if ( verbose && sample == num_samples-1 ){ 
			 sprintf ( buf, "Iteration %d phi3", iteration+1 ) ; 
			 ListMatrix(0,buf,1,16,phi3) ; 
		 } 
         qx_matrix_mmul(16,16,1, (qx *)M_IDE_2A_IDE, phi3, phi4) ; 
		 if ( sample == num_samples-1 ){
			 sprintf ( buf, "Iteration %d phi4", iteration+1 ) ; 
			 ListMatrix(0,buf,1,16,phi4) ; 
		 }
		 // assign phi1 for next iteration
		 memcpy ( phi1, phi4, sizeof(phi1) ) ; 
	 }
	 qx_state_measurement(16, phi4, measured) ; 
	 xout = (qx_state_variable_binary_value(16,measured,0)<<2) + (qx_state_variable_binary_value(16,measured,1)<<1) + (qx_state_variable_binary_value(16,measured,2)<<0) ;
	 if ( xout == classical_fx ) ++total_ok ; 
	 else ++total_ko ; 
	 ++total ; 
	 if ( sample == num_samples-1 ){
		 sprintf ( buf, "Grover with 3 bit, fx = %d xout found = %d (%s). Total samples=%d, OK=%d (%.3f), KO=%d (%.3f)", GROVER_3BIT_VALUE, xout, qx_binary_output(3,xout),
			 total, total_ok, (double)total_ok/(double)total,	total_ko, (double)total_ko/(double)total ); 
		 ListMatrix(0,buf) ; 
	 }
 }
}
void CQCP_grover::QCF_Grover_3bit_algorithm()
{
 ListMatrix(3, "Grover 3 bit function once" ) ;
 QCF_Grover_3bit_algorithm(0,1) ; // once
 ListMatrixColumnView(2*(GROVER_3BIT_VALUE)-1, 2*(GROVER_3BIT_VALUE)+2) ;
}
void CQCP_grover::QCF_QcfGrover3bitalgorithmverbose()
{
 ListMatrix(3, "Grover 3 bit function once - Expanded display of intermediate phi states" ) ;
 QCF_Grover_3bit_algorithm(1,1) ; // once
 ListMatrixColumnView(2*(GROVER_3BIT_VALUE)-1, 2*(GROVER_3BIT_VALUE)+2) ;
}

void CQCP_grover::QCF_Grover_3bit_stat()
{
 ListMatrix(3, "Grover 3 bit function sampled 1000 times" ) ;
 work_in_progress_show(1);
 QCF_Grover_3bit_algorithm(0,1000) ; // less information displayed
 ListMatrixColumnView(2*(GROVER_3BIT_VALUE)-1, 2*(GROVER_3BIT_VALUE)+2) ;
 work_in_progress_show(0);
}
///////////////// Grover with N between 4 and 8 ------------------------------
#define GROVER_N_BIT_VALUE (((1<<number_of_bits)/2)+1)
#define GROVER_N_BIT_VALUE_THREADED (((1<<smp->number_of_bits)/2)+1)
byte CQCP_grover::QCF_Grover_Nbit_base_function(byte input)
{
byte conventional_value = GROVER_N_BIT_VALUE  ;
 if ( input == conventional_value ) return 1 ; 
 else return 0 ; 
}
void CQCP_grover::QCF_Grover_Nbit_func1()
{
char buf[200] ; 
byte x, y ;  
 ListMatrixResize(2) ; 
 sprintf ( buf, "Values returned from the sample %d bit function implemented trivially", number_of_bits ) ;
 ListMatrix(3,buf) ; 
 for ( x = 0 ; x < (1<<number_of_bits) ; ++x ) 
 {	
	y = QCF_Grover_Nbit_base_function(x) ;
	sprintf (buf,"Input = %d (%s), output = %d %s", x, qx_binary_output(number_of_bits,x), y, y==1 ? " FOUND FUNCTION VALUE" : "" ) ; 
	ListMatrix(0, buf) ; 
 }
}
void CQCP_grover::QCF_Build_Grover_Nbit_func_Uf(qx *Ufuncp)
{
byte x, y, fx, y_xor_fx ;  
int row, col ; 
 memset(Ufuncp, 0, 2*(1<<number_of_bits)*2*(1<<number_of_bits)*sizeof(qx)) ; 
 for ( x = 0 ; x < (1<<number_of_bits) ; ++x ) 
 {
	 for ( y = 0 ; y <= 1 ; ++y ) 
	 {
		 fx = QCF_Grover_Nbit_base_function(x) ;
		 y_xor_fx = y^fx ; 
		 row = x * 2 + y  ; 
		 col = x * 2 + y_xor_fx  ;  
		 Ufuncp[row*(2*(1<<number_of_bits))+col].a = 1 ; 
	 }
 }
}
static qx Ufunc_big[256][256] ; 
void CQCP_grover::QCF_Grover_Nbit_func_Uf()
{
char buf[200] ; 
byte x, y, fx, y_xor_fx ;  
qx phi0[256], phi1[256] ; 
 ListMatrixResize(2) ; 
 QCF_Build_Grover_Nbit_func_Uf((qx *)Ufunc_big);
 sprintf ( buf,"Values returned from the sample %d bit function implemented as Uf", number_of_bits) ; 
 ListMatrix(3,buf) ; 
 // enable list for debugging
 //ListMatrix(0,"",2*(1<<number_of_bits),2*(1<<number_of_bits),(qx *)Ufunc_big ) ;
 for ( x = 0 ; x < (1<<number_of_bits) ; ++x ) 
 {	
    y = 0 ; // could be 1 
    memset ( phi0, 0, sizeof(phi0) ) ; 
	phi0[x*2+y].a = 1.0 ; // input data 
	qx_matrix_mmul(2*(1<<number_of_bits),2*(1<<number_of_bits),1, (qx *)Ufunc_big, phi0, phi1) ; 
	// Notice that the binary variable to be extracted is 3, i.e. the fourth bit
	y_xor_fx = qx_state_variable_binary_value(2*(1<<number_of_bits),phi1,number_of_bits) ; 
	fx = y^y_xor_fx ;
	sprintf (buf,"Input = %d (%s), output = %d %s", x, qx_binary_output(number_of_bits,x), fx, fx==1 ? " FOUND FUNCTION VALUE" : "" ) ; 
	ListMatrix(0, buf) ; 
 }
}
void CQCP_grover::QCF_Build_Grover_Nbit_average_inversion_matrix(int size, qx *MI2A) 
{
int  r, c ; 
 for ( r = 0 ; r < size ; ++r ) 
 {
	 for ( c = 0 ; c < size ; ++c ) 
	 {
         // Take care of floating point. Do not calculate an integer division:
		 if ( r == c ) MI2A[r*size+c].a = -1.0 + (2.0/(double)size) ;
		 else MI2A[r*size+c].a = (2.0/(double)size) ; 
		 MI2A[r*size+c].b = 0 ; 		 
	 }
 }
}
static qx M_IDE_2A_big[128][128] ; 
void CQCP_grover::QCF_Grover_Nbit_inversion_matrix()
{
char buf[200] ; 
 ListMatrixResize(0) ; 
 QCF_Build_Grover_Nbit_average_inversion_matrix((1<<number_of_bits), (qx *)M_IDE_2A_big) ;
 sprintf ( buf, "M_IDE_2A is unitary=%s, is hermitian=%s", qx_matrix_is_unitary((1<<number_of_bits),(qx *)M_IDE_2A_big) ? "yes" : "no", qx_matrix_is_hermitian((1<<number_of_bits),(qx *)M_IDE_2A_big) ? "yes" : "no"  ) ; 
 ListMatrix(3,buf) ; 
 ListMatrix(0, "Inversion about the mean matrix for N bit input",(1<<number_of_bits),(1<<number_of_bits), (qx *)M_IDE_2A_big) ; 
}
void CQCP_grover::QCF_Grover_Nbit_algorithm(char verbose, int num_samples, qx *phi4)
{
char buf[200] ;
static int total_ok=0, total_ko=0, total; 
 if ( num_samples < 0 ) 
 {
	 total_ok = total_ko = total = 0 ; return ; 
 }
 QCF_Build_Grover_Nbit_func_Uf((qx *)Ufunc_big);
 QCF_Build_Grover_Nbit_average_inversion_matrix((1<<number_of_bits), (qx *)M_IDE_2A_big) ;
qx HA[2][2] ; 
qx IDE1[2][2] ; 
// cannot be in stack:
static qx HA3[128][128] ;
static qx HA4[256][256] ;
static qx IDE3[128][128] ; 
static qx IDE3HA[256][256] ; 
static qx HA3IDE[256][256] ; 
static qx M_IDE_2A_IDE[256][256] ; 
 qx_matrix_constant(QX_M22_HADA, (qx *)HA) ; 
 qx_matrix_constant(QX_M22_HADA,1+number_of_bits,(qx *)HA4) ; 
 qx_matrix_constant(QX_M22_HADA,number_of_bits,(qx *)HA3) ; 
 qx_matrix_constant(QX_M22_IDEN, (qx *)IDE1) ; 
 qx_matrix_constant(QX_M22_IDEN,number_of_bits,(qx *)IDE3) ; 
 qx_matrix_tensor_product((1<<number_of_bits),(1<<number_of_bits),2,2,(qx *)M_IDE_2A_big,(qx *)IDE1, (qx *)M_IDE_2A_IDE) ; 
 qx_matrix_tensor_product((1<<number_of_bits),(1<<number_of_bits),2,2,(qx *)IDE3,(qx *)HA, (qx *)IDE3HA) ; 
 qx_matrix_tensor_product((1<<number_of_bits),(1<<number_of_bits),2,2,(qx *)HA3,(qx *)IDE1, (qx *)HA3IDE) ; 
int iteration, g ; 
byte xout ; 
qx phi0[256], phi1[256],  phi2[256], phi3[256], measured[256] ; 
byte classical_fx = GROVER_N_BIT_VALUE ; // value to be found 
int sample, local_cnt = 0  ; 

 for ( sample = 0 ; sample < num_samples ; ++sample ) 
 { 
	 memset( phi0, 0, sizeof(phi0) ) ; 
	 // ww must initialize phi0 with x[3] = 0, y = 1, so the significant element is:
	 phi0[1].a = 1.0 ; 
	 // first step:
	 qx_matrix_mmul(2*(1<<number_of_bits),2*(1<<number_of_bits),1,(qx *)HA3IDE, phi0, phi1) ; 
	 	 
	 if ( verbose && sample == num_samples-1 ) ListMatrix(0,"Grover N bit phi1",1,2*(1<<number_of_bits), phi1) ; 
	 // iterations 
// you can verify what appens with more iteration giving a value != 0 here:
int optimal_iterations ; 
     if ( number_of_iterations <= 0 )
	 {
		 switch ( (1<<number_of_bits) )
		 {
		 default : optimal_iterations = 0 ; 
			 ListMatrix(0, "Unknown optimal iteration number" ) ; 
			 return ; 
	  
		 case   4: optimal_iterations =  3 ; break ; 
		 case   8: optimal_iterations =  3 ; break ; 
		 case  16: optimal_iterations =  3 ; break ; 
		 case  32: optimal_iterations =  3 ; break ; 
		 case  64: optimal_iterations =  3 ; break ; 
		 case 128: optimal_iterations =  3 ; break ; 
		 }
	 }
	 else optimal_iterations = number_of_iterations ;
     for ( iteration = 0 ; iteration < optimal_iterations ; ++iteration )
	 {			
		 qx_matrix_mmul(2*(1<<number_of_bits),2*(1<<number_of_bits),1, (qx *)IDE3HA, phi1, phi2) ; 
		 qx_matrix_mmul(2*(1<<number_of_bits),2*(1<<number_of_bits),1, (qx *)Ufunc_big, phi2, phi3) ; 
		/*/ if ( verbose && sample == num_samples-1 ){ // not interesting
			 sprintf ( buf, "Iteration %d phi3", iteration+1 ) ; 
			 ListMatrix(0,buf,1,2*(1<<number_of_bits),phi3) ; 
		 } /**/
         qx_matrix_mmul(2*(1<<number_of_bits),2*(1<<number_of_bits),1, (qx *)M_IDE_2A_IDE, phi3, phi4) ; 
		 if ( verbose && sample == num_samples-1 ){
			 sprintf ( buf, "Iteration %d phi4",  iteration+1 ) ; 
			 ListMatrix(0,buf,1,2*(1<<number_of_bits),phi4) ; 
		 }
		 // assign phi1 for next iteration
		 memcpy ( phi1, phi4, sizeof(phi1) ) ; 
	 }
	 qx_state_measurement(2*(1<<number_of_bits), phi4, measured) ; 
	 for ( xout = 0, g = 0 ; g < number_of_bits ; ++g ) 
	 {
		 xout += (qx_state_variable_binary_value(2*(1<<number_of_bits),measured,g)<<((number_of_bits-1)-g)) ;
		//xout = (qx_state_variable_binary_value(16,measured,0)<<2) + (qx_state_variable_binary_value(16,measured,1)<<1) + (qx_state_variable_binary_value(16,measured,2)<<0) ;
	 }
	 if ( xout == classical_fx ) ++total_ok ; 
	 else ++total_ko ; 
	 ++total ; 
	 if ( verbose && sample == num_samples-1 ){
		 sprintf ( buf, "Grover with %d bit and %d iterations, fx = %d xout found = %d (%s). Total samples=%d, OK=%d (%.3f), KO=%d (%.3f)",
			 number_of_bits, optimal_iterations, GROVER_N_BIT_VALUE , xout, qx_binary_output(number_of_bits,xout),
			 total, total_ok, (double)total_ok/(double)total,	total_ko, (double)total_ko/(double)total ); 
		 ListMatrix(0,buf) ; 
	 }
	 if ( verbose ) 
	 {
#ifdef QCNOOQ_WINDOWS
		 char bpr[100] ; 
		 sprintf ( bpr, "%d", ++local_cnt) ; m_progress1.SetWindowText(bpr) ; 
#endif
	 }
 }
}
static UINT QCF_Grover_Nbit_algorithm_threaded(LPVOID param_class_pointer)
{
CQCP_grover *smp = (CQCP_grover *)param_class_pointer ; 
qx phi4[256] ;
 smp->QCF_Grover_Nbit_algorithm(1,1, phi4) ; // once
 ListMatrixColumnView(2*(GROVER_N_BIT_VALUE_THREADED)-1, 2*(GROVER_N_BIT_VALUE_THREADED)+2) ;
 work_in_progress_show(0);
 return 0 ; 
}
void CQCP_grover::QCF_Grover_Nbit_algorithm()
{
 ListMatrixResize(0) ; 
 ListMatrix(3, "Grover N bit function once" ) ;
 work_in_progress_show(1);
#ifdef QCNOOQ_WINDOWS
 // a Windows event should not timeout. So if the function will last more than a few seconds, create a thread and release the button event
 AfxBeginThread(QCF_Grover_Nbit_algorithm_threaded,this) ; 
#else
 QCF_Grover_Nbit_algorithm_threaded(this) ; 
#endif   
}
static UINT QCF_Grover_Nbit_stat_threaded(LPVOID param_class_pointer)
{
CQCP_grover *smp = (CQCP_grover *)param_class_pointer ; 
qx phi4[256] ;
 smp->QCF_Grover_Nbit_algorithm(1,1000, phi4) ; // less information displayed
 #ifdef QCNOOQ_WINDOWS
 smp->m_progress1.SetWindowText("DONE") ; 
#endif
 ListMatrixColumnView(2*(GROVER_N_BIT_VALUE_THREADED)-1, 2*(GROVER_N_BIT_VALUE_THREADED)+2) ;
 work_in_progress_show(0);
 return 0 ; 
}	
void CQCP_grover::QCF_Grover_Nbit_stat()
{
 ListMatrixResize(0) ; 
 ListMatrix(3, "Grover N bit function sampled 1000 times" ) ;
 work_in_progress_show(1);
#ifdef QCNOOQ_WINDOWS
 // a Windows event should not timeout. So if the function will last more than a few seconds, create a thread and release the button event
 AfxBeginThread(QCF_Grover_Nbit_stat_threaded,this) ; 
#else
 QCF_Grover_Nbit_stat_threaded(this) ; 
#endif  
}
static UINT QCF_Grover_Nbit_find_optimal_iterations_threaded (LPVOID param_class_pointer)
{
CQCP_grover *smp = (CQCP_grover *)param_class_pointer ; 
int nn ; 
qx phi4[256] ;
qx phinormal[256] ; 
int best_case_iterations ; 
char buf[200] ; 
int col_fx ; 
double msq ; 
qx inverse_length, px ;
double best_case ; 

 col_fx = 2* GROVER_N_BIT_VALUE_THREADED ; // this and the next are the colums corresponding to fx 
 best_case = best_case_iterations = 0 ; 
 for ( nn = 3 ; nn < (1<<smp->number_of_bits) ; ++nn )
 {
#ifdef QCNOOQ_WINDOWS
	 sprintf ( buf, "%d", nn) ; smp->m_progress1.SetWindowText(buf) ; 
#endif
	 smp->number_of_iterations = nn ; 
	 smp->QCF_Grover_Nbit_algorithm(0,1, phi4) ; // once	to have phi4	 
	 // now normalize phi 
	 msq = qx_vector_moduli_squared_sum(2*(1<<smp->number_of_bits), phi4) ; 
	 inverse_length.a = 1/sqrt(msq) ; inverse_length.b = 0 ; 
	 qx_vector_smul(2*(1<<smp->number_of_bits), inverse_length, phi4, phinormal ) ; 
	 // probability to get fx = sum of squares of the values of the two fx columns
	 px = qx_add(qx_mul(phi4[col_fx],phi4[col_fx]), qx_mul(phi4[col_fx+1],phi4[col_fx+1])) ;
	 if ( px.a > best_case )
	 {
		 best_case = px.a ; best_case_iterations = nn ; 
	 }	 
 }
 sprintf ( buf, "Iterations %d BEST phi4 Probability of fx=%f",  best_case_iterations, best_case ) ;
 ListMatrix(0,buf) ; 
 ListMatrix(0,buf,1,2*(1<<smp->number_of_bits),phi4) ; 
 ListMatrixColumnView(2*(GROVER_N_BIT_VALUE_THREADED)-1, 2*(GROVER_N_BIT_VALUE_THREADED)+2) ;
 work_in_progress_show(0);
 smp->number_of_iterations = best_case_iterations ; // set this case for now
#ifdef QCNOOQ_WINDOWS
 smp->m_number_of_iterations.SetCurSel(smp->number_of_iterations-1) ;
#endif
 smp->QCF_Grover_Nbit_algorithm(1,-1, NULL); // zero statistics if number changed 
 return 0 ; 
}
void CQCP_grover::QCF_Grover_Nbit_find_optimal_iterations()
{

 ListMatrix(3, "Grover N bit search optimal number of iterations" ) ;
 work_in_progress_show(1);
#ifdef QCNOOQ_WINDOWS
 // a Windows event should not timeout. So if the function will last more than a few seconds, create a thread and release the button event
 AfxBeginThread(QCF_Grover_Nbit_find_optimal_iterations_threaded,this) ; 
#else
 QCF_Grover_Nbit_find_optimal_iterations_threaded(this) ; 
#endif  
}

