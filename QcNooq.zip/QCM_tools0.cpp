/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020 ISBN: 9788897527541 
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// General usage MATH tools
//
#include "stdafx.h"
#pragma warning(disable : 4996) // this pragma is to allow the usage of sprintf without giving a warning

#include "QCM_Math.h"
#include <math.h>

// unsafe methods: after some operation floating point approximation can present itself
extern BOOL qx_iszero(qx c0) 
{
 if ( c0.a == 0.0 && c0.b == 0.0 ) return TRUE ; 
 return FALSE ; 
}
extern BOOL qx_equal(qx c0, qx c1) 
{
 if ( c0.a == c1.a && c0.b == c1.b ) return TRUE ; 
 return FALSE ; 
}

// test per eguale date le approssimazioni f.p. - da vedere se la precision dovr� essere modulabile 
#define QX_DOUBLE_PRECISION (1.0e-12) // anche  (1.0e-14) potrebbe funzionare 
extern BOOL qx_complex_equal_enough (qx c0, qx c1) 
{
qx diffe ; 
 diffe.a = c0.a - c1.a ; diffe.b = c0.b - c1.b ;
 if ( diffe.a < -QX_DOUBLE_PRECISION || diffe.a > QX_DOUBLE_PRECISION ) 
	 return FALSE ;
 if ( diffe.b < -QX_DOUBLE_PRECISION || diffe.b > QX_DOUBLE_PRECISION ) 
	 return FALSE ;
 return TRUE ; 
}
extern BOOL qx_double_equal_enough (double c0, double c1) 
{
double diffe ; 
 diffe = c0 - c1 ; 
 if ( diffe < -QX_DOUBLE_PRECISION || diffe > QX_DOUBLE_PRECISION ) 
	 return FALSE ;
 return TRUE ; 
}
extern unsigned short qx_Euclid_GCD_double(double a, unsigned short b) 
{
unsigned short r;
    while(b != 0) //repeat until b is reduced to zero
    {
         r = (unsigned short)fmod(a,(double)b) ;
         a = b; 
         b = r; //swap the role played by a or b
    }
    return (unsigned short)a; //... and when b is zero, the GCD is a
}
unsigned short qx_Euclid_GCD_16(unsigned short a, unsigned short b) // Euclid's algorithm for Greatest Common Divisor //
{
unsigned short r;
    while(b != 0) //repeat until b is reduced to zero
    {
         r = a % b;
         a = b; 
         b = r; //swap the role played by a or b
    }
    return a; //... and when b is zero, the GCD is a
}
unsigned short qx_Euclid_GCD_16_r(unsigned short m, unsigned short n) /*ALGORITMO RICORSIVO*/
{
  if(n == 0) return(m);
  else return qx_Euclid_GCD_16_r(n, m%n) ;
}
unsigned int qx_Euclid_GCD_32(unsigned int a, unsigned int b) // prototipo della funzione Euclide //
{
unsigned int r;
    while(b != 0) //ripetere finch� non riduciamo a zero
    {
         r = a % b;
         a = b; 
         b = r; //scambiamo il ruolo di a e b
    }
    return a; //... e quando b � (o � diventato) 0, il risultato � a
}
unsigned int qx_Euclid_GCD_32_r(unsigned int m, unsigned int n) /*ALGORITMO RICORSIVO*/
{
  if(n == 0) return(m);
  else return qx_Euclid_GCD_16_r(n, m%n) ;
}

extern unsigned short qx_a_powx_modN_16 (unsigned short a, unsigned short x, unsigned short N)
{
unsigned short k ; 
unsigned int value ; // can overflow the 16 bit range
 value = 1 ; 
 // a pow(x) goes into overflow for small values of a 
 // so we exploit the property:  (a pow (x)) % N = ( (a pow(x-1)%N) * a ) % N  
 for ( k = 0 ; k < x ; ++k ) 
 { 
	 value = value % N ;
	 value *= a ;	 // here it can overflow the 16 bit range
 }
 return (value % N) ;
}
extern unsigned int qx_a_powx_modN_32 (unsigned int a, unsigned int x, unsigned int N)
{
unsigned int k ; 
unsigned int value ; // can overflow the 16 bit range
 value = 1 ; 
 // a pow(x) goes into overflow for small values of a 
 // so we exploit the property:  (a pow (x)) % N = ( (a pow(x-1)%N) * a ) % N  
 for ( k = 0 ; k < x ; ++k ) 
 { 
	 value = value % N ;
	 value *= a ;	 // here it can overflow the 16 bit range
 }
 return (value % N) ;
}
// redundant version of the same to control implementation
extern unsigned short qx_a_powx_modN_16 (unsigned short a, unsigned short x, unsigned short N, unsigned int *maxapowxp)
{
unsigned short k ; 
unsigned int value ; // can overflow the 16 bit range
 *maxapowxp = 0 ; // for display to control interpretation
 value = 1 ; 
 // a pow(x) goes into overflow for small values of a 
 // so we exploit the property:  (a pow (x)) % N = ( (a pow(x-1)%N) * a ) % N  
 for ( k = 0 ; k < x ; ++k ) 
 { 
	 if ( value > *maxapowxp ) *maxapowxp = value ; 
	 value = value % N ;
	 value *= a ;	 // here it can overflow the 16 bit range
 }
 return (value % N) ;
}
unsigned short qx_period_16 (unsigned short A, unsigned short N)
{
unsigned short x ; 
unsigned int value ; // can overflow the 16 bit range

 if ( qx_Euclid_GCD_16(A,N) != 1 ) 
 {
#ifdef QCNOOQ_WINDOWS
	 AfxMessageBox("Application error: Never call  qx_period_16() if ( qx_Euclid_GCD_16(A,N)) != 1 )") ; 
#endif
	 return 0xffff ; // SW error: never call without previous GCD control
 }
 value = 1 ; // A pow(0)
 // A pow(x) goes into overflow for small values of A 
 // so we exploit the property:  (A pow (x)) % N = ( (A pow(x-1)%N) * A ) % N  
 for ( x = 0 ; x < N ; ++x ) 
 { 
	 // the modulus operation ensures that value is inside the 16 bit range
	 value = value % N ; // (A pow (x)) % N
	 if ( x > 0 && value == 1 ) 
		 return x ;
	 // here value can overflow the 16 bit range
	 value *= A ;	// x will be incremented, so this performs (A pow(x-1)%N) * A	 
 } 
#ifdef QCNOOQ_WINDOWS
 AfxMessageBox("Software error: qx_period_16() must find a period") ; 
#endif
 return 0xffff ; // SW error: according to the theorem we should never get here 
}
