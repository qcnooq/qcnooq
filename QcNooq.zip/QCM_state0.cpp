/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020 ISBN: 9788897527541 
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// State vector operations
//

#include "stdafx.h"
#include <math.h>  
#include "QCM_Math.h"

// the following function checks a state returning:
// >= 0 if the vector is a state - the return value is the index of the element == 1 
// < 0  if the vector is not a state
extern int qx_check_measured_state (int size, qx *v0) 
{
int k, rv = -1 ; 
qx c0 = {0,0} ; 
qx c1 = {1,0} ;
 for ( k = 0 ; k < size ; ++k ) 
 {
	 if ( qx_complex_equal_enough(v0[k], c0)) continue ; 
	 if ( qx_complex_equal_enough(v0[k], c1)) 
	 {
		 if ( rv != -1 ) return -1 ; // value 1 found twice or more 
		 rv = k ; 
		 continue ; 
	 }
	 return -1 ; // found a value different than 0 or 1 
 }
 return rv ; 
}
/* retrieve the value of a variable given a (valid) state
if we have a state vector [0001], the variables x and y have both value = 1, because the vector corresponds to:
xy state
00  0
01  0
10  0
11  1
the following function retrieves the value for variable n 
Convention: if xyz, x = variable 0, y = variable 1, z = variable 3
The function returns -1 on error (invalid state), else a bit 0 or 1 
WARNING: this function will work only if variables in the vector are of the same size 
*/
extern char qx_state_variable_binary_value (int size, qx *v0, int n_variable)
{
char result = -1 ;  // mask error result = -1
qx qx_one = {1.0, 0.0} ; // 1 constant for test
int k, sz, max_variables ; 
 // if the variable index is >= the log base 2 of the  state size, the variable index is illegal 
 for ( sz = size, max_variables = 0 ; sz > 1 ; sz >>= 1 ) // calculate log base 2 of size 
 {
	 ++max_variables ;
 } 
 if ( n_variable >= max_variables ) return result ; // error
 n_variable = max_variables - (1+n_variable);
 for ( k = 0 ; k < size ; ++k ) 
 {
	 if ( qx_complex_equal_enough( qx_one, v0[k] ) )
	 {
		 // set result 
		 result = (k & (1 << n_variable )) ? 1 : 0 ; 
		 return result ; 
	 }
 }
 return result ; // if the vector is a state we should never get here
}
// return a random number between 0 .. and 2^31-1, about 2e9 
static unsigned int qx_holdrand = 0 ;
extern int qx_random(){
// instead the system library call, use this technique to have  31 bit random numbers 
#define ALTERNATE_INTERNAL_RANDOM
#ifdef  ALTERNATE_INTERNAL_RANDOM
#define QX_RANDOM_MAX 0x7fffffff  // about 2e9
	if (qx_holdrand == 0) 
	{
		//qx_holdrand = (clock()<<16)+clock(); // init random series seed
		qx_holdrand = ~((unsigned int)((clock()<<16)+clock())) ; // init random series seed
	}
	qx_holdrand *= (7*7*7*7*7) ; 
	qx_holdrand %= (((unsigned long)1<<31)-1) ;	
	return (int)(qx_holdrand & QX_RANDOM_MAX) ; 
#else
int rr ; 
#define QX_RANDOM_MAX RAND_MAX
	if (qx_holdrand == 0) {qx_holdrand = clock(); srand(qx_holdrand);}// init random series seed
	rr = rand() ; 
	return ( rr % QX_RANDOM_MAX ) ; 

#endif 
}
// emulation of measurement via random numbers
// if we have a vector [p, 0, 2*p, 0], we shall return 
// never indexes 1 and 3, since probability is 0
// t times index 0 
// about 4 * t times index 2, since the probabilities are squared
extern BOOL qx_state_measurement (int size, qx *v0, qx *mresult) 
{
double total_probability ;
double *probabilities ; 
int k, resindex ; 
int random_extracted ; 
 // let us alloc a temporary buffer for calculations 
 probabilities = (double *)malloc(size * sizeof(double) ) ;
 total_probability = qx_vector_moduli_squared_sum(size, v0);
 for ( k = 0 ; k < size ; ++k ) probabilities[k] = qx_modulus_squared(v0[k]) ;
  // total probability must be meaningful
 if ( qx_double_equal_enough ( total_probability, 0.0 )) return FALSE ; // meaningless 
 // let us put data in the range of our random numbers 
 double factor = ((double)QX_RANDOM_MAX+1)/total_probability ; 
 total_probability *= factor ;
 for ( k = 0 ; k < size ; ++k ) probabilities[k] *= factor ; 
 // the items have a segment proportioned to their probability
 // the whole range will be equal to the range of our random numbers 
 for ( k = 1 ; k < size ; ++k ) probabilities[k] += probabilities[k-1] ;
 random_extracted = qx_random() ; // extract a point in the line 
 for ( resindex = 0 ; resindex < size ; ++resindex ) 
 {
	 if ( probabilities[resindex] > random_extracted )
	 {
		 // if equal to the previous it had  probability = 0 
		 if ( resindex > 0 && qx_double_equal_enough(probabilities[resindex], probabilities[resindex-1]) ) 
			 continue ; 
		 break ; 
	 }
 }
 if  ( resindex < size ) 
 {
	 for ( k = 0 ; k < size ; ++k ) { 
		 mresult[k].a = 0 ; mresult[k].b = 0 ; }
	 mresult[resindex].a = 1 ;
	 free(probabilities) ; 
	 return TRUE ; 
 }
 memcpy ( mresult, v0, size * sizeof(qx)) ; // in case of failure copy input on output 
 free(probabilities) ;
 return FALSE ; // failure 
}