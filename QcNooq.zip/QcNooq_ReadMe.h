/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
#pragma once
#include "afxwin.h"

// QcNooq_ReadMe dialog

class QcNooq_ReadMe : public CDialogML
{
	DECLARE_DYNAMIC(QcNooq_ReadMe)

public:
	QcNooq_ReadMe(CWnd* pParent = NULL);   // standard constructor
	virtual ~QcNooq_ReadMe();

// Dialog Data
	enum { IDD = IDD_QCNOOQ_ReadMe };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()

	CColorButton m_ok;
	void On_Button_Ok();
	CStaticML m_static00, m_static01, m_static02, m_static03, m_static04, m_static05, m_static06 ;
	CStaticML m_static11, m_static12, m_static21, m_static22;
};
