/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020 ISBN: 9788897527541 
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// math defs 
#ifndef QCP_tools_h_included_q1w2e3r4t5y6u7i8o9
 #define QCM_tools_h_included_q1w2e3r4t5y6u7i8o9

// output prototypes to be remapped 
extern void ListMatrix(char init, char *commento, int mrow, int ncol, qx *mtr, int hexacomment ) ;
extern void ListMatrix(char init, char *commento, int mrow, int ncol, qx *mtr ) ;
extern void ListMatrix(char init, char *commento) ;
extern void ListMatrixResize ( char mode ) ;
extern void ListMatrixColumnView(int c1, int c2);
#ifdef QCNOOQ_WINDOWS
 extern void global_ListMatrix(CListBox *messap, CListCtrl *mcp,  char init, char *commento, int mrow, int ncol, void *mtr, int hexacomment ) ;
#else
 extern void global_ListMatrix(void *messap, void *mcp,  char init, char *commento, int mrow, int ncol, void *mtr, int hexacomment ) ;
#endif
#endif 
// eof 