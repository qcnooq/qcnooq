/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
#pragma once
#ifdef QCNOOQ_WINDOWS
#include "afxwin.h"
#endif

// CQCP_deutsch_josza dialog

class CQCP_deutsch_josza 
#ifdef QCNOOQ_WINDOWS
: public CDialogML
#endif
{
#ifdef QCNOOQ_WINDOWS
	DECLARE_DYNAMIC(CQCP_deutsch_josza)
public:
	CQCP_deutsch_josza(CWnd* pParent = NULL);   // standard constructor
	virtual ~CQCP_deutsch_josza();
	BOOL Create(CWnd* pParent) ;
	void OnCancel() ;
	BOOL OnInitDialog();
	void OnOK();
	CStaticML m_progress1, m_progress2 ;
// Dialog Data
	enum { IDD = IDD_QCP_G_DJ };
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	CStaticML m_static00;
	CStaticML m_static03;
	CStaticML m_static04;
	CColorButton m_A;
	CColorButton m_B;
	CColorButton m_C;
	CColorButton m_D;
	CColorButton m_E;
	CColorButton m_G;
	CColorButton m_H;
	CColorButton m_I;
	CColorButton m_J;
	CColorButton m_K;

	DECLARE_MESSAGE_MAP()
#endif

	void QCF_DJ_N2_execute_DJ(int, qx Ufunc[8][8]);
    void QCF_DJ_N2_verify(int, char f[4], char fp[4], char, qx Ufunc[8][8]);
    void QCF_DJ_N2(char mode);
	void QCF_develop_N2();
	void QCF_develop_N2_verify();
	void QCF_develop_N2_execute_DJ();
	void QCF_develop_N2_execute_Dj_Vtimes();
	void QCF_develop_N2_reset_counters();

	void QCF_DJ_N3_execute_DJ(int, qx Ufunc[16][16]);
    void QCF_DJ_N3_verify(int, char f[4], char fp[4], char, qx Ufunc[16][16]);
public:
    void QCF_DJ_N3(char mode);
protected:
	void QCF_develop_N3();
	void QCF_develop_N3_verify();
	void QCF_develop_N3_execute_DJ();
	void QCF_develop_N3_execute_Dj_Vtimes();
	void QCF_develop_N3_reset_counters();	
};
