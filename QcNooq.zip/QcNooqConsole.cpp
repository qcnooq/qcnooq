/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// QcNooqConsole.cpp:   Entry point model for a console application

#include <stdio.h>

// DO NOT define the symbol QCNOOQ_WINDOWS in the whole console project

// include and create the QCP_ modules and CQCP_ classes you want to test, e.g.:
#include "QCP_matrix.h"
static CQCP_matrix test_matrix ; 

int main (int argc, char *argv[] ) 
{
char buf[100] ; 

 // call the test you want to perform
 test_matrix.QCF_Mul_Vector_Matrix() ; 

 printf ("TEST FINISHED - PRESS ENTER"); gets(buf) ;  
}

// end of file 