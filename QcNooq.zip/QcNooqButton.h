/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020 ISBN: 9788897527541 
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
#if !defined(AFX_COLORBOX_H__1F411462_E4B2_11D8_B14D_00201X574596__INCLUDED_)
#define AFX_COLORBOX_H__1F411462_E4B2_11D8_B14D_00201X574596__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ColorBox.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// CColorButton window

class CColorButton : public CButton
{
// Construction
public:
	CColorButton();

// Attributes
public:

// Operations
public:
	//Set/Get the current color
	void SetColor(const COLORREF newColor);
	COLORREF GetColor() const;

	//Set/get allow change mode. When on, the user can change color
	//when he clicks on the box..
	void SetAllowChange(const BOOL allowchange);
	BOOL GetAllowChange() const;
	
	//Get/set selected mode.
	//When selected, a small frame is drawn around the box
	void SetSelected(const BOOL selected);
	BOOL GetSelected() const;
	
	//Start the color selector and let user change color.
	//Return true if color changed.
	BOOL SelectColor();

	//Set a pointer to the custom colors.
	//IMPORTANT: It must be a pointer to an array with at least 16 elements.
	//When user change color in the color selector, the colors here might be
	//changed as well.
	void SetCustomColors(COLORREF *customcolors);

	//Redraw the box
	void Redraw();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CColorButton)
	public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CColorButton();
    DWORD   tipospeciale, stilespeciale, borderspeciale ;
    char    nographicfocus, dontcenter ;
    virtual void CColorButton::SetWindowText( LPCTSTR lpString );

	// Generated message map functions
protected:
	COLORREF m_color;
    COLORREF m_text_color ;
	BOOL m_allowChange;
	BOOL m_selected;

	COLORREF*  m_CustomColors;

	//{{(CColorButton)
	BOOL OnClickedEx();
    void OnDestroy() ;
	//}}

	DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COLORBOX_H__1F411462_E4B2_11D8_B14D_00201X574596__INCLUDED_)
