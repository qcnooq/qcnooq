/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// QcNooqDialog.cpp: Main Dialog To be included in project ONLY in Windows MFC environment
//
#include "stdafx.h"
#include "QcNooq.h"
#include "QcNooqDlg.h"
#include "QcNooqButton.h"
#include "QcNooqDialog.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDialogML
CDialogML::CDialogML(int IDDX, CWnd* pParent) : CDialog(IDDX, pParent)
{	
    m_clrText  = ZO_COLOR_NORMAL_TEXT ;
    m_clrBkgnd = ZO_COLOR_SFONDONE_SFONDO ;/**/
    m_brBkgnd.CreateSolidBrush( ZO_COLOR_SFONDONE_SFONDO );/**/
}
void CDialogML::ColoriSpeciali ( int testo, int sfondo )
{
 if ( testo  != -1 ) m_clrText  = testo  ; else m_clrText  = ZO_COLOR_NORMAL_TEXT ;
 if ( sfondo != -1 )
 {
     m_clrBkgnd = sfondo ;
     m_brBkgnd.DeleteObject() ;
     m_brBkgnd.CreateSolidBrush( m_clrBkgnd );
 }
 else m_clrBkgnd = ZO_COLOR_SFONDONE_SFONDO ;
}
BEGIN_MESSAGE_MAP(CDialogML, CDialog)
	ON_WM_CTLCOLOR_REFLECT()
    ON_WM_PAINT()
    ON_WM_DESTROY()
END_MESSAGE_MAP()

// CDialogML message handlers
void CDialogML::OnDestroy()
{
	CDialog::OnDestroy();
}
HBRUSH CDialogML::CtlColor(CDC* pDC, UINT nCtlColor)
{
  pDC->SetBkColor( m_clrBkgnd );    // text bkgnd
  return m_brBkgnd ;
}
void CDialogML::OnPaint()
{
 CDialog::OnPaint() ;
}
