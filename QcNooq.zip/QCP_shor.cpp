/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// QCP_shor.cpp : implementation file. Drills for Chapter 6.5 of "Quantum Computing for Programmers and Investors"
//

#include "stdafx.h"
#include "QcNooq.h"

#include "math.h"      // standard C math definition     
#include "QCM_math.h"  // portable definitions 
#include "QCM_tools.h"

#include "QCP_shor.h"

// CQCP_shor dialog
#ifdef QCNOOQ_WINDOWS
IMPLEMENT_DYNAMIC(CQCP_shor, CDialog)

CQCP_shor::CQCP_shor(CWnd* pParent /*=NULL*/) : CDialogML(CQCP_shor::IDD, pParent)
{
}
CQCP_shor::~CQCP_shor()
{
}
BOOL CQCP_shor::Create(CWnd* pParent)
{
	if (!CDialogML::Create(CQCP_shor::IDD, pParent))
	{
		return FALSE;
	}
	return TRUE;
}
void CQCP_shor::OnCancel() {DestroyWindow(); theApp.windows_semaphore=0;}
void CQCP_shor::DoDataExchange(CDataExchange* pDX)
{
	CDialogML::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC00, m_static00);
	DDX_Control(pDX, IDC_Shor_number_input_64, m_edit_number_64);
	DDX_Control(pDX, IDC_Shor_number_input_16, m_edit_number_16);
	DDX_Control(pDX, IDC_progress1, m_progress1);
	DDX_Control(pDX, IDC_STATIC01, m_static01);
	DDX_Control(pDX, IDC_STATIC02, m_static02);
	DDX_Control(pDX, IDC_STATIC03, m_static03);
	DDX_Control(pDX, IDC_STATIC04, m_static04);
	DDX_Control(pDX, IDC_Shor_experiments_input, m_experiments_input);
	DDX_Control(pDX, IDC_Shor_increment_64, m_pp0);
	DDX_Control(pDX, IDC_Shor_decrement_64, m_mm0);
	DDX_Control(pDX, IDC_Shor_Non_Shor_factoring_64_bit, m_A);
	DDX_Control(pDX, IDC_Shor_increment_16, m_pp1);
	DDX_Control(pDX, IDC_Shor_decrement_16, m_mm1);
	DDX_Control(pDX, IDC_Shor_Non_Shor_factoring_16_bit, m_B);
	DDX_Control(pDX, IDC_Shor_Periods_16_bit, m_C);
	DDX_Control(pDX, IDC_Shor_Periods_16_bit_short, m_D);
	DDX_Control(pDX, IDC_Shor_non_quantum, m_E);
	DDX_Control(pDX, IDC_Shor_non_quantum_overflow, m_F);
	DDX_Control(pDX, IDC_Shor_Uf_7_bit, m_G);
	DDX_Control(pDX, IDC_Shor_Uf_7_periods, m_H);	
	DDX_Control(pDX, IDC_Shor_Test_Tools, m_Z);	
}
BEGIN_MESSAGE_MAP(CQCP_shor, CDialogML)
	ON_BN_CLICKED(IDC_Shor_increment_64, &CQCP_shor::QCF_Shor_increment_64)
	ON_BN_CLICKED(IDC_Shor_decrement_64, &CQCP_shor::QCF_Shor_decrement_64)
	ON_BN_CLICKED(IDC_Shor_increment_16, &CQCP_shor::QCF_Shor_increment_16)
	ON_BN_CLICKED(IDC_Shor_decrement_16, &CQCP_shor::QCF_Shor_decrement_16)
	ON_BN_CLICKED(IDC_Shor_Non_Shor_factoring_64_bit, &CQCP_shor::QCF_Non_Shor_factoring_64_bit)
	ON_BN_CLICKED(IDC_Shor_Non_Shor_factoring_16_bit, &CQCP_shor::QCF_Non_Shor_factoring_16_bit)
	ON_BN_CLICKED(IDC_Shor_non_quantum, &CQCP_shor::QCF_Shor_nonquantum_16)
	ON_BN_CLICKED(IDC_Shor_Periods_16_bit, &CQCP_shor::QCF_Shor_Periods_16_bit)
	ON_BN_CLICKED(IDC_Shor_Periods_16_bit_short, &CQCP_shor::QCF_Shor_Periods_16_bit_short)
	ON_BN_CLICKED(IDC_Shor_Uf_7_bit, &CQCP_shor::QCF_Shor_Uf_4_bit)
	ON_BN_CLICKED(IDC_Shor_Uf_7_periods, &CQCP_shor::QCF_Shor_Uf_4_periods)
	ON_BN_CLICKED(IDC_Shor_non_quantum_overflow, &CQCP_shor::QCF_Shor_nonquantum_16_overflow)
	ON_BN_CLICKED(IDC_Shor_Test_Tools, &CQCP_shor::QCF_Shor_Test_Tools)
END_MESSAGE_MAP()
void CQCP_shor::OnOK(){};
BOOL CQCP_shor::OnInitDialog()
{
	unsigned_64_bit N ; 
	char  buf[100] ; 
	CDialogML::OnInitDialog();
	ListMatrixResize(0); // give appropriate sizes
	N = 2*3*5*7*11*13*17 ;
	N*=19;N*=23;N*=29;N*=31;N*=37;N*=41;N*=47;N*=53;
	sprintf ( buf, "%llu", N ) ; 
	m_edit_number_64.SetWindowText(buf) ; 
	// The same, just to see the dots:
	m_edit_number_64.SetWindowText("757.887.406.446.280.110") ;  // the previous value is a prime number
	m_edit_number_16.SetWindowText("4") ; 
	m_experiments_input.SetWindowText("1000") ; 
	return TRUE;  // return TRUE  unless you set the focus to a control
}
#endif
// CQCP_shor message handlers
void CQCP_shor::only_digits(char *buf) 
{
	char *cp, *cp2 ; 
	for ( cp = buf ; *cp ; ++cp )  
	{
		if ( *cp < '0' || *cp > '9' ) 
		{
			for ( cp2 = cp ; *cp2 ; ++cp2 ) 
			{
				*cp2 = *(cp2+1) ;
			}
			*(cp2-1) = 0 ; 
		}
	}
}
void CQCP_shor::QCF_Shor_increment_64()
{
	char buf[200+2] ; 
	unsigned_64_bit N ; 
#ifdef QCNOOQ_WINDOWS
	m_edit_number_64.GetWindowText(buf, 200) ; only_digits(buf) ;  
#else
	strcpy(buf, "15") ; // to be done: input number to factor
#endif
	if ( strlen (buf) > 19 )  {
		return ; 
	}
	N = _atoi64(buf) ; 
	++N ;
	sprintf ( buf, "%lld", N ) ; 
#ifdef QCNOOQ_WINDOWS
	m_edit_number_64.SetWindowText(buf) ; 
#endif
}
void CQCP_shor::QCF_Shor_decrement_64()
{
char buf[200+2] ; 
unsigned_64_bit N ; 
#ifdef QCNOOQ_WINDOWS
	m_edit_number_64.GetWindowText(buf, 200) ; only_digits(buf) ;  
#else
	strcpy(buf, "15") ; // to be done: input number
#endif
	if ( strlen (buf) > 19 )  {
		return ; 
	}
	N = _atoi64(buf) ; 
	if ( N > 0 )
	{
		--N ;
		sprintf ( buf, "%lld", N ) ; 
#ifdef QCNOOQ_WINDOWS
		m_edit_number_64.SetWindowText(buf) ; 
#endif
	}
}
void CQCP_shor::QCF_Shor_increment_16()
{
char buf[200+2] ; 
unsigned short N ; 
#ifdef QCNOOQ_WINDOWS
	m_edit_number_16.GetWindowText(buf, 200) ; only_digits(buf) ;  
#else
	strcpy(buf, "15") ; // to be done: input number
#endif
	if ( (unsigned)atoi(buf) >= ((1<<16)-1))  {
		return ; 
	}
	N = atoi(buf) ; 
	++N ;
	sprintf ( buf, "%d", N ) ; 
#ifdef QCNOOQ_WINDOWS
	m_edit_number_16.SetWindowText(buf) ; 
#endif
}
void CQCP_shor::QCF_Shor_decrement_16()
{
char buf[200+2] ; 
UINT16 N ; 
#ifdef QCNOOQ_WINDOWS
	m_edit_number_16.GetWindowText(buf, 200) ; only_digits(buf) ;  
#else
	strcpy(buf, "15") ; // to be done: input number
#endif
	if ( (unsigned)atoi(buf) > ((1<<16)+1) || (unsigned)atoi(buf) == 2 )  {
		return ; 
	}
	N = atoi(buf) ; 
	if ( N >= 0 )
	{
		--N ;
		sprintf ( buf, "%d", N ) ; 
#ifdef QCNOOQ_WINDOWS
		m_edit_number_16.SetWindowText(buf) ; 
#endif
	}
}
void CQCP_shor::QCF_Non_Shor_factoring_64_bit()
{
char buf[200+2] ; 
int cnt ;  
	// if the division count is disabled the operation will be slightly faster
#define STAT_DIVISION_CNT
#ifdef STAT_DIVISION_CNT
	unsigned int division_cnt ;  
#endif 
	unsigned_64_bit a, N ;
	qx just_for_output[2] = { {0} }; // solo per l'output
#ifdef QCNOOQ_WINDOWS
	m_edit_number_64.GetWindowText(buf, 200) ; only_digits(buf) ;  
#else
	strcpy(buf, "15") ; // to be done: input number
#endif
	// with 20 digits behavior of _atoi64 is strange:
	if ( strlen (buf) > 18 ) 
	{
		ListMatrix(3,"N too big") ; 
		return ; 
	}
	work_in_progress_show(1); 
#ifdef QCNOOQ_WINDOWS
	m_progress1.SetWindowText("") ; // progress display would take much time
#endif
	N = _atoi64(buf) ; 
	sprintf ( buf, "Non Shor 64 bit factoring for %lld", N ) ; 
	ListMatrix(3,buf) ;
	cnt = 0 ; 
#ifdef STAT_DIVISION_CNT
	division_cnt = 0 ; 
#endif
next_test_even:
	a = 2 ; 
#ifdef STAT_DIVISION_CNT
	++division_cnt ; 
#endif
	if ( N % a == 0  )
	{
		just_for_output[0].a = ++cnt ; 
		sprintf ( buf, "Next factor %lld", a )  ; 
		ListMatrix(0, buf, 1,1, just_for_output) ; 
		N /= a ; 
		goto next_test_even ; 
	}
next_test_odd:
	for ( a = 3 ; a <= (N/(a)) ; a += 2  ) 
	{
#ifdef STAT_DIVISION_CNT
		++division_cnt ; // qua nel ciclo si fa solo un'operazione di modulo. Il ++cnt � quindi rilevante 
#endif
		if ( N % a == 0  )
		{
			just_for_output[0].a = ++cnt ; 
			sprintf ( buf, "Next factor %lld", a )  ; 
			ListMatrix(0, buf, 1,1, just_for_output) ; 
			N /= a ; 
			goto next_test_odd ; 
		}
	}
	if ( N > 1 ) // last factor found - if this is the only result, N is a prime number
	{
		just_for_output[0].a = ++cnt ; 
#ifdef STAT_DIVISION_CNT
		sprintf ( buf, "Last factor %lld Divisions=%d", N, division_cnt )  ; 
#else
		sprintf ( buf, "Last factor %lld ", N  )  ; 
#endif
		ListMatrix(0, buf, 1,1, just_for_output) ;  
	}
	work_in_progress_show(0);
}
// if obuf != NULL output is builf on obuf
int CQCP_shor::QCF_do_factoring_16_bit(unsigned short input, char *obuf)
{
char buf[200+2] ; 
short int cnt ;  
short int division_cnt ;  
unsigned short int a, N ;
qx just_for_output[2] = { {0} }; // solo per l'output
	if ( obuf ) N = input ; 
	else 
	{
#ifdef QCNOOQ_WINDOWS
		m_edit_number_16.GetWindowText(buf, 200) ; only_digits(buf) ;  
#else
		strcpy(buf, "15") ; // to be done: input number
#endif
		// here use the 32 bit integer return of atoi to check range:
		if ( (unsigned)atoi(buf) >= (1<<16)  ) 
		{
			if ( !obuf) ListMatrix(3,"N too big") ; 
			return -1 ; 
		} 
		N = atoi(buf) ; 
	}
	if ( ! obuf ) {
		sprintf ( buf, "Non Shor 16 bit factoring for %d", N ) ; 
		ListMatrix(3,buf) ;
	}
	else
	{
		obuf[0] = ' ' ; obuf[1] = 0 ; 
	}
	cnt = 0 ; 
	division_cnt = 0 ; 
next_test_even:
	a = 2 ; 
	++division_cnt ; 
	if ( N % a == 0  )
	{
		just_for_output[0].a = ++cnt ; 
		if ( ! obuf ) 
		{
			sprintf ( buf, "Next factor %d", a )  ; 
			ListMatrix(0, buf, 1,1, just_for_output) ; 
		}
		else
		{
			sprintf ( &obuf[strlen(obuf)], "%d ", a ) ;  
		}
		N /= a ; 
		goto next_test_even ; 
	}
next_test_odd:
	for ( a = 3 ; a <= (N/(a)) ; a += 2  ) 
	{
		++division_cnt ; // qua nel ciclo si fa solo un'operazione di modulo. Il ++cnt � quindi rilevante 
		if ( N % a == 0  )
		{
			just_for_output[0].a = ++cnt ; 
			if ( ! obuf ) 
			{
				sprintf ( buf, "Next factor %d", a )  ; 
				ListMatrix(0, buf, 1,1, just_for_output) ; 
			}
			else
			{
				sprintf ( &obuf[strlen(obuf)], "%d ", a ) ; 
			}
			N /= a ; 
			goto next_test_odd ; 
		}
	}
	if ( N > 1 )
	{
		just_for_output[0].a = ++cnt ; 
		if ( ! obuf ) 
		{
			sprintf ( buf, "Last factor %d Divisions=%d", N, division_cnt )  ; 
			ListMatrix(0, buf, 1,1, just_for_output) ;  
		}
		else
		{
			sprintf ( &obuf[strlen(obuf)], "%d ", N ) ; 
		}
	}
	return 0 ;
}
void CQCP_shor::QCF_Non_Shor_factoring_16_bit()
{
char buf[200] ; 
	if ( QCF_do_factoring_16_bit(0,NULL) == 0 )  // read from input box and output
	{
		// to get factors in a string:
#ifdef QCNOOQ_WINDOWS
		m_edit_number_16.GetWindowText(buf, 10) ; 
#endif
		QCF_do_factoring_16_bit(atoi(buf),buf) ; // read from input box and output
		ListMatrix(0,buf) ; 
	}
}
void CQCP_shor::QCF_Shor_nonquantum_16()
{
 QCF_Non_Quantum_Shor_16_overflow_controlled(); // non quantum mode 
}
void CQCP_shor::QCF_Shor_nonquantum_16_overflow()
{
 QCF_Non_Quantum_Shor_16_overflow_NOT_controlled(); // non quantum mode 
}

#define MAX_VERBOSE_PERIOD_N 20
#define MAX_SHORT_VERBOSE_PERIOD_N  40  // anyway, do not display too much
void CQCP_shor::QCF_do_Shor_Period_16(char verbose)
{
char buf[200+2], bpr[40+1] ;
unsigned short N, A, x ;
int R ;
	// 
	qx fx_for_display[MAX_SHORT_VERBOSE_PERIOD_N+1] ; 
#ifdef QCNOOQ_WINDOWS
	m_edit_number_16.GetWindowText(buf, 200) ; only_digits(buf) ;  
#else
	strcpy(buf, "15") ; // to be done: input number
#endif
	if ( atoi(buf) > (1<<16) ) 
	{
		sprintf ( buf, "N too big") ; 
		ListMatrix(3,buf) ; 
		return ; 
	}
	if ( verbose && atoi(buf) > MAX_VERBOSE_PERIOD_N ) 
	{ 
		sprintf ( buf, "N too big for verbose test, max = %d", MAX_VERBOSE_PERIOD_N) ; 
		ListMatrix(3,buf) ; 
		return ; 
	} 
	// First show number prime factors calculated with the simple method: 
	QCF_Non_Shor_factoring_16_bit() ; ListMatrix(2,"") ; // clear the matrix display
	N = atoi(buf) ; 
	sprintf ( buf, "Development of Period for N=%d (taking advantage of the property:  (a pow (x)) % N = ( (a pow(x-1)%N) * a ) % N)", N ) ; 
	ListMatrix(0,buf) ; 
	work_in_progress_show(1); 
	if ( verbose )  // calculate the whole operation
	{
		for ( A = 2 ; A < N ; ++A ) 
		{
#ifdef QCNOOQ_WINDOWS
			sprintf ( bpr, "%d", A) ; m_progress1.SetWindowText(bpr) ; 
#endif
			R = 0 ; // flag not found 
			for ( x = 0 ; x < N ; ++x ) 
			{
				fx_for_display[x].a = pow((double)A,(double)x) ; 
				fx_for_display[x].b = 0 ; 
				if ( R == 0 && qx_double_equal_enough( fmod((double)fx_for_display[x].a,(double)N), 1.0 ) )
					R = x ;
			}
			sprintf ( buf, "A=%3d, values of (A pow x)%N, period=%d", A, R) ; 
			if ( R == 0 )
			{
				if ( qx_Euclid_GCD_16(A,N) != 1 ) // is a factor
					sprintf (&buf[strlen(buf)], " NO PERIOD, A=%u contains a factor of N=%u", A, N ) ; 
				else 
					sprintf (&buf[strlen(buf)], "  - - - - - Software error!" ) ; 
				ListMatrix(4,buf,1,N,fx_for_display) ; 
			}
			else
			{
				ListMatrix(0,buf,1,N,fx_for_display) ;
				for ( x = 0 ; x < N ; ++x ) 
				{
					fx_for_display[x].a = fmod((double)fx_for_display[x].a,(double)N) ; 
				}
				sprintf ( buf, "A=%3d, values of (A pow x)%%N, period=%d", A, R) ; 
				ListMatrix(4,buf,1,N,fx_for_display) ; 
			}
		}
	}
	else if ( N <= MAX_SHORT_VERBOSE_PERIOD_N  )  // anyway, do not display too much
	{
		unsigned int maxapowx ; // for display only 
		for ( A = 2 ; A < N ; ++A ) 
		{
			if ( qx_Euclid_GCD_16(A,N) != 1 ) // is a factor
				continue ; 
#ifdef QCNOOQ_WINDOWS
			sprintf ( bpr, "%d", A) ; m_progress1.SetWindowText(bpr) ; 
#endif
			R = 0 ; // flag not found 
			for ( x = 0 ; x < N; ++x ) 
			{
				fx_for_display[x].a = qx_a_powx_modN_16(A,x,N, &maxapowx) ; 
				fx_for_display[x].b = 0 ; 
				if ( R == 0 && qx_double_equal_enough( fx_for_display[x].a, 1.0 ) )
					R = x ;
			}
			//sprintf ( buf, "A=%3d, values of (A pow x)%%N, period=%d [Max value of (A pow x)=%u]", A, R, maxapowx) ; 
			sprintf ( buf, "A=%3d, values of (A pow x)%%N, period=%d", A, R ) ; 
			ListMatrix(0,buf,1,N,fx_for_display) ; 
		} 
	}
	// Now determine the period taking advantage of the property:  (A pow (x)) % N = ( (A pow(x-1)%N) * A ) % N  
	for ( A = 2 ; A < N ; ++A ) 
	{
#ifdef QCNOOQ_WINDOWS
		sprintf ( bpr, "%d", A) ; m_progress1.SetWindowText(bpr) ; 
#endif
		if ( qx_Euclid_GCD_16(A,N) != 1 ) // is a factor
		{
			sprintf ( buf, "%40s A=%u contains factors of N=%u, no period", "",A, N  ) ;
		}
		else 
		{
			R = qx_period_16(A,N) ; 
			sprintf ( buf, "A=%u, PERIOD=%u", A, R ) ;
		}
		ListMatrix(0,buf) ; 
	}
	work_in_progress_show(0); 
}
void CQCP_shor::QCF_Shor_Periods_16_bit()
{
	QCF_do_Shor_Period_16(1) ; 
}
void CQCP_shor::QCF_Shor_Periods_16_bit_short()
{
	QCF_do_Shor_Period_16(0) ; 
}
void CQCP_shor::QCF_Non_Quantum_Shor_16_overflow_controlled()
{
char buf[200+2], bgcda[100], bgcdb[100], bpr[40+1] ; // only for output
char facbuf[200] ; // only for output
char flag_found[1<<16] ; // only for output
char flag_overflow_occurred ; 
unsigned short A, N, GCDA, GCDB, R ;
double A_pow_R_half ; // avoid overflow

	qx just_for_output[2] = { {0} }; // this variable is used only for matrix output
#ifdef QCNOOQ_WINDOWS
	m_edit_number_16.GetWindowText(buf, 200) ; only_digits(buf) ;  
#else
	strcpy(buf, "15") ; // to be done: input number
#endif
	if ( atoi(buf) >= (1<<16) ) 
	{
		ListMatrix(3,"N too big") ; 
		return ; 
	}
	// limit of N for verbose display
#define SHOR_16_VERBOSE_LIMIT 1000
	N = atoi(buf) ; 
	memset(flag_found,0,N); flag_overflow_occurred = 0 ;
	work_in_progress_show(1); 
	// First show number prime factors calculated with the simple method: 
	QCF_Non_Shor_factoring_16_bit() ; ListMatrix(2,"") ; // clear the matrix display
	sprintf ( buf, "Non quantum Shor for %u - COMPLETE OVERFLOW CONTROL on pow(A,R/2)", N ) ; 
	if ( N >= SHOR_16_VERBOSE_LIMIT ) sprintf(&buf[strlen(buf)], " Warning: limited information displayed"); 
	ListMatrix(4,buf) ; 
	// step 1: we should avoid prime numbers ... easy
	// ...
	// step 2: randomly choose A - or let us try all the values of A 
	for ( A = 2 ; A < N ; ++A ) 
	{
#ifdef QCNOOQ_WINDOWS
		sprintf ( bpr, "%d", A) ; m_progress1.SetWindowText(bpr) ; 
#endif
		if ( (GCDA=qx_Euclid_GCD_16(A,N)) != 1 ) // GCDA > 1 contains or is a factor
		{
			just_for_output[0].a = (double)A ; just_for_output[1].a = (double)GCDA ; // per molte cifre l'output sarebbe approssimato 
			QCF_do_factoring_16_bit(GCDA,facbuf) ; 
			sprintf ( buf, "Gcd for A=%u found  GCD = %26u IS A FACTOR [Prime components: (%s)]", A, GCDA, facbuf ) ;
			if ( N < SHOR_16_VERBOSE_LIMIT  || (! flag_found[GCDA]) ) ListMatrix(0, buf, 1,2, just_for_output) ; 
			if ( ! (flag_found[GCDA]&1) ) 
			{
				ListMatrix(0, buf) ; // also in the upper window
				flag_found[GCDA] |= 1 ; 
			}
		}
		else // A is a co-prime of N
		{
			R = qx_period_16(A,N) ; // a period R exists
			just_for_output[0].a = (double)A ; just_for_output[1].a = (double)R ; // per molte cifre l'output sarebbe approssimato 
			if ( R % 2 == 1 ) // if R is odd discard A
			{
				if ( N < SHOR_16_VERBOSE_LIMIT ) 
				{
					sprintf ( buf, "   Period found = %5u  to discard, ODD", R ) ; 
					ListMatrix(0,buf,1,2, just_for_output ) ;
				}
				continue ; // discard odd periods
			}
			errno = 0 ; 
			A_pow_R_half = pow((double)A, (double)(R/2)) ; 
			if ( errno == ERANGE ) 
			{
				if ( N < SHOR_16_VERBOSE_LIMIT ) 
				{
					sprintf ( buf, "A=%u, R=%u, pow(%u,%u) overflow", A,R,A,R/2 ) ; 
					ListMatrix(0, buf, 1,1, just_for_output) ;   
				}
				if ( ! flag_overflow_occurred ) 
				{
					sprintf ( buf, "A=%u, R=%u, pow(%u,%u) overflow", A,R,A,R/2 ) ; 
					ListMatrix(0,buf ) ; // upper window
					flag_overflow_occurred = 1 ; 
				}
				continue ; 
			}
			GCDA = qx_Euclid_GCD_double(A_pow_R_half+1,N) ; GCDB = qx_Euclid_GCD_double(A_pow_R_half-1,N) ;      
			char ga_trivial = ( GCDA == 1 || GCDA == N ) ; 
			char gb_trivial = ( GCDB == 1 || GCDB == N ) ; 
			if ( !ga_trivial || !gb_trivial ) 
			{
				bgcda[0], bgcdb[0] = 0 ; 
				if ( !ga_trivial ) 
				{
					QCF_do_factoring_16_bit(GCDA,facbuf) ; 
					sprintf ( bgcda, "SHOR A = %u Period found = %u GCDA = %5u IS A FACTOR [Prime components: (%s)]", A,R, GCDA, facbuf ) ; 
					if ( ! (flag_found[GCDA]&2)   ) 
					{
						ListMatrix(0,bgcda,1,2, just_for_output ) ; 
						ListMatrix(0,bgcda) ; // also upper
						flag_found[GCDA]|=2 ; 
					}
				}
				if ( !gb_trivial ) 
				{
					QCF_do_factoring_16_bit(GCDB,facbuf) ; 
					sprintf ( bgcdb, "SHOR A = %u Period found = %u GCDB = %5u IS A FACTOR [Prime components: (%s)]", A,R, GCDB, facbuf ) ; 
					if ( ! (flag_found[GCDB]&2)   ) 
					{
						ListMatrix(0,bgcdb,1,2, just_for_output ) ;
						ListMatrix(0,bgcdb) ; // also upper
						flag_found[GCDB]|=2 ; 
					}
				}
				sprintf ( buf, "* PERIOD found = %5u  OK GCDA = %u (%s) GCDB = %u (%s)", R, GCDA, ga_trivial ? "trivial" : " NON  TRIVIAL", GCDB, gb_trivial ? "trivial" : " NON  TRIVIAL" ) ; 
			}
			else
			{
				sprintf ( buf, "   Period found = %5u  OK GCDA = %u GCDB = %u (both trivial)", R, GCDA, GCDB ) ; 
			}
			if ( N < SHOR_16_VERBOSE_LIMIT )ListMatrix(0,buf,1,2, just_for_output ) ;
		}
	} 
	work_in_progress_show(0);
}
void CQCP_shor::QCF_Non_Quantum_Shor_16_overflow_NOT_controlled()
{
char buf[200+2], bgcda[100], bgcdb[100], bpr[40+1] ; // only for output
char facbuf[200] ; // only for output
char flag_found[1<<16] ; // only for output
unsigned short A, N, GCDA, GCDB, R ;
unsigned short k ;
unsigned short A_pow_R_half ; // allow overflow 

	qx just_for_output[2] = { {0} }; // this variable is used only for matrix output
#ifdef QCNOOQ_WINDOWS
	m_edit_number_16.GetWindowText(buf, 200) ; only_digits(buf) ;  
#else
	strcpy(buf, "15") ; // to be done: input number
#endif
	if ( atoi(buf) >= (1<<16) ) 
	{
		ListMatrix(3,"N too big") ; 
		return ; 
	}
	// limit of N for verbose display
#define SHOR_16_VERBOSE_LIMIT 1000
	N = atoi(buf) ; 
	memset(flag_found,0,N);
	work_in_progress_show(1); 
	// First show number prime factors calculated with the simple method: 
	QCF_Non_Shor_factoring_16_bit() ; ListMatrix(2,"") ; // clear the matrix display
	sprintf ( buf, "Non quantum Shor for %u - NO OVERFLOW CONTROL on pow(A,R/2): rough results", N ) ; 
	if ( N >= SHOR_16_VERBOSE_LIMIT ) sprintf(&buf[strlen(buf)], " Warning: limited information displayed"); 
	ListMatrix(4,buf) ; 
	// step 1: we should avoid prime numbers ... easy
	// ...
	// step 2: randomly choose A - or let us try all the values of A 
	for ( A = 2 ; A < N ; ++A ) 
	{
#ifdef QCNOOQ_WINDOWS
		sprintf ( bpr, "%d", A) ; m_progress1.SetWindowText(bpr) ; 
#endif
		if ( (GCDA=qx_Euclid_GCD_16(A,N)) != 1 ) // GCDA > 1 contains or is a factor
		{
			just_for_output[0].a = (double)A ; just_for_output[1].a = (double)GCDA ; // per molte cifre l'output sarebbe approssimato 
			QCF_do_factoring_16_bit(GCDA,facbuf) ; 
			sprintf ( buf, "Gcd for A=%u found  GCD = %26u IS A FACTOR [Prime components: (%s)]", A, GCDA, facbuf ) ;
			if ( N < SHOR_16_VERBOSE_LIMIT  || (! flag_found[GCDA]) ) ListMatrix(0, buf, 1,2, just_for_output) ; 
			if ( ! (flag_found[GCDA]&1) ) 
			{
				ListMatrix(0, buf) ; // also in the upper window
				flag_found[GCDA] |= 1 ; 
			}
		}
		else // A is a co-prime of N
		{
			R = qx_period_16(A,N) ; // a period R exists
			just_for_output[0].a = (double)A ; just_for_output[1].a = (double)R ; // per molte cifre l'output sarebbe approssimato 
			if ( R % 2 == 1 ) // if R is odd discard A
			{
				if ( N < SHOR_16_VERBOSE_LIMIT ) 
				{
					sprintf ( buf, "   Period found = %5u  to discard, ODD", R ) ; 
					ListMatrix(0,buf,1,2, just_for_output ) ;
				}
				continue ; // discard odd periods
			}
			A_pow_R_half = A ;
			// execute pow(A,R/2) allowing overflow to occur
			for ( k = 1; k < R/2 ; ++k ) 
			{
				A_pow_R_half *= A ;
			}
			GCDA = qx_Euclid_GCD_16(A_pow_R_half+1,N) ; GCDB = qx_Euclid_GCD_16(A_pow_R_half-1,N) ;      
			char ga_trivial = ( GCDA == 1 || GCDA == N ) ; 
			char gb_trivial = ( GCDB == 1 || GCDB == N ) ; 
			if ( !ga_trivial || !gb_trivial ) 
			{
				bgcda[0], bgcdb[0] = 0 ; 
				if ( !ga_trivial ) 
				{
					QCF_do_factoring_16_bit(GCDA,facbuf) ; 
					sprintf ( bgcda, "SHOR A = %u Period found = %u GCDA = %5u IS A FACTOR [Prime components: (%s)]", A,R, GCDA, facbuf ) ; 
					if ( ! (flag_found[GCDA]&2)   ) 
					{
						ListMatrix(0,bgcda,1,2, just_for_output ) ; 
						ListMatrix(0,bgcda) ; // also upper
						flag_found[GCDA]|=2 ; 
					}
				}
				if ( !gb_trivial ) 
				{
					QCF_do_factoring_16_bit(GCDB,facbuf) ; 
					sprintf ( bgcdb, "SHOR A = %u Period found = %u GCDB = %5u IS A FACTOR [Prime components: (%s)]", A,R, GCDB, facbuf ) ; 
					if ( ! (flag_found[GCDB]&2)   ) 
					{
						ListMatrix(0,bgcdb,1,2, just_for_output ) ;
						ListMatrix(0,bgcdb) ; // also upper
						flag_found[GCDB]|=2 ; 
					}
				}
				sprintf ( buf, "* PERIOD found = %5u  OK GCDA = %u (%s) GCDB = %u (%s)", R, GCDA, ga_trivial ? "trivial" : " NON  TRIVIAL", GCDB, gb_trivial ? "trivial" : " NON  TRIVIAL" ) ; 
			}
			else
			{
				sprintf ( buf, "   Period found = %5u  OK GCDA = %u GCDB = %u (both trivial)", R, GCDA, GCDB ) ; 
			}
			if ( N < SHOR_16_VERBOSE_LIMIT )ListMatrix(0,buf,1,2, just_for_output ) ;
		}
	} 
	work_in_progress_show(0);
}

// Uf is a vector to make simpler calculations for any N 
static qx Ufunc_4_bit[16*16*16*16*16*16] ; // cannot be in stack
static qx phi0[16*16*16] ; 
static qx output4_calc_Uf[16*16*16] ; 
static byte a_known_periods[16] ; 
void CQCP_shor::QCF_Shor_Uf_4_bit()
{
	QCF_Shor_Uf_4_bit_exec(1); // execute and display results verbose
}
BOOL CQCP_shor::QCF_Shor_Uf_4_bit_exec(int verbose_mode)
{
char buf[200+2], bpr[40+1]  ;
BOOL rv = FALSE ; 
byte N, A, M, y, fx, fx_xor_y ;
byte non_reversible_matrix = 0 ; 
int row, col ; 
#ifdef QCNOOQ_WINDOWS
	m_edit_number_16.GetWindowText(buf, 100) ; only_digits(buf) ;  
#else
	strcpy(buf, "15") ; // to be done: input number
#endif
	if ( atoi(buf) >= (1<<4) ) 
	{
		ListMatrix(3,"N too big, max 4 bit (15)") ; 
		return FALSE ; 
	}
	work_in_progress_show(1); 
	N = atoi(buf) ; 
	memset ( Ufunc_4_bit, 0, sizeof(Ufunc_4_bit)) ; 
	non_reversible_matrix = 0 ; 
	byte N_ceiling ; 
	// ceiling of 2 pow(log base 2 of N) (so assigned for readability - should be calculated)
	if ( N <= 2 ) N_ceiling = 2 ; 
	else if ( N <= 4 ) N_ceiling = 4 ; 
	else if ( N <= 8 ) N_ceiling = 8 ; 
	else N_ceiling = 16 ;
	for ( A = 0 ; A < N_ceiling ; ++A ) 
	{
#ifdef QCNOOQ_WINDOWS
				sprintf ( bpr, "%d", A) ; m_progress1.SetWindowText(bpr) ; 
#endif
		for ( M = 0 ; M < N_ceiling ; ++M ) 
		{
			fx = (byte)qx_a_powx_modN_16(A,M,N) ; 
			for ( y = 0 ; y < N_ceiling ; ++y ) 
			{
				fx_xor_y = fx^y ;
				row = ((int)A*N_ceiling*N_ceiling+(int)M*N_ceiling+(int)y) ; 
				col = ((int)A*N_ceiling*N_ceiling+(int)M*N_ceiling+(int)fx_xor_y) ; 
				if ( col >= A*N_ceiling*N_ceiling+M*N_ceiling + N_ceiling ) {
					non_reversible_matrix = 1 ; 
					// check overflow 
					if ( col >= N_ceiling*N_ceiling*N_ceiling ) 
					{
						continue ; 
					}
				}
				Ufunc_4_bit[row*(N_ceiling*N_ceiling*N_ceiling)+col].a = 1.0 ; 
			}
		}
	} 
	sprintf ( buf, "Composition of Uf for N=%u REVERSIBLE MATRIX=%s", N, non_reversible_matrix ? "NO" : "YES" ) ; 
	ListMatrix(3,buf) ; 
	if (  N_ceiling <= 4 ) // avoid test for bigger matrix, it is slow 
	{
		byte is_hermitian = qx_matrix_is_hermitian(N_ceiling*N_ceiling*N_ceiling,Ufunc_4_bit) ; 
		byte is_unitary = qx_matrix_is_unitary(N_ceiling*N_ceiling*N_ceiling,Ufunc_4_bit) ; 
		sprintf ( buf, "Composition of Uf for N=%u hermitian=%s unitary=%s ", N, is_hermitian?"yes":"NO", is_unitary?"yes":"NO" ) ; 
		ListMatrix(0,buf) ; 
	}
	if ( verbose_mode == 1 &&  N_ceiling <= 4 ) // verbose matrix output
	{
		for ( A = 0 ; A < N_ceiling*N_ceiling*N_ceiling ; ++A ) 
		{
			ListMatrix(0,qx_vector_qx_to_binary_output(N_ceiling*N_ceiling*N_ceiling,&Ufunc_4_bit[A*N_ceiling*N_ceiling*N_ceiling]) );
		}
	} 
	if ( non_reversible_matrix ) 
		goto retpoint ; 
	rv = TRUE ;
	qx display_normal[16] ; // type is qx just for display 
	qx display_uf[16] ; 
	int wz ; 
	// this code to calculate periods and to display and check Uf :
	for ( A = 0 ; A < N ; ++A ) 
	{
		// store periods for every A 
		if ( qx_Euclid_GCD_16(A,N) == 1 ) a_known_periods[A] = (byte)qx_period_16(A,N) ; 
		else a_known_periods[A] = 0 ; 
		for ( M = 0 ; M < N ; ++M ) // calculation with simple technique for check
		{
			display_normal[M].a = qx_a_powx_modN_16(A,M,N) ; display_normal[M].b = 0 ;  
		}
		if ( verbose_mode == 1 ) // display result
		{
			sprintf ( buf, "A=%d N=%d (A pow(x))%%N) Simple calculation", A,N) ; 
			ListMatrix(0,buf,1,N,display_normal) ; 
		}
	}
	if ( verbose_mode == 1 ) // display the whole matrix
	{
		for ( A = 0 ; A < N ; ++A ) 
		{
			y = qx_random() % N_ceiling ; // y can have any value 
			//y = 0 ; 
			for ( M = 0 ; M < N_ceiling ; ++M ) 
			{
#ifdef QCNOOQ_WINDOWS
				sprintf ( bpr, "A:%d M:%d", A,M) ; m_progress1.SetWindowText(bpr) ; 
#endif
				memset(phi0, 0, sizeof(phi0)) ; 
				phi0[((int)A*N_ceiling*N_ceiling+(int)M*N_ceiling+(int)y)].a = 1.0 ; 
				qx_matrix_mmul(N_ceiling*N_ceiling*N_ceiling,N_ceiling*N_ceiling*N_ceiling,1,(qx *)Ufunc_4_bit,phi0,output4_calc_Uf );
				// get the row of output having non zero value 
				//int ww = qx_check_measured_state(N*N*N, phi0) ; 
				wz = qx_check_measured_state(N_ceiling*N_ceiling*N_ceiling, output4_calc_Uf) ; 
				// get the column with the y values
				fx_xor_y = wz % N_ceiling ;
				fx = fx_xor_y^y ;
				display_uf[M].a = fx ; display_uf[M].b = 0 ; 
			}
			sprintf ( buf, "A=%d N=%d (A pow(x))%%N) Uf calculation", A,N) ; 
			ListMatrix(0,buf,1,N,display_uf) ; 
		}
	}
	// if verbose display the whole matrix 
	if ( verbose_mode == 1 && N != N_ceiling )
	{
		for ( A = 0 ; A < N_ceiling ; ++A ) 
		{
			y = qx_random() % N_ceiling ; // y can have any value 
			//y = 0 ; 
			for ( M = 0 ; M < N_ceiling ; ++M ) 
			{
#ifdef QCNOOQ_WINDOWS
				sprintf ( bpr, "A:%d M:%d", A,M) ; m_progress1.SetWindowText(bpr) ; 
#endif
				memset(phi0, 0, sizeof(phi0)) ; 
				phi0[((int)A*N_ceiling*N_ceiling+(int)M*N_ceiling+(int)y)].a = 1.0 ; 
				qx_matrix_mmul(N_ceiling*N_ceiling*N_ceiling,N_ceiling*N_ceiling*N_ceiling,1,(qx *)Ufunc_4_bit,phi0,output4_calc_Uf );
				// get the row of output having non zero value 
				//int ww = qx_check_measured_state(N*N*N, phi0) ; 
				wz = qx_check_measured_state(N_ceiling*N_ceiling*N_ceiling, output4_calc_Uf) ; 
				// get the column with the y values
				fx_xor_y = wz % N_ceiling ;
				fx = fx_xor_y^y ;
				display_uf[M].a = fx ; display_uf[M].b = 0 ; 
			}
			sprintf ( buf, "A=%d N=%d (A pow(x))%%N) Uf calculation WHOLE MATRIX", A,N) ; 
			ListMatrix(0,buf,1,N_ceiling,display_uf) ;  
		}
	}
	sprintf ( buf, "periods found:" ) ; 
	for ( A = 2 ; A < N ; ++A ) 
	{
		if ( a_known_periods[A] ) sprintf ( &buf[strlen(buf)], " A=%d R=%d |", A, a_known_periods[A] ) ; 
	}
	ListMatrix(0x20,buf) ; 
retpoint:
	if ( verbose_mode == 1 ) work_in_progress_show(0); 
	return rv ; 
}

// These are used by period search;
static qx UQTFN[16*16*16*16] ; // Vandermonde for |x> = A,M
static qx HADAN[16*16*16*16] ; // Hadamard for |x> = A,M
static qx IDEN [16*16] ; // Identity for |y>
static qx UQTFIDE[16*16*16*16*16*16] ; // Vandermonde tensor Identity
static qx HADAIDE[16*16*16*16*16*16] ; // Hadamard tensor Identity
static qx phi1[16*16*16] ; 
static qx phi2[16*16*16] ; 
static qx phi3[16*16*16] ; 
static qx measured[16*16*16] ; 

// this is a possible variant of the algorithm, mentioned at page 215 of Yanofsky & Mannucci
// the result is about the same. You can test the variant defining:
// #define  SHOR_VARIATION_215

#ifdef  SHOR_VARIATION_215
 static qx UQTFN_ADJ[16*16*16*16] ; // Vandermonde for |x> = A,M
 static qx UQTF_ADJ_IDE[16*16*16*16*16*16] ; // Vandermonde tensor Identity
#endif

UINT QCF_Shor_Uf_4_periods_exec_threaded(LPVOID param_class_pointer)
{
char buf[200]  ; 
CQCP_shor *smp = (CQCP_shor *)param_class_pointer ; 
byte N_ceiling, A, M, y ; 
unsigned short AM ; 
unsigned int AMy ; 
int A_M_occurrencies[16*16*16*16] ;
int A_M_multiples_of_2, A_M_multiples_of_4, A_M_not_useful = 0 ; 
int measurement_no ; 

	memset ( A_M_occurrencies, 0, sizeof(A_M_occurrencies) ) ; A_M_multiples_of_2 = A_M_multiples_of_4 = A_M_not_useful = 0; 
	work_in_progress_show(1); 
	// floor of log base 2 of N (so assigned for readability - should be calculated)
	if ( smp->N <= 2 ) N_ceiling = 2 ; 
	else if ( smp->N <= 4 ) N_ceiling = 4 ; 
	else if ( smp->N <= 8 ) N_ceiling = 8 ; 
	else N_ceiling = 16 ;
#ifdef QCNOOQ_WINDOWS
	smp->m_progress1.SetWindowText("") ; 
#endif
	// now search period with Shor
	byte hdva_size_log ; 
	byte iden_size_log ; 

	if ( N_ceiling == 2 )      {hdva_size_log = 2 ; iden_size_log = 1 ; }
	else if ( N_ceiling == 4 ) {hdva_size_log = 4 ; iden_size_log = 2 ; }
	else if ( N_ceiling == 8 ) {hdva_size_log = 6 ; iden_size_log = 3 ; }
	else                       {hdva_size_log = 8 ; iden_size_log = 4 ; }
	qx_matrix_constant(QX_M22_VANDERMONDE,hdva_size_log,UQTFN) ;
	qx_matrix_constant(QX_M22_HADA,hdva_size_log,HADAN) ;
	qx_matrix_constant(QX_M22_IDEN,iden_size_log,IDEN) ;
	qx_matrix_tensor_product(N_ceiling*N_ceiling,N_ceiling*N_ceiling,N_ceiling,N_ceiling, HADAN, IDEN, HADAIDE ) ;
	qx_matrix_tensor_product(N_ceiling*N_ceiling,N_ceiling*N_ceiling,N_ceiling,N_ceiling, UQTFN, IDEN, UQTFIDE ) ;

#ifdef  SHOR_VARIATION_215
	qx_matrix_adjoint(N_ceiling*N_ceiling,N_ceiling*N_ceiling,UQTFN, UQTFN_ADJ) ; 
	qx_matrix_tensor_product(N_ceiling*N_ceiling,N_ceiling*N_ceiling,N_ceiling,N_ceiling, UQTFN_ADJ, IDEN, UQTF_ADJ_IDE ) ;
#endif 

	if ( 0 ) // output to check implementation
	{
		ListMatrix(0, "Uqtf",N_ceiling*N_ceiling,N_ceiling*N_ceiling,UQTFN ) ;
		ListMatrix(0, "Uqtf+Ide",N_ceiling*N_ceiling*N_ceiling,N_ceiling*N_ceiling*N_ceiling,UQTFIDE ) ;
	}
int qq , max_unu=0, min_unu = 999888; 
// change the loop if you want to check the algorithm for different values of 
#define QQ_BEGIN 0
#define QQ_END   1 //16*16*16
 for ( qq = QQ_BEGIN ; qq < QQ_END ; ++qq ) 
 {
	memset(phi0, 0, sizeof(phi0)) ; 
	sprintf ( buf, "QQ=%d", qq ) ; ListMatrix(0,buf); 
	memset ( A_M_occurrencies, 0, sizeof(A_M_occurrencies) ) ; A_M_multiples_of_2 = A_M_multiples_of_4 = A_M_not_useful = 0; 
	phi0[qq].a = 1.0 ; // if qq==0 then |x> = |0>
#ifdef  SHOR_VARIATION_215
	qx_matrix_mmul(N_ceiling*N_ceiling*N_ceiling,N_ceiling*N_ceiling*N_ceiling,1,(qx *)UQTFIDE,phi0,phi1 );
	qx_matrix_mmul(N_ceiling*N_ceiling*N_ceiling,N_ceiling*N_ceiling*N_ceiling,1,(qx *)Ufunc_4_bit,phi1,phi2 );
	qx_matrix_mmul(N_ceiling*N_ceiling*N_ceiling,N_ceiling*N_ceiling*N_ceiling,1,(qx *)UQTF_ADJ_IDE,phi2,phi3 );	
#else	
	qx_matrix_mmul(N_ceiling*N_ceiling*N_ceiling,N_ceiling*N_ceiling*N_ceiling,1,(qx *)HADAIDE,phi0,phi1 );
	qx_matrix_mmul(N_ceiling*N_ceiling*N_ceiling,N_ceiling*N_ceiling*N_ceiling,1,(qx *)Ufunc_4_bit,phi1,phi2 );
	qx_matrix_mmul(N_ceiling*N_ceiling*N_ceiling,N_ceiling*N_ceiling*N_ceiling,1,(qx *)UQTFIDE,phi2,phi3 );	
#endif
	for ( measurement_no = 0 ; measurement_no < smp->number_of_loops ;  ++measurement_no   )
	{
		// ListMatrix(0,"phi3",1,N_ceiling*N_ceiling*N_ceiling,phi3) ; // SLOW output
		qx_state_measurement(N_ceiling*N_ceiling*N_ceiling,phi3,measured ) ; 
		// ListMatrix(0,"phi3",1,N_ceiling*N_ceiling*N_ceiling,measured) ; // SLOW output
		AMy = qx_check_measured_state(N_ceiling*N_ceiling*N_ceiling, measured) ;
		A = AMy/(N_ceiling*N_ceiling) ; 
		M = (AMy/(N_ceiling))%N_ceiling ;
		y = AMy%(N_ceiling) ;
		AM = A*M ;
		++A_M_occurrencies[AM] ;
		// count periods of N=15
		if ( (AM) % 4 == 0 ) ++A_M_multiples_of_4 ; 
		else if ( (AM) % 2 == 0 ) ++A_M_multiples_of_2 ; 
		else ++A_M_not_useful ;
	}
	sprintf ( buf, "AM measurement: Multiples of Period=4 occurred:%d times",A_M_multiples_of_4) ; 
	ListMatrix(0,buf) ;
	sprintf ( buf, "AM measurement: Multiples of Period=2 occurred:%d+%d times",A_M_multiples_of_4,A_M_multiples_of_2) ; 
	ListMatrix(0,buf) ;
	sprintf ( buf, "AM measurement: Not useful values occurred:%d times", A_M_not_useful ) ; 
	ListMatrix(0,buf) ;

	if ( QQ_END - QQ_BEGIN > 1 ) // if you want to look for the most efficient input 
	{
		if ( A_M_not_useful > max_unu )
		{
			max_unu = A_M_not_useful ; 
			sprintf ( buf, "qq=%d, MAX = %d", qq, max_unu ) ; ListMatrix(0,buf,1,1,phi0) ; 
		}
		if ( A_M_not_useful < min_unu )
		{
			min_unu = A_M_not_useful ; 
			sprintf ( buf, "qq=%d, MIN = %d", qq, min_unu ) ; ListMatrix(0,buf,1,1,phi0) ; 
		}
	}
 }
 work_in_progress_show(0); 
 return 0 ; 
}
void CQCP_shor::QCF_Shor_Uf_4_periods()
{
char buf[200] ; 
char *m_warning = "Shor Quantum Period Search is defined only for odd numbers having at least 2 non trivial factors, so the only 4 bit good value is 15 (5*3)." ;
#ifdef QCNOOQ_WINDOWS
	m_edit_number_16.GetWindowText(buf, 100) ; only_digits(buf) ;  
#else
	strcpy(buf, "15") ; // to be done: input number
#endif
	if ( atoi(buf) != 15 ) 
	{
		ListMatrix(3,m_warning) ;
#ifdef QCNOOQ_WINDOWS
		m_edit_number_16.SetWindowText("15") ; m_edit_number_16.SetFocus() ; m_edit_number_16.SetSel(m_edit_number_16.GetWindowTextLength(),m_edit_number_16.GetWindowTextLength()) ; 
		m_edit_number_16.GetWindowText(buf, 100) ; only_digits(buf) ;  
#else
		strcpy(buf, "15") ; 
#endif
	}
	this->N = atoi(buf) ; // parameter for threaded search
#ifdef QCNOOQ_WINDOWS
	m_experiments_input.GetWindowText(buf, 100) ; only_digits(buf) ;  
#else
	strcpy (buf, "100") ; // input buf
#endif
	this->number_of_loops = atoi(buf);

	// first execute matrix construction, silent mode 
	if ( QCF_Shor_Uf_4_bit_exec(0) == FALSE ) 
		return ;
	// then execute Shor's period search: execute as a thread because it will be slow 
#ifdef QCNOOQ_WINDOWS
	 // a Windows event should not timeout. So if the function will last more than a few seconds, create a thread and release the button event
	AfxBeginThread(QCF_Shor_Uf_4_periods_exec_threaded, this) ;
#else
	QCF_Shor_Uf_4_periods_exec_threaded(this);
#endif
}
void CQCP_shor::QCF_Shor_Test_Tools() // write here the code needed for tests
{
int k, j ; 
#define VANDER_TO_TEST     8
#define VANDER_TO_TEST_LOG 3
static qx vander[VANDER_TO_TEST][VANDER_TO_TEST] ;
static qx realpart[VANDER_TO_TEST][VANDER_TO_TEST] ;
 // display a Vandermonde matrix:
 qx_matrix_constant(QX_M22_VANDERMONDE,VANDER_TO_TEST_LOG,(qx *)vander); // dimension: 2 pow4, = VANDER_TO_TEST 
 ListMatrix(0,"Vandermonde VANDER_TO_TEST", VANDER_TO_TEST,VANDER_TO_TEST,(qx *)vander);
 for ( k = 0 ; k < VANDER_TO_TEST ; ++k ) 
 {
	 for ( j = 0 ; j < VANDER_TO_TEST ; ++j ) 
	 {
		 realpart[k][j].b = 0 ; 
		 realpart[k][j].a = vander[k][j].a  ;
	 }
 }
 ListMatrix(0,"Real coefficent VANDER_TO_TEST", VANDER_TO_TEST,VANDER_TO_TEST,(qx *)realpart);
}
