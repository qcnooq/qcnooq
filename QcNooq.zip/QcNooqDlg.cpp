/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// QcNooqDlg.cpp : implementation file. To be included in project ONLY in Windows MFC environment
//

#include "stdafx.h"
#include "QcNooq.h"
#include "QcNooqDlg.h"
#include "QcNooq_ReadMe.h"

#include "math.h"      // standard C math definition     
#include "QCM_math.h"  // portable definitions 
#include "QCM_tools.h"

#include "QCP_matrix.h"
#include "QCP_bitqubit.h"
#include "QCP_gates.h"
#include "QCP_deutsch.h"
#include "QCP_deutsch_josza.h"
#include "QCP_simon.h"
#include "QCP_grover.h"
#include "QCP_shor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CAboutDlg dialog used for App About
CAboutDlg::CAboutDlg() : CDialogML(CAboutDlg::IDD)
{
}
void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogML::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC01, m_static01);
	DDX_Control(pDX, IDC_STATIC02, m_static02);
	DDX_Control(pDX, IDC_STATIC03, m_static03);
}
void CAboutDlg::OnOK(){};
BEGIN_MESSAGE_MAP(CAboutDlg, CDialogML)
END_MESSAGE_MAP()

// CQcNooqDlg dialog

CQcNooqDlg::CQcNooqDlg(CWnd* pParent /*=NULL*/) 	: CDialogML(CQcNooqDlg::IDD, pParent)
{	
}
void CQcNooqDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogML::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_messages, m_messages);
	DDX_Control(pDX, IDC_matrix_0, m_matrix_0);
	DDX_Control(pDX, IDC_BUTTON_resize, m_resize);
	DDX_Control(pDX, IDC_BUTTON_cls, m_cls);
	DDX_Control(pDX, IDC_BUTTON_read_me, m_readme);
	DDX_Control(pDX, IDC_BUTTON_matrix_test, m_chap30);
	DDX_Control(pDX, IDC_BUTTON_bitqubit_test, m_chap40);
	DDX_Control(pDX, IDC_BUTTON_gates_test, m_chap50);
	DDX_Control(pDX, IDC_BUTTON_deutsch_test, m_chap61);
	DDX_Control(pDX, IDC_BUTTON_deutsch_Josza, m_chap62);
	DDX_Control(pDX, IDC_BUTTON_Simon, m_chap63);
	DDX_Control(pDX, IDC_BUTTON_Grover, m_chap64);
	DDX_Control(pDX, IDC_BUTTON_Shor, m_chap65);
	DDX_Control(pDX, IDC_info00, m_info00);
	DDX_Control(pDX, IDC_buildinfo, m_buildinfo);
	DDX_Control(pDX, IDC_STATIC01, m_static01);
	DDX_Control(pDX, IDC_STATIC00, m_static00);
	DDX_Control(pDX, IDC_STATIC02, m_static02);
}
BEGIN_MESSAGE_MAP(CQcNooqDlg, CDialogML)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_read_me, &CQcNooqDlg::On_Button_readme)
	ON_BN_CLICKED(IDC_BUTTON_matrix_test, &CQcNooqDlg::On_Button_matrix_test)	
	ON_BN_CLICKED(IDC_BUTTON_deutsch_test, &CQcNooqDlg::On_Button_deutsch_test)
	ON_BN_CLICKED(IDC_BUTTON_bitqubit_test, &CQcNooqDlg::On_Button_bitqubittest)
	ON_BN_CLICKED(IDC_BUTTON_gates_test, &CQcNooqDlg::On_Button_gatestest)
	ON_BN_CLICKED(IDC_BUTTON_deutsch_Josza, &CQcNooqDlg::On_Button_deutschJosza)
	ON_BN_CLICKED(IDC_BUTTON_Simon, &CQcNooqDlg::On_Button_Simon)
	ON_BN_CLICKED(IDC_BUTTON_Grover, &CQcNooqDlg::On_Button_Grover)
	ON_BN_CLICKED(IDC_BUTTON_Shor, &CQcNooqDlg::On_Button_Shor)
	ON_BN_CLICKED(IDC_BUTTON_resize, &CQcNooqDlg::On_Button_resize)
	ON_BN_CLICKED(IDC_BUTTON_cls, &CQcNooqDlg::On_Button_Buttoncls)
	ON_NOTIFY(NM_RCLICK, IDC_matrix_0, &CQcNooqDlg::OnNMRClickmatrix0)
END_MESSAGE_MAP()

// CQcNooqDlg message handlers
void CQcNooqDlg::OnOK(){};
BOOL CQcNooqDlg::OnInitDialog()
{
char buf[200] ; 
	CDialog::OnInitDialog();
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// Add extra initialization here
	// matrix style
	m_matrix_0.SetExtendedStyle(m_matrix_0.GetExtendedStyle() | (LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT));
	if ( WorkInProgress.Create(CAboutDlg::IDD,this) == TRUE ) 
	{
		WorkInProgress.UpdateWindow() ; 
		WorkInProgress.ShowWindow(SW_HIDE) ; 
	}
	sprintf(buf, "Build %s %s", __DATE__, __TIME__ ) ; 
	m_buildinfo.SetWindowText(buf);
	return TRUE;  // return TRUE  unless you set the focus to a control
}
void CQcNooqDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}
// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.
void CQcNooqDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogML::OnPaint();
	}
}
// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CQcNooqDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}
void CQcNooqDlg::OnNMRClickmatrix0(NMHDR *pNMHDR, LRESULT *pResult)
{
LPNMITEMACTIVATE pNMItemActivate = (LPNMITEMACTIVATE)(pNMHDR);
int r,rows, c,cols ; 
CHeaderCtrl* pHeader;
CString mread ; 
 if (AfxMessageBox("Do you want to copy the Matrix into Windows Clipboard?", MB_YESNO) == IDYES) 
 {
	rows = m_matrix_0.GetItemCount() ; 
	if ((pHeader = m_matrix_0.GetHeaderCtrl()) == NULL) return ;
	cols = pHeader->GetItemCount();
	if ( rows > 0 && cols > 0 )
	{
		for ( r = 0 ; r < rows ; ++r ) 
		{
			for ( c = 0 ; c < cols ; ++c ) 
		 {
			 mread.Append(m_matrix_0.GetItemText(r,c)) ;
			 mread.Append("\t" ) ; 
		 }
			mread.Append("\r\n" ) ; 
		}
		int ok = OpenClipboard();
		if (ok) {			
			HGLOBAL clipbuffer;
			char * buffer;
			EmptyClipboard();
			clipbuffer = GlobalAlloc(GMEM_DDESHARE, strlen(mread)+1);
			buffer = (char*)GlobalLock(clipbuffer);
			strcpy(buffer, mread);
			GlobalUnlock(clipbuffer);
			SetClipboardData(CF_TEXT,clipbuffer);
			CloseClipboard();
		}
	}
}
*pResult = 0;
}

// END of Windows specific code -- Service of application buttons
void CQcNooqDlg::On_Button_readme()
{
QcNooq_ReadMe qcni ; 
 qcni.DoModal() ; 
}
void CQcNooqDlg::On_Button_resize()
{
static char resize_mode = 0 ; 
 if ( ++resize_mode > 2 ) resize_mode = 0 ; 
 ListMatrixResize(resize_mode) ; 
}
void CQcNooqDlg::On_Button_Buttoncls()
{
 m_messages.ResetContent() ; 
 m_matrix_0.DeleteAllItems() ; 
}
void CQcNooqDlg::On_Button_matrix_test()
{
static CQCP_matrix QCP_object ;
 if ( theApp.windows_semaphore ) return ;  theApp.windows_semaphore = 1 ; 
 if ( QCP_object.Create(this)== TRUE ) { QCP_object.ShowWindow(SW_SHOW) ; QCP_object.UpdateWindow() ; }
}
void CQcNooqDlg::On_Button_bitqubittest()
{
static CQCP_bitqubit QCP_object ;
 if ( theApp.windows_semaphore ) return ;  theApp.windows_semaphore = 1 ; 
 if ( QCP_object.Create(this)== TRUE ) { QCP_object.ShowWindow(SW_SHOW) ; QCP_object.UpdateWindow() ; }
}
void CQcNooqDlg::On_Button_gatestest()
{
static CQCP_gates QCP_object ;
 if ( theApp.windows_semaphore ) return ;  theApp.windows_semaphore = 1 ; 
 if ( QCP_object.Create(this)== TRUE ) { QCP_object.ShowWindow(SW_SHOW) ; QCP_object.UpdateWindow() ; }
}
void CQcNooqDlg::On_Button_deutsch_test()
{
static CQCP_deutsch QCP_object ;
 if ( theApp.windows_semaphore ) return ;  theApp.windows_semaphore = 1 ; 
 if ( QCP_object.Create(this)== TRUE ) { QCP_object.ShowWindow(SW_SHOW) ; QCP_object.UpdateWindow() ; }
}
void CQcNooqDlg::On_Button_deutschJosza()
{
static CQCP_deutsch_josza QCP_object ;
 if ( theApp.windows_semaphore ) return ;  theApp.windows_semaphore = 1 ; 
 if ( QCP_object.Create(this)== TRUE ) { QCP_object.ShowWindow(SW_SHOW) ; QCP_object.UpdateWindow() ; }
}
void CQcNooqDlg::On_Button_Simon()
{
static CQCP_simon QCP_object ;
 if ( theApp.windows_semaphore ) return ;  theApp.windows_semaphore = 1 ; 
 if ( QCP_object.Create(this)== TRUE ) { QCP_object.ShowWindow(SW_SHOW) ; QCP_object.UpdateWindow() ; }
}
void CQcNooqDlg::On_Button_Grover()
{
static CQCP_grover QCP_object ;
 if ( theApp.windows_semaphore ) return ;  theApp.windows_semaphore = 1 ; 
 if ( QCP_object.Create(this)== TRUE ) { QCP_object.ShowWindow(SW_SHOW) ; QCP_object.UpdateWindow() ; }
}
void CQcNooqDlg::On_Button_Shor()
{
static CQCP_shor QCP_object ;
 if ( theApp.windows_semaphore ) return ;  theApp.windows_semaphore = 1 ; 
 if ( QCP_object.Create(this)== TRUE ) { QCP_object.ShowWindow(SW_SHOW) ; QCP_object.UpdateWindow() ; }
}
