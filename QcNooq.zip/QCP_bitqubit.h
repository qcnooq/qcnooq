/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
#pragma once
#ifdef QCNOOQ_WINDOWS
 #include "afxwin.h"
#endif 

// CQCP_bitqubit dialog

class CQCP_bitqubit 
#ifdef QCNOOQ_WINDOWS
	: public CDialogML
#endif
{
#ifdef QCNOOQ_WINDOWS
	DECLARE_DYNAMIC(CQCP_bitqubit)
public:
	CQCP_bitqubit(CWnd* pParent = NULL);   // standard constructor
	virtual ~CQCP_bitqubit();
	BOOL Create(CWnd* pParent) ;
	void OnCancel() ;
	BOOL OnInitDialog();
	void OnOK();
// Dialog Data
	enum { IDD = IDD_QCP_B_BITQUBIT };
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	CStaticML m_static00;
	CColorButton m_A, m_B, m_C, m_D, m_E, m_F;
	DECLARE_MESSAGE_MAP()
#endif
	void execute_measurement_test(int);
    void QCF_measurement_test();
	void QCF_measurement_test_loop();
	void QCF_ket_normalization();
	void QCF_ket_simple_action_1_qubit();
	void QCF_ket_action_on_2_qubits();
	void QCF_ket_action_2_bit_measured();
};
