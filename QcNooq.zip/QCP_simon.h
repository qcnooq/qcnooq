/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020 ISBN: 9788897527541 
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
#pragma once
#ifdef QCNOOQ_WINDOWS
#include "afxwin.h"
#endif

// CQCP_simon dialog

class CQCP_simon 
#ifdef QCNOOQ_WINDOWS
	: public CDialogML
#endif
{
#ifdef QCNOOQ_WINDOWS
	DECLARE_DYNAMIC(CQCP_simon)
public:
	CQCP_simon(CWnd* pParent = NULL);   // standard constructor
	virtual ~CQCP_simon();
	BOOL Create(CWnd* pParent) ;
	void OnCancel() ;
	BOOL OnInitDialog();
	void OnOK();
	
// Dialog Data
	enum { IDD = IDD_QCP_H_SIMON };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	CStaticML m_static00;
	CStaticML m_static01;
	CColorButton m_A;
	CColorButton m_B;
	CColorButton m_C;
	CColorButton m_D;
	CColorButton m_E;
	CColorButton m_F;
	CColorButton m_G;
	CColorButton m_H;
	CColorButton m_I;
	CColorButton m_J;
	CColorButton m_K;
	CColorButton m_L;
	DECLARE_MESSAGE_MAP()
#endif
public:
	byte func_6bit_period ; 
	int number_of_loops ; 	
protected:
	void QCF_Simon_3bit_func_Uf_compose(char mode, qx Ufunc[64][64]);
	void QCF_Simon_3bit_func_definition();
	void QCF_Simon_3bit_func_find_period();
    void QCF_Simon_3bit_func_Uf();
    void QCF_Simon_3bit_func_Uf_verify();  
    void QCF_Simon_3bit_Simons_once();
	void QCF_Simon_3bit_Simons();

// allocate once: cannot be in stack
public:
	qx big_Ufunc_64[(64*64)][(64*64)] ;
	qx big_HA64ID64[(64*64)][(64*64)] ; // cannot be in stack
	void QCF_Simon_6bit_func_Uf_compose(char mode, qx Ufunc[(64*64)][(64*64)]);		

protected:
	void QCF_Simon_6bit_func_definition_do(int param);
	void QCF_Simon_6bit_func_definition();
	void QCF_Simon_6bit_func_find_period();
    void QCF_Simon_6bit_func_Uf();
    void QCF_Simon_6bit_func_Uf_verify();  
    void QCF_Simon_6bit_Simons_once();
	void QCF_Simon_6bit_Simons();	
};
