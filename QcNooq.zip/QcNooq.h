/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020 ISBN: 9788897527541 
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
**  To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// QcNooq.h : main header file for the PROJECT_NAME application
//

#pragma once
#ifdef QCNOOQ_WINDOWS
#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

// Windows includes:
#include "resource.h"		// main symbols
#include "QcNooqButton.h"
#include "QcNooqStatic.h"
#include "QcNooqDialog.h"
// Definizioni di libreria Palz (classi MFC modifcate)
#define APP_STYLE    
#define ZO_COLOR_SFONDONE_SFONDO 0xbbbd7f // 0xaaac6f
#define ZO_COLOR_TASTI           0x9dc6b6 //0xc0e1f6 //0xe8fd92

#define ZO_COLOR_SFONDONE_SFONDO_STATICS ZO_COLOR_SFONDONE_SFONDO
#define ZO_COLOR_SFONDONE_LATI   0xf4f4f4
#define ZO_COLOR_SFONDONE_TESTO  0x404040
#define ZO_COLOR_ARANCIO 0x0faaf2
#define ZO_COLOR_NAVY    0x993300
#define ZO_COLOR_TASTI_BORDER          0x685d1e//0x503e2c   // tasti tutti se borderati anyway
#define ZO_COLOR_TASTI_BORDER_DISABLED 0xc8aa8c   // tasti tutti se borderati anyway
#define ZO_COLOR_KEY_FRAMED            0x993300   // tasti pigiati

#define ZO_COLOR_HELP_BORDER   0xa6e3b8 //0xfacc9f

#define ZO_COLOR_TASTI_HELP    0xd7d7d7    // indiano
#define ZO_COLOR_TASTI_FINALE  0xc6c6c6 // indiano

#define ZO_COLOR_TEXT         0x00     //0x343434     // indiano
#define ZO_COLOR_TEXT_HELP    0x232323
#define ZO_COLOR_TEXT_FINALE  0xdd5500 //   0x232323

#define ZO_VERDE_PROVVISORIO      0x9fe4df
#define ZO_VERDE_HELP_PROVVISORIO 0x97cac6
#define ZO_TESTO_PROVVISORIO      0x000000

#define ZO_COLOR_NORMAL_TEXT 0x00

// help della prima pagina
#define ZO_COLOR_TEXT_MAIN_HELP    ZO_COLOR_SFONDONE_TESTO

#define ZO_COLOR_ROSSO       0x2100a5      // rosso tasto reset
#define ZO_COLOR_ROSSONE     0x0000aa
#define ZO_COLOR_ROSSO_RESET 0x0000e1
#define ZO_COLOR_GIALLO      0x00ccff // 0xc56a31   // cos� per default
/* end of file */

// CQcNooqApp:
// See QcNooq.cpp for the implementation of this class
//

class CQcNooqApp : public CWinApp
{
public:
	CQcNooqApp();

// Overrides
	public:
	virtual BOOL InitInstance();
	char windows_semaphore ; 

// Implementation

	DECLARE_MESSAGE_MAP()
};
extern CQcNooqApp theApp;
extern void work_in_progress_show(int) ; 
#pragma warning(disable : 4996) // this pragma is to allow the usage of sprintf without giving a warning
#else

#pragma warning(disable : 4996) // this pragma is to allow the usage of sprintf without giving a warning
extern void work_in_progress_show(int) ; 
typedef unsigned short      UINT16, *PUINT16;
typedef unsigned int        UINT;
typedef void             *LPVOID;
#endif 
