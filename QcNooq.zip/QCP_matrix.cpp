/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020 ISBN: 9788897527541 
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// QCP_matrix.cpp : implementation file. Drills for Chapter 3 of "Quantum Computing for Programmers and Investors"
//

#include "stdafx.h"
#include "QcNooq.h"

#include "math.h"      // standard C math definition     
#include "QCM_math.h"  // portable definitions 
#include "QCM_tools.h"

#include "QCP_matrix.h"

// CQCP_matrix dialog
#ifdef QCNOOQ_WINDOWS
IMPLEMENT_DYNAMIC(CQCP_matrix, CDialog)

CQCP_matrix::CQCP_matrix(CWnd* pParent /*=NULL*/) : CDialogML(CQCP_matrix::IDD, pParent)
{
}
CQCP_matrix::~CQCP_matrix()
{
}
BOOL CQCP_matrix::Create(CWnd* pParent)
{
	if (!CDialogML::Create(CQCP_matrix::IDD, pParent))
	{
		return FALSE;
	}
	return TRUE;
}
void CQCP_matrix::OnCancel() {DestroyWindow(); theApp.windows_semaphore=0;}
void CQCP_matrix::DoDataExchange(CDataExchange* pDX)
{
	CDialogML::DoDataExchange(pDX);	
	DDX_Control(pDX, IDC_STATIC00, m_static00);
	DDX_Control(pDX, IDC_MUL_VEC_MAT, m_A);
	DDX_Control(pDX, IDC_MUL_MAT_MAT, m_B);
	DDX_Control(pDX, IDC_VERIF_UNIT_MAT, m_C);
	DDX_Control(pDX, IDC_VERIF_HERMITIAN_MAT, m_D);
	DDX_Control(pDX, IDC_VERIF_TENSOR, m_E);
	DDX_Control(pDX, IDC_VERIF_INNER_PRODUCT, m_F);
	DDX_Control(pDX, IDC_VERIF_INNER_PRODUCT_BIT, m_G);
}
BEGIN_MESSAGE_MAP(CQCP_matrix, CDialogML)
	ON_BN_CLICKED(IDC_MUL_VEC_MAT, &CQCP_matrix::QCF_Mul_Vector_Matrix)
	ON_BN_CLICKED(IDC_MUL_MAT_MAT, &CQCP_matrix::QCF_Mul_Matrix_Matrix)
	ON_BN_CLICKED(IDC_VERIF_UNIT_MAT, &CQCP_matrix::QCF_Verify_Unitary_Matrix)
	ON_BN_CLICKED(IDC_VERIF_TENSOR, &CQCP_matrix::QCF_Verify_Tensor)
	ON_BN_CLICKED(IDC_VERIF_HERMITIAN_MAT, &CQCP_matrix::QCF_Verif_Hermitian_Mat)
	ON_BN_CLICKED(IDC_VERIF_INNER_PRODUCT, &CQCP_matrix::QCF_Verify_Inner_Product)
	ON_BN_CLICKED(IDC_VERIF_INNER_PRODUCT_BIT, &CQCP_matrix::QCF_Verify_Inner_Product_Bit)
END_MESSAGE_MAP()
void CQCP_matrix::OnOK(){};
BOOL CQCP_matrix::OnInitDialog()
{
	CDialogML::OnInitDialog();
	ListMatrixResize(0); // give appropriate sizes
	return TRUE;  // return TRUE  unless you set the focus to a control
}
#endif
// CQCP_matrix message handlers

void CQCP_matrix::QCF_Mul_Vector_Matrix() // multiply twice a matrix * a vector - Only real values
{
char buf[200] ; 
qx b0[8][8] = {                         // input matrix - real values
	{{0},{0},{0},{0},{0},{0},{0},{0}},
	{{1},{2},{0},{0},{0},{0},{0},{0}},
	{{1},{0},{1},{0},{0},{0},{0},{0}},
	{{0},{2},{0},{1},{0},{0},{0},{0}},
	{{0},{2},{0},{0},{1},{0},{0},{0}},
	{{0},{2},{2},{0},{0},{1},{0},{0}},	
	{{0},{0},{2},{0},{0},{0},{1},{0}},
	{{0},{0},{2},{0},{0},{0},{0},{1}}  };
qx v0[8] = {{1,1},{2},{1,2},{3},{1,2},{4},{1,3},{5}} ;  // input vector - real and complex
qx v1[8] ; // output of first multiplication
qx vr[8] ; // output of first multiplication

   sprintf ( buf, "The following samples work with the type qx (struct s_qx {double a; double b ;}), whose size is %d bytes", sizeof(qx)); 
   ListMatrix(3,buf) ; 

   qx_matrix_mmul(8,8,1,  (qx *)b0, v0, v1 ) ;  
   ListMatrix(0, "Vector resulting from first multiplication (Matrix * Vector)" , 1,8, v1) ; 
   qx_matrix_mmul(8,8,1, (qx *)b0, v1, vr ) ; 
   ListMatrix(4, "Vector resulting from second multiplication (Matrix * Vector)", 1,8, vr) ; 
   qx_matrix_mmul(1,8,8, v0, (qx *)b0,  v1 ) ;  
   ListMatrix(0, "Vector resulting from first multiplication (Vector *Matrix)" , 1,8, v1) ; 
   qx_matrix_mmul(1,8,8, v1, (qx *)b0,  vr ) ; 
   ListMatrix(4, "Vector resulting from second multiplication (Vector *Matrix)", 1,8, vr) ; 
}

void CQCP_matrix::QCF_Mul_Matrix_Matrix() // matrix multiplication with complex values 
{
qx m11[4][3] = {{ {3,2}, {0},   {5,-6}}, 
	            { {1},   {4,2}, {0,1} }, 
				{ {1},   {4,3}, {2,1} }, 
                { {4,-1},{0},   {4}   } }; // 4 rows, 3 columns
qx m12[3][2] = {{ {1},  {0,1}}, 
				{ {1},  {4,2}}, 
				{ {0,5},{2,1}}} ; // 3 rows, 2 columns
qx m13[4][2] ; // the result has m rows  and p columns
 qx_matrix_mmul(4,3,2, (qx *)m11, (qx *)m12, (qx *)m13 ) ;  
 ListMatrix(3,"Matrix Resulting from multiplication", 4,2, (qx *)m13)  ;
}

void CQCP_matrix::QCF_Verify_Unitary_Matrix()
{
#define ALPHA 30.0   // any angle in degrees
BOOL unitary ;
char buf[200] ;
qx matrix_to_test[3][3] = 
 { { {1}, {0}, {0}}, 
   { {0}, {1}, {0}}, 				
   { {0}, {0}, {1}} }; // 3 rows, 3 columns

 unitary = qx_matrix_is_unitary(3, (qx *) matrix_to_test) ; 
 sprintf ( buf, "The Identity matrix is trivially unitary: %s", unitary ? "yes": "no" ) ;
 ListMatrix(7, buf,3,3,(qx *)matrix_to_test ) ; 

 // let us assign different values to some elements:
 matrix_to_test[0][0].a =  cos(ALPHA) ;
 matrix_to_test[0][1].a = -sin(ALPHA) ;
 matrix_to_test[1][0].a =  sin(ALPHA) ;
 matrix_to_test[1][1].a =  cos(ALPHA) ;
 sprintf ( buf, "The  matrix of the second example is unitary: %s", unitary ? "yes": "no" ) ;
 ListMatrix(4, buf,3,3,(qx *)matrix_to_test ) ; 

 // let us test if it is reversible
qx vector[3] = { {1}, {2,2}, {0,3} } ;
qx v1[3], v2[3] ;
 ListMatrix(0, "Sample vector", 1,3, vector ) ; 
 qx_matrix_mmul ( 3,3,1, (qx *)matrix_to_test, vector, v1) ; 
 ListMatrix(0, "First product unitary matrix * vector", 1,3, v1 ) ; 
 qx_matrix_mmul ( 3,3,1, (qx *)matrix_to_test, v1, v2) ; 
 ListMatrix(0, "Second product unitary matrix * vector", 1,3, v2 ) ; 
}
void CQCP_matrix::QCF_Verif_Hermitian_Mat()
{
BOOL unitary , hermitian ;
char buf[200] ;
qx matrix_to_test[4][4] = 
{ { {2},    {4,4},  {4,-3},  {7}   },  
  { {4,-4}, {3},    {11.5},  {3,2} },
  { {4,3},  {11.5}, {4},     {1,1} },
  { {7},    {3,-2}, {1,-1},  {5}   } }; // 4 rows, 4 columns

 ListMatrix(3, "First sample matrix", 4,4, (qx *)matrix_to_test ) ; 
 unitary = qx_matrix_is_unitary(4, (qx *) matrix_to_test) ; 
 sprintf ( buf, "The  matrix of the example is unitary: %s", unitary ? "yes": "no" ) ;
 ListMatrix(0, buf ) ; 
 hermitian = qx_matrix_is_hermitian(4, (qx *) matrix_to_test) ; 
 sprintf ( buf, "The  matrix of the example is hermitian: %s", hermitian ? "yes": "no" ) ;
 ListMatrix(0, buf ) ; 

 // let us test if it is reversible
qx vector[4] = { {1}, {2,2}, {0,4}, {2} } ;
qx v1[4], v2[4] ;
 ListMatrix(0, "Sample vector", 1,4, vector ) ; 
 qx_matrix_mmul ( 4,4,1, (qx *)matrix_to_test, vector, v1) ; 
 ListMatrix(0, "First product hermitian matrix * vector", 1,4, v1 ) ; 
 qx_matrix_mmul ( 4,4,1, (qx *)matrix_to_test, v1, v2) ; 
 ListMatrix(0, "Second product hermitian matrix * vector", 1,4, v2 ) ; 

 ListMatrix(4,"---") ; // empty line
// let us substitute the matrix with a remarkable matrix which we'll consider later
qx hada[2][2] ;
 // this will be explained later
 qx_matrix_constant(QX_M22_HADA, (qx *)hada) ;
 qx_matrix_tensor_product(2,2,2,2, (qx *)hada, (qx *)hada, (qx *)matrix_to_test ) ;
 // the matrix was changed in this way
 ListMatrix(0, "Second sample matrix", 4,4, (qx *)matrix_to_test ) ;
 unitary = qx_matrix_is_unitary(4, (qx *) matrix_to_test) ;
 sprintf ( buf, "The  new matrix is unitary: %s", unitary ? "yes": "no" ) ;
 ListMatrix(0, buf ) ;
 hermitian = qx_matrix_is_hermitian(4, (qx *) matrix_to_test) ;
 sprintf ( buf, "The  new matrix is hermitian: %s", hermitian ? "yes": "no" ) ;
 ListMatrix(0, buf ) ;

 // let us test if this is reversible
 ListMatrix(0, "Sample vector", 1,4, vector ) ;
 qx_matrix_mmul ( 4,4,1, (qx *)matrix_to_test, vector, v1) ;
 ListMatrix(0, "First product hermitian matrix * vector", 1,4, v1 ) ; 
 qx_matrix_mmul ( 4,4,1, (qx *)matrix_to_test, v1, v2) ;
 ListMatrix(0, "Second product hermitian matrix * vector", 1,4, v2 ) ;

 // WRONG verification with simple test
int k ; 
 for ( k = 0 ; k < 4 ; ++k ) 
 {
	 if ( vector[k].a != v2[k].a || vector[k].b != v2[k].b ) break ; 
 }
 sprintf ( buf, "Verification NOT taking into NO account floating point approximation:%s", k < 4 ? "KO" : "OK" ) ; ListMatrix(0,buf) ; 
 for ( k = 0 ; k < 4 ; ++k ) 
 {
	 if ( ! qx_complex_equal_enough(vector[k],v2[k] )) break ; 
 }
 sprintf ( buf, "Verification taking into account floating point approximation:%s", k < 4 ? "KO" : "OK" ) ; ListMatrix(0,buf) ; 
}


void CQCP_matrix::QCF_Verify_Tensor()
{
qx matrix_0[2][2] = { {{2},{3}},        {{5},{7}} } ;
qx matrix_1[2][3] = { {{11},{13},{17}}, {{19},{23},{29}} } ;
qx tensor[2*2][2*3] ; 
 qx_matrix_tensor_product(2,2,2,3, (qx *)matrix_0, (qx *)matrix_1, (qx *)tensor ) ; 
 ListMatrix(7,"Tensor product [2][2] Tensor [2][3] ", 2*2, 2*3, (qx *)tensor) ; 

// this vector[2] tensor product will be used often to compose the input of Quantum Data
qx v0[2] = {{1},{0}} ;
qx v1[2] = {{1},{0}} ;
qx v0v1[4] ; 
 qx_matrix_tensor_product(1,2,1,2, v0, v1, v0v1 ) ; 
 ListMatrix(0,"Tensor product of two vectors[2]", 1,4, (qx *)v0v1) ; 
}
void CQCP_matrix::QCF_Verify_Inner_Product()
{
char buf[200] ;
qx indata[7][7] = {
 {{1},{0},{1},{0},{1},{1},{0}},
 {{0},{0},{1},{0},{0},{0},{1}},
 {{1},{1},{0},{0},{1},{0},{1}},
 {{0},{0},{1},{1},{0},{1},{1}},
 {{0},{1},{0},{1},{0},{0},{1}},
 {{0},{0},{1},{1},{0},{1},{0}},
 {{0},{1},{1},{0},{1},{1},{1}}
} ;
qx c[7] = {{1},{1},{0},{1},{0},{1},{0}} ;
qx ipr ;
int k ; 

 ListMatrix(7,"Inner product <vectors[7],c>") ; 
 for ( k = 0 ; k < 7 ; ++k ) 
 {
	 ipr = qx_vector_conjugate_and_inner_product(7, indata[k], c) ; 
	 sprintf ( buf, "Case %03d vector=%s <vector,c> =<%s,%s> =%.0f", k, qx_vector_qx_to_binary_output(7,indata[k]),  
		 qx_vector_qx_to_binary_output(7,indata[k]),  qx_vector_qx_to_binary_output(7,c),  		 ipr ) ; 
	 ListMatrix(0, buf) ; 
 }
qx z[7] ;  
 ListMatrix(4,"Inner product of all <vectors[7],c>") ; 
 for ( k = 0 ; k < 128 ; ++k ) 
 {
	 memset ( z, 0, sizeof(z) ) ; 
	 z[0].a = (k & 64) ? 1 : 0 ; 
	 z[1].a = (k & 32) ? 1 : 0 ; 
	 z[2].a = (k & 16) ? 1 : 0 ; 
	 z[3].a = (k &  8) ? 1 : 0 ; 
	 z[4].a = (k &  4) ? 1 : 0 ; 
	 z[5].a = (k &  2) ? 1 : 0 ; 
	 z[6].a = (k &  1) ? 1 : 0 ; 
	 ipr = qx_vector_conjugate_and_inner_product(7, z, c) ; 
	 sprintf ( buf, "Case %03d vector=[%s] <%s,%s>=%.0f", k, qx_vector_qx_to_binary_output(7,z), 
	 qx_vector_qx_to_binary_output(7,z), qx_vector_qx_to_binary_output(7,c),ipr ) ; 
	 ListMatrix(0, buf) ; 
 }
}
void CQCP_matrix::QCF_Verify_Inner_Product_Bit()
{
char buf[200] ;
byte z, c = 64+32+0+8+0+2+0 ; 
byte ipr ;
 ListMatrix(7,"BIT Inner product of all <vectors[7],c>") ; 
 for ( z = 0 ; z < 128 ; ++z ) 
 {
	 ipr = qx_bit_inner_product(7, (unsigned int)z, (unsigned int)c ) ; 
	 sprintf ( buf, "Case %03d vector=[%s] <%s,%s>=%d", z, qx_binary_output(7,z), 
		 qx_binary_output(7,z), qx_binary_output(7,c), ipr ) ; 
	 ListMatrix(0, buf) ; 

 }
}
