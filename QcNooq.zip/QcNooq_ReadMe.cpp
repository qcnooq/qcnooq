/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// QcNooq_ReadMe.cpp : implementation file. To be included in project ONLY in Windows MFC environment
//

#include "stdafx.h"
#include "QcNooq.h"
#include "QcNooq_ReadMe.h"


// QcNooq_ReadMe dialog

IMPLEMENT_DYNAMIC(QcNooq_ReadMe, CDialog)

QcNooq_ReadMe::QcNooq_ReadMe(CWnd* pParent /*=NULL*/) 	: CDialogML(QcNooq_ReadMe::IDD, pParent)
{
}
QcNooq_ReadMe::~QcNooq_ReadMe()
{
}
void QcNooq_ReadMe::DoDataExchange(CDataExchange* pDX)
{
	CDialogML::DoDataExchange(pDX);
	DDX_Control(pDX, IDOK, m_ok);
	DDX_Control(pDX, IDC_STATIC00, m_static00);
	DDX_Control(pDX, IDC_STATIC11, m_static11);
	DDX_Control(pDX, IDC_STATIC12, m_static12);
	DDX_Control(pDX, IDC_STATIC01, m_static01);
	DDX_Control(pDX, IDC_STATIC02, m_static02);
	DDX_Control(pDX, IDC_STATIC21, m_static21);
	DDX_Control(pDX, IDC_STATIC22, m_static22);
	DDX_Control(pDX, IDC_STATIC03, m_static03);
	DDX_Control(pDX, IDC_STATIC04, m_static04);
	DDX_Control(pDX, IDC_STATIC05, m_static05);
	DDX_Control(pDX, IDC_STATIC06, m_static06);
}
BEGIN_MESSAGE_MAP(QcNooq_ReadMe, CDialogML)
	ON_BN_CLICKED(IDOK, &QcNooq_ReadMe::On_Button_Ok)
END_MESSAGE_MAP()


// QcNooq_ReadMe message handlers
BOOL QcNooq_ReadMe::OnInitDialog()
{
	CDialog::OnInitDialog();
	return TRUE;  // return TRUE  unless you set the focus to a control
}
void QcNooq_ReadMe::On_Button_Ok()
{
	// TODO: Add your control notification handler code here
	OnOK();
}
