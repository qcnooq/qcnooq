/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
#pragma once
#ifdef QCNOOQ_WINDOWS
#include "afxwin.h"
#include "afxcmn.h"
#endif

// CQCP_deutsch dialog

class CQCP_deutsch 
#ifdef QCNOOQ_WINDOWS
 : public CDialogML
#endif
{
#ifdef QCNOOQ_WINDOWS
	DECLARE_DYNAMIC(CQCP_deutsch)
public:
	CQCP_deutsch(CWnd* pParent = NULL);   // standard constructor
	virtual ~CQCP_deutsch();
	BOOL Create(CWnd* pParent) ;
	void OnCancel() ;
	BOOL OnInitDialog();
	void OnOK();

// Dialog Data
	enum { IDD = IDD_QCP_F_DEUTSCH };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	CStaticML m_static00;
	CStaticML m_static01;
	CColorButton m_A;
	CColorButton m_B;
	CColorButton m_C;
	CColorButton m_X;
	CColorButton m_Y;
	DECLARE_MESSAGE_MAP()	
#endif
	void QCF_Shor_Verify_0();
	void QCF_Shor_Verify_1();
	void QCF_Shor_Verify_2();
	void QCF_Alg_deutsch_1_case();
	void QCF_Alg_Deutsch();	
};
