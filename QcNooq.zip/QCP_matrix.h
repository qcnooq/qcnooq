/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
#pragma once
#ifdef QCNOOQ_WINDOWS
#include "afxwin.h"
#endif

// CQCP_matrix dialog

class CQCP_matrix 
#ifdef QCNOOQ_WINDOWS
	: public CDialogML
#endif
{
#ifdef QCNOOQ_WINDOWS
	DECLARE_DYNAMIC(CQCP_matrix)
public:
	CQCP_matrix(CWnd* pParent = NULL);   // standard constructor
	virtual ~CQCP_matrix();
	BOOL Create(CWnd* pParent) ;
	void OnCancel() ;
	BOOL OnInitDialog();
	void OnOK();
	CStaticML m_static00;
// Dialog Data
	enum { IDD = IDD_QCP_A_MATRIX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	CColorButton m_A,m_B,m_C,m_D,m_E,m_F, m_G;
	DECLARE_MESSAGE_MAP()
#endif
public:
	void QCF_Mul_Vector_Matrix();
	void QCF_Mul_Matrix_Matrix();
	void QCF_Verify_Unitary_Matrix();
	void QCF_Verify_Tensor();
	void QCF_Verif_Hermitian_Mat();
	void QCF_Verify_Inner_Product();
	void QCF_Verify_Inner_Product_Bit();	
};
