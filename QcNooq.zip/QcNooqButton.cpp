/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020 ISBN: 9788897527541 
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// QcNooqButton.cpp: A simple class to have color Buttons. To be included in project ONLY in Windows MFC environment
//
#include "stdafx.h"
#include "QcNooq.h"
#include "QcNooqDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CColorButton

extern struct s_mlt MLT_bottoni_statici[] ;

CColorButton::CColorButton()
{
	m_color=0x2ab77a;
	m_allowChange = TRUE;
	m_selected = FALSE;
	m_CustomColors = NULL;
	tipospeciale = nographicfocus = 0 ;
	borderspeciale = dontcenter = 0 ;
	stilespeciale = 0 ;
}
CColorButton::~CColorButton()
{
}
BEGIN_MESSAGE_MAP(CColorButton, CButton)
	ON_WM_DESTROY()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CColorButton message handlers
void CColorButton::OnDestroy()
{
}
#define ABSMENO(x,y) (x>y ? x-y : y-x)
#define INCOLORINIT 0x17
static byte incolor = INCOLORINIT ;

// questa si deve rimappare, perch� altrimenti la traduzione avviene due volte (e male) se il testo del bottone viene settato da programma
void CColorButton::SetWindowText( LPCTSTR lpString )
{
	return CButton::SetWindowText ( lpString ) ;
}
//This function is called when the item is drawn
void CColorButton::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	int l ;
	int righe, niuline ;
	char *nnp ;

	CClientDC dc(this); // device context for painting
	//Draw text
	// Get caption text
	CString strCaption;
	char *strCaptionptr ;

	GetWindowText (strCaption);	
	l = strCaption.GetLength();
	strCaptionptr = strCaption.GetBuffer(l) ;
	l = (int)strlen(strCaptionptr) ;

	if ( tipospeciale >= 1001 )
	{
		int t, flip  ;
		byte r, g, b ;

		t = tipospeciale ;
		flip = 0 ;
		r = g = b = incolor;      // rosso tasto reset

		while ( --t >= 1001 )
		{
			if      ( flip == 0 ) {r += incolor ; if ( r == g && r == b ) r += incolor ;}
			else if ( flip == 1 ) {g += incolor ; if ( r == g && r == b ) g += incolor ;}
			else                  {b += incolor ; if ( r == g && r == b ) b += incolor ;}
			if ( ++flip > 2 ) flip = 0 ;
		}
		m_color = r + g*0x100 + b*0x10000 ;
#define TESTOBIANCO 0x80
		m_text_color = 0 ;
		if ( r < TESTOBIANCO ) m_text_color += 0xff ;
		if ( g < TESTOBIANCO ) m_text_color += 0xff00 ;
		if ( b < TESTOBIANCO ) m_text_color += 0xff0000 ;
	}
	else
	{
		switch ( tipospeciale )
		{
		case 0: if ( l > 0 &&  (strCaptionptr[0] == '!' )  )
				{
					m_color      = ZO_COLOR_TASTI_FINALE ;
					m_text_color = ZO_COLOR_TEXT_FINALE ;
					if ( strCaptionptr[0] == '!' ) ++strCaptionptr ;
				}
				else if ( l > 0 &&  (strCaptionptr[0] == '?' || strCaptionptr[0] == '#' || strCaptionptr[0] == '@') )  // HELP
				{
					char fd1 = 0 , color_gia_dato = 0 ;

					if ( strCaptionptr[1] == '?' ) // help speciale
					{
						m_color      = ZO_COLOR_SFONDONE_LATI ;
						m_text_color = ZO_COLOR_TEXT_MAIN_HELP ;   color_gia_dato = 1 ;
						borderspeciale = ZO_COLOR_HELP_BORDER ;
						strCaptionptr[0] = strCaptionptr[1] ;
						strCaptionptr[1] = ' ' ; //( strCaptionptr[2] == 0  ? 0 : ' ' ) ;
					}
					m_color      = ZO_COLOR_TASTI_HELP   ;
					m_text_color = ZO_COLOR_TEXT_HELP ;
					if ( strCaptionptr[0] == '#' ) { ++fd1 ; ++strCaptionptr ; }
					if ( strCaptionptr[0] == '@' )
					{
						++fd1 ;
						m_color = 0x27c7ef ;
						if ( ! color_gia_dato ) m_text_color = 0x003399 ;
						++strCaptionptr ;
					}

					// dopo il primo incremento
					if ( fd1 )
					{
						if ( strCaptionptr[0] == '#' )
						{
							m_color = ZO_VERDE_PROVVISORIO ;                 // verde provvisorio
							m_text_color = ZO_TESTO_PROVVISORIO ;
							++strCaptionptr ;
						}
						if ( strCaptionptr[0] == '@' )
						{
							m_color = ZO_VERDE_HELP_PROVVISORIO ;                // verde help provvisorio
							m_text_color = ZO_TESTO_PROVVISORIO ;
							++strCaptionptr ;
						}
					}
					//m_text_color = 0 ;
				}
				else
				{
					m_color      = ZO_COLOR_TASTI ;
					m_text_color = ZO_COLOR_TEXT ;
				}
				break ;

		case 1: //m_color      = 0x0066ff ;      // rosso tasto reset
			m_color      = ZO_COLOR_ROSSO_RESET ;      // rosso tasto reset
			m_text_color = 0xffffff ;
			break ;
		case 2: m_color      = 0xffffff ;      // bianco non assegnato
			m_text_color = 0x000000 ;
			break ;
		case 21: m_color      = 0xffffff ;      // bianco non assegnato
			m_text_color = ZO_COLOR_NAVY ;
			break ;
		case 3: m_color      = 0x6355ff ;      // decrementa elaborazioni disponibili
			m_text_color = 0x000000 ;
			break ;
		case 4: m_color      = 0xc0c0c0 ;      // grigio
			m_text_color = 0x000000 ;
			break ;
		case 41:m_color      = 0xb0b0b0 ;      // grigio
			m_text_color = 0xffffff ;      // testo bianco
			break ;
		case 42: m_color      = ZO_COLOR_TASTI ;
			m_text_color = 0x606060 ;      // testo grigio
			break ;
		case 5: m_color      = 0x27c7ef ;      // giallo, come @
			m_text_color = 0x003399 ;
			break ;
		case 51:m_color      = 0x7bf4e9 ; // giallo, come @
			m_text_color = 0x000000 ;
			break ;
		case 52:m_color      = 0x51c2f6 ; // giallo, come @
			m_text_color = 0x000000 ;
			break ;
		case 6: m_color      = ZO_COLOR_ROSSO  ; //0x2100a5 ;      // rosso tasto reset
			m_text_color = 0xffffff ;      // testo bianco in evidenza
			break ;
		case 7: m_color      = ZO_COLOR_SFONDONE_SFONDO ;      // coerente con le caselle mute
			m_text_color = ZO_COLOR_NORMAL_TEXT ;
			break ;
		case 8: m_color      = 0xffffff ;      // bianco
			m_text_color = 0x0000ff ;      // testo rosso in evidenza
			break ;
		case 9: m_color      = 0xffffff ;      // bianco ;      // buio tutto invisibile
			m_text_color = 0xffffff ;      // bianco;
			break ;
		case 10: m_color      = 0x0 ;      // nero
			m_text_color = 0x000000 ;
			break ;
		case 11 :m_color      = ZO_COLOR_SFONDONE_SFONDO ;
			break ;
		case 12 :m_color      = 0x0080ff ;
			m_text_color = 0x000000 ;
			break ;
		case 13 :m_color      = 0xffffff ;      // bianco
			m_text_color = ZO_COLOR_NAVY ;      // testo BLU in evidenza
			break ;
		case 14 :m_color      = 0xffffff ;      // bianco
			m_text_color = ZO_COLOR_ROSSO ;      // testo rosso in evidenza
			break ;
		case 31 :m_color      = ZO_COLOR_NAVY ;  
			m_text_color = 0xffffff ;      // bianco
			break ;
		case 91: m_color      = ZO_VERDE_PROVVISORIO ;      // buio tutto invisibile ma colore del provvisorio
			m_text_color = ZO_VERDE_PROVVISORIO ;
			break ;
		case 92: m_color      = 0xa0a0a0 ;      // grigio
			m_text_color = 0xffffff ;      // testo bianco
			break ;
		case 93: m_color      = 0xe0e0e0 ;      // grigio quasi bianco
			m_text_color = 0xffffff ;      // testo bianco
			break ;
		case 101: m_color = m_text_color = borderspeciale = ZO_COLOR_GIALLO ;      // default cornice della message Box
			break ;
		case 102: m_color = m_text_color = borderspeciale = ZO_COLOR_ROSSONE ;      // errore cornice della message Box
			break ;
		case 103: m_color = m_text_color = borderspeciale = ZO_COLOR_NAVY ;      // question cornice della message Box
			break ;
		case 104: m_color = m_text_color = borderspeciale = ZO_COLOR_ROSSO ;      // exclama cornice della message Box
			break ;
		case 105: m_color = m_text_color = borderspeciale = ZO_COLOR_ARANCIO ;      // asterisk cornice della message Box
			break ;
		}
	}
	CRect rect, ignoreRect, borderrect;
	GetClientRect(&rect);

	//First, fill with background. Don't overwrite the button
	ignoreRect = rect;
#ifdef APP_STYLE
	ignoreRect.DeflateRect(1,1); /**/   ;
#else
	ignoreRect.DeflateRect(2, 2);
#endif
	/* dc.SaveDC();
	dc.ExcludeClipRect(&ignoreRect);
	dc.FillSolidRect(&rect, ::GetSysColor(COLOR_BTNFACE));

	dc.RestoreDC(-1);/**/

	//Draw selection rect, or background color if no selection
#ifdef APP_STYLE
	;
#else
	{
		COLORREF rgbBorder = GetSysColor (COLOR_3DDKSHADOW);
		if(!m_selected)
			rgbBorder = GetSysColor (COLOR_BTNFACE);

		CPen borderPen(PS_SOLID, 1, rgbBorder);
		CPen* pold = dc.SelectObject(&borderPen);
		dc.MoveTo(rect.TopLeft());

		// coordinate per il selection rectangle
		dc.LineTo(rect.right-1, rect.top);
		dc.LineTo(rect.right-1, rect.bottom-1);
		dc.LineTo(rect.left, rect.bottom-1);
		dc.LineTo(rect.left, rect.top);

		dc.SelectObject(pold);
	}/**/
#endif
	//Shrink the rect, 1 pixel on all sides.
	//	rect.DeflateRect(1,1);

	//We want to ignore the area inside the border...
	ignoreRect = rect;
#ifdef APP_STYLE
	;
#else
	ignoreRect.DeflateRect(2, 2);
#endif

	//Draw border
	UINT uFrameCtrl = DFCS_BUTTONPUSH;
	//Is button pushed?
	if ((lpDrawItemStruct->itemState & ODS_SELECTED) == ODS_SELECTED)
		uFrameCtrl |= DFCS_PUSHED;
	//Disabled?
	if ((lpDrawItemStruct->itemState & ODS_DISABLED) == ODS_DISABLED)
		uFrameCtrl |= DFCS_INACTIVE;

	//Draw the frame, but ignore the area inside
	dc.SaveDC();
	dc.ExcludeClipRect(&ignoreRect);
	dc.DrawFrameControl(&rect, DFC_BUTTON, uFrameCtrl);
	dc.RestoreDC(-1);

	//Draw color
#ifdef APP_STYLE
	borderrect = rect ;
	rect.DeflateRect(1,1);
	dc.FillSolidRect(&rect,	m_color);
	rect.DeflateRect(1,1);
#else
	rect.DeflateRect(2,2);
	borderrect = rect ;
	dc.FillSolidRect(&rect,	m_color);
#endif
	//Draw pattern if disabled
	if(!IsWindowEnabled())
	{	
#ifdef APP_STYLE
		COLORREF but = ZO_COLOR_SFONDONE_SFONDO ;
#else
		COLORREF but = ::GetSysColor(COLOR_BTNFACE);
#endif

		for(int x=rect.left; x<rect.right; x++)
			for(int y=rect.top; y<rect.bottom; y++)
				if( (x+y)%2 == 0)
					dc.SetPixel(x, y, but);
	}	/**/
	//Any text to draw?
	if(strCaptionptr[0])
	{
		int oldTextColor = dc.SetTextColor(m_text_color);
		// Determine drawing format
		//DWORD  dwFormat = DT_SINGLELINE | DT_VCENTER | DT_END_ELLIPSIS | DT_CENTER;
		DWORD  dwFormat, format_read_BS ;
		if ( stilespeciale ) dwFormat = stilespeciale ;
		else                 
		{			
			dwFormat = (DT_WORDBREAK | DT_VCENTER ) ;			
			format_read_BS = GetWindowLong(m_hWnd, GWL_STYLE) ;
			if ( ( format_read_BS & BS_LEFT) ) 
			{
				dwFormat |=  DT_LEFT;			
			}
			else if ( ( format_read_BS & BS_RIGHT) ) 
			{
				dwFormat |=  DT_RIGHT;			
			}
			else 
				dwFormat |=  DT_CENTER; 
		}
		// Determine dimensions of caption
		CRect rectCaption = rect;

		//Make push effect by shrinking the rect
		if ((lpDrawItemStruct->itemState & ODS_SELECTED) == ODS_SELECTED)rectCaption.DeflateRect(0, 0, -2, -2);

		//Draw text transparent...
		int oldMode = dc.SetBkMode(TRANSPARENT);
		//...with the original font
		CFont* oldFont = dc.SelectObject(GetFont());

		// gestione della multiline: dove mettere il testo
		/*if ( memicmp( strCaptionptr, "Se l", 4 ) == 0 )
		printf ( "3" ) ;/**/

		if ( ! dontcenter )
		{
			// questa extent � inesatta per un alchimia mentale di questi pazzi - cfr google -> Bristol
			int len = (int)strlen(strCaptionptr) ;
			CSize sz = dc.GetOutputTextExtent(strCaptionptr, len) ;
			//if ( sz.cx > 0 ) {  sz.cx *= 111 ; sz.cx /= 100 ; }  // inutile allungare a caso

			/* SIZE sss ;
			GetTextExtentPoint32(  dc,  strCaptionptr,  len, &sss ); /* identico risultato */
			righe = ((sz.cx / (rectCaption.right-rectCaption.left))+1) ; // numero teorico delle righe

			// se ci sono a capo, tenere conto del numero delle righe risultante
			for ( niuline = 1 , nnp = strCaptionptr ; *nnp ; ++nnp )
				if ( (*nnp == '\n' || *nnp == '\r') && *(nnp+1) >= ' ' ) ++niuline ;

			if ( righe < niuline ) righe = niuline ;
			sz.cy *= righe ;

			len = rectCaption.bottom - rectCaption.top ;
			if ( len > sz.cy )
				rectCaption.top += (len - sz.cy) / 2 ;
		}

		//OK, draw the text...
		if ((lpDrawItemStruct->itemState & ODS_DISABLED) == ODS_DISABLED)
		{
			//Draw like this if disabled.
			rectCaption.OffsetRect(1, 1);
			//dc.SetTextColor(GetSysColor (COLOR_3DHILIGHT));
			dc.SetTextColor(0xffffff);
			dc.DrawText(strCaptionptr, &rectCaption, dwFormat);/**/

			/*	rectCaption.OffsetRect(-1,-1);
			dc.SetTextColor(GetSysColor (COLOR_GRAYTEXT));
			dc.DrawText(strCaptionptr, &rectCaption, dwFormat);/**/
		}
		else dc.DrawText ( strCaptionptr, &rectCaption, dwFormat );

		//Set some stuff back
		dc.SelectObject(oldFont);
		dc.SetBkMode(oldMode);
		dc.SetTextColor(oldTextColor);
	}
	// cornicina se non selected, se il caso

	CRect frect = borderrect ;

	CBrush Brushp ;
	if((!nographicfocus) && ::GetFocus() == m_hWnd) //Is in focus?
		Brushp.CreateSolidBrush (ZO_COLOR_KEY_FRAMED ) ;
	else if ( borderspeciale )
		Brushp.CreateSolidBrush (borderspeciale) ;
	else if ((lpDrawItemStruct->itemState & ODS_DISABLED) == ODS_DISABLED)
		Brushp.CreateSolidBrush (ZO_COLOR_TASTI_BORDER_DISABLED ) ;
	else
		Brushp.CreateSolidBrush ( ZO_COLOR_TASTI_BORDER ) ;
#ifdef APP_STYLE
	;
#else
	::FrameRect(lpDrawItemStruct->hDC, &frect, Brushp );/**/
	frect.bottom += 1 ;
	frect.right  += 1 ;
#endif
	::FrameRect(lpDrawItemStruct->hDC, &frect, Brushp );/**/
	return ;
}
void CColorButton::PreSubclassWindow()
{
	//Make sure owner draw
	ModifyStyle(0, BS_OWNERDRAW);
	CButton::PreSubclassWindow();
}
//When allow change is on, the color may be changed when the user
//click on the button.
BOOL CColorButton::OnClickedEx()
{
	if(m_allowChange)
	{
		SelectColor();
	}
	//Return FALSE. The parent will get the OnClick message.
	return FALSE;
}
//Redraws color box
void CColorButton::Redraw()
{
	Invalidate(FALSE);
}
//Set/get color
void CColorButton::SetColor(const COLORREF newColor)
{
	//Set color
	m_color=newColor;
	Redraw();
}
COLORREF CColorButton::GetColor() const
{
	return m_color;
}

//Get/set selected
void CColorButton::SetSelected(const BOOL selected)
{
	m_selected = selected;
	Redraw();
}
BOOL CColorButton::GetSelected() const
{
	return m_selected;
}
//Set/get if user can change color by clicking
void CColorButton::SetAllowChange(const BOOL allowchange)
{
	m_allowChange = allowchange;
}
BOOL CColorButton::GetAllowChange() const
{
	return m_allowChange;
}
void CColorButton::SetCustomColors(COLORREF *customcolors)
{
	m_CustomColors = customcolors;
}
//Show color box and let user select color
BOOL CColorButton::SelectColor()
{
	BOOL ret = FALSE;

	CColorDialog *dlg = new CColorDialog;

	if(m_CustomColors != NULL)
		dlg->m_cc.lpCustColors = m_CustomColors;

	if(dlg)
	{
		//Set flags, init color
		dlg->m_cc.Flags = dlg->m_cc.Flags | CC_RGBINIT | CC_FULLOPEN;
		dlg->m_cc.rgbResult = m_color;

		if(dlg->DoModal() == IDOK)
		{
			TRACE(_T("User selected color: %d\n"), dlg->GetColor());

			if(dlg->GetColor() != m_color)
			{
				SetColor(dlg->GetColor());
				ret = TRUE;
			}
		}
	}
	delete dlg;
	return ret;
}