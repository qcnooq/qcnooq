/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
#pragma once
#ifdef QCNOOQ_WINDOWS
 #include "afxwin.h"
#endif

// CQCP_gates dialog

class CQCP_gates 
#ifdef QCNOOQ_WINDOWS
	: public CDialogML
#endif
{
#ifdef QCNOOQ_WINDOWS
	DECLARE_DYNAMIC(CQCP_gates)
public:
	CQCP_gates(CWnd* pParent = NULL);   // standard constructor
	virtual ~CQCP_gates();
	BOOL Create(CWnd* pParent) ;
	void OnCancel() ;
	BOOL OnInitDialog();
	void OnOK();

// Dialog Data
	enum { IDD = IDD_QCP_C_GATES };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	CStaticML m_static00, m_static01, m_static02, m_static03 ;
	CColorButton m_NOT;
	CColorButton m_AND;
	CColorButton m_OR;
	CColorButton m_XOR;
	CColorButton m_NAND;
	CColorButton m_C, m_D, m_E;
	CColorButton m_misc_a ;

	DECLARE_MESSAGE_MAP()
#endif

	void classical_gates_test(char *description, qx *classical_gate ) ;
	void QCF_gate_NOT();
	void QCF_gate_AND();
	void QCF_gate_NAND();
	void QCF_gate_OR();
	void QCF_gate_XOR();
	void QCF_gate_composed();
	void QCF_gate_controlled_NOT();
	void QCF_gate_Toffoli();
	void QCF_gate_misc_a();
};
