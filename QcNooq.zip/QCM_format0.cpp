/*
** QcNooq is a copyright free toolbox to implement and test what is explained in the book:
** Quantum Computing for Programmers and Investors 
** by Alberto Palazzi (c) Alberto Palazzi, 2020
** published by GogLiB, 2020 - (Refer to the book for instructions about the usage of QcNooq)
**
** For information and training on Quantum Computing and its practical use, contact us at: www.qcnooq.com 
**
** To use this source code outside the Windows MFC environment, do not define the symbol QCNOOQ_WINDOWS
*/
// output format of a complex number
//

#include "stdafx.h"
#pragma warning(disable : 4996) // questo per levare dai piedi il warning delle future discontinued functions (deprecated)
#include "QCM_Math.h"

// the aim of the following trick is to allow calls of the form: 
// sprintf ( buf, "%c %c %c", qx_format(a), qx_format(b), qx_format(c) )
// define how many times qx_format could be given as parameter to the same call (40 is enormous)
#define RESPONSE_STACK 40
#define QCM_FORMAT_SZ  40
static char responses_buffer[RESPONSE_STACK][QCM_FORMAT_SZ+2] ;
static int  responses_idx = 0;
static char *get_response_ptr ()
{
char *rv ;
    if ( ++responses_idx >= RESPONSE_STACK )
        responses_idx = 0 ;    
    rv = responses_buffer[responses_idx] ;    
    return rv ;    
}
// the aim of qx_format is to give in a quick way a decent representation of a complex number
// you can improve this routine according to your needs
extern char *qx_format(qx c0) 
{
char *response_ptr = get_response_ptr() ; // 
char preca, precb, *cp ; 
char siga, sigb ; 
char numa[QCM_FORMAT_SZ], numb[QCM_FORMAT_SZ] ;

 preca = (int_64_bit)c0.a == c0.a ? 0 : 6 ;
 precb = (int_64_bit)c0.b == c0.b ? 0 : 6 ;
 if ( c0.a < 0.0 ) { c0.a = -c0.a; siga = '-';} else siga = ' ' ; 
 if ( c0.b < 0.0 ) { c0.b = -c0.b; sigb = '-';} else sigb = '+' ; 
 
/*unsigned char bufax[10] , bufbx[10]  ;
 memcpy ( bufax, &c0.a, sizeof(c0.a) ) ; 
 memcpy ( bufbx, &c0.b, sizeof(c0.b) ) ; /**/

 // dopo le operazioni, puoi avere uno zero double composto da zeri e 0x80 nel MSbyte: in tal caso hai l'output "-0"
 // bisogna quindi correggere internamente il double con questo apparente nonsense: 
 /*if ( c0.a == -0.0 ) {
	 c0.a = 0.0 ; // propriet� del floating point
	 // memcpy ( bufax, &c0.a, sizeof(c0.a) ) ; 
 }
 if ( c0.b == -0.0 ) {
	 c0.b = 0.0 ;
	 // memcpy ( bufbx, &c0.b, sizeof(c0.b) ) ; 
 }
/**/
 if ( c0.a == 0.0 && c0.b == 0.0 )
 {
	 sprintf ( response_ptr, " 0 " ) ; 
	 return response_ptr ; 
 }
 if ( c0.a == 0.0 ) numa[0] = 0 ; 
 else
 {
	 if ( preca == 0 ) sprintf ( numa , "%.0f", c0.a ) ;
	 else
	 {
		 sprintf ( numa , "%.*f", preca, c0.a ) ;
		 for ( cp = numa ; *cp ; ++cp ) ;
		 --cp ; 
		 for ( ; cp > numa ; --cp ) 
		 {
			 if ( *cp != '0' ) break ; 
			 *cp = 0 ; 
		 }
	 }
 }
 if ( c0.b == 0.0 ) { numb[0] = 0 ; sigb = ' ' ; }
 else
 {
	 if ( precb == 0 ) sprintf ( numb , "%.0fi", c0.b ) ;
	 else
	 {
		 sprintf ( numb , "%.*f", precb, c0.b ) ;
		 for ( cp = numb ; *cp ; ++cp ) ;
		 --cp ; 
		 for ( ; cp > numb ; --cp ) 
		 {
			 if ( *cp != '0' ) break ; 
			 *cp = 0 ; 
		 }
		 *(cp+1) = 'i' ; *(cp+2) = 0 ; 
	 }
 }
 sprintf ( response_ptr, "%c%s%c%s",  siga, numa,  sigb, numb) ; 

return response_ptr ; 
}

#define QCM_BINARY_LEN 1024
extern void qx_binary_output ( char *dest, int length,  unsigned int number )
{
char binary[QCM_BINARY_LEN+1] ; // a 128 bit number can be represented 
int bx = 0, mask = 1;

 if ( length > QCM_BINARY_LEN )
 {
	 *dest = 0 ; return ; 
 }
 for(int i = 0; i < length; ++i)
 {

			if((mask&number) >= 1)
				binary[bx] = '1';
			else
				binary[bx] = '0';
			++bx ; 
			mask<<=1;
 }
 --bx ; 
 for ( ; bx >= 0 ; --bx ) 
 {
	 *dest = binary[bx] ; ++dest ; 
 }
 *dest = 0 ;  
}
extern char * qx_binary_output (  int length,  unsigned int number )
{
char binary[QCM_BINARY_LEN+1] ; // a 128 bit number can be represented 
int bx = 0, mask = 1;
char *dest, *cp ;
 if ( length > QCM_BINARY_LEN ) return NULL ; 
 dest = (char *)malloc(length+1) ; 
 for(int i = 0; i < length; ++i)
 {

			if((mask&number) >= 1)
				binary[bx] = '1';
			else
				binary[bx] = '0';
			++bx ; 
			mask<<=1;
 }
 --bx ; 
 for ( cp = dest ; bx >= 0 ; --bx ) 
 {
	 *cp = binary[bx] ; ++cp ; 
 }
 *cp = 0 ;  
 return dest ;
}
extern char * qx_vector_qx_to_binary_output( int length, qx *invec) 
{
int bx = 0 ;
char *dest ;
 if ( length > QCM_BINARY_LEN ) return NULL ; 
 dest = (char *)malloc(length+1) ; 
 for(int i = 0; i < length; ++i)
 {

	 if( qx_double_equal_enough(invec[i].a, 1.0) )
		dest[bx] = '1';
	 else
		dest[bx] = '0';
	 ++bx ; 	
 }
 dest[bx] = 0 ; 
 return dest ;
}
extern void qx_binary_vector ( char *dest,  int length,  unsigned int number )
{
char binary[128+1] ; // a 128 bit number can be represented 
int bx = 0, mask = 1;
 for (int i = 0; i < length; ++i)
 {
	if((mask&number) >= 1) binary[bx] = 1;
	else binary[bx] = 0;
	++bx ; 
	mask<<=1;
 }
 --bx ; 
 for ( ; bx >= 0 ; --bx ) 
 {
	*dest = binary[bx] ; ++dest ; 
 } 
}